﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtlasApi.Attributes;
using AtlasApi.Enums;
using AtlasApi.Interfaces;
using AtlasApi.Models;
using AtlasApi.Models.Data;
using AtlasApi.Models.Extensions;
using AtlasApi.Models.Helpers;
using AtlasApi.Models.PrecinctWalkSheetOptions;
using IronPdf;
using Microsoft.AspNetCore.Mvc;

// TODO:  Separate helper methods into their own model classes.
// TODO:  Consider multiple controllers/domains.
// TODO:  More dependency injection of other classes.
namespace AtlasApi.Controllers
{
    // All endpoints start with "atlas/"
    [RequestSizeLimit(int.MaxValue)]
    [Route("[controller]")]
    [ApiController]
    public class AtlasController : ControllerBase
    {
        private const string SheetImageRepositoryDirectory = @"..\Petition Sheets\";

        private static readonly IDictionary<int, string> DuplicateSignalOrdinalByInteger = new Dictionary<int, string>
        {
            [1] = "Owner",
            [2] = "Second",
            [3] = "Third",
            [4] = "Fourth",
            [5] = "Fifth",
            [6] = "Sixth",
            [7] = "Seventh",
            [8] = "Eighth",
            [9] = "Ninth",
            [10] = "Tenth"
        };

        private readonly IAtlasRepository _repository;
        private readonly IPdfWalkSheetGenerator _pdfWalkSheetGenerator;

        public AtlasController(IAtlasRepository repository, IPdfWalkSheetGenerator pdfWalkSheetGenerator)
        {
            this._repository = repository;
            this._pdfWalkSheetGenerator = pdfWalkSheetGenerator;
        }

        #region Endpoint Methods

        [HttpGet]
        public ActionResult<IEnumerable<string>> Hello()
        {
            return new[] {"Hello Atlas"};
        }

        [HttpGet("users/{id}")]  // Endpoint for testing only, not official API call
        public async Task<ActionResult<User>> GetUserAsync(long id)
        {
            var user = await this._repository.GetUserAsync(id);

            if (user == null)
            {
                return this.NotFound();
            }

            return user;
        }

        [HttpPost("admins")]  // Endpoint for prototype API only
        public async Task<ActionResult<User>> CreateAdminAccountAsync(User user)
        {
            user.IsAdmin = true;
            await this._repository.CreateUserAccountAsync(user);
            return this.CreatedAtAction(nameof(AtlasController.GetUserAsync), new { id = user.Id }, user);
        }

        [HttpPost("volunteers")]  // Endpoint for prototype API only
        public async Task<ActionResult<User>> CreateVolunteerAccountAsync(User user)
        {
            user.IsAdmin = false;
            await this._repository.CreateUserAccountAsync(user);

            return this.CreatedAtAction(nameof(AtlasController.GetUserAsync), new { id = user.Id }, user);
        }

        [HttpPost("new-session")]
        public async Task<ActionResult<LoginResponse>> LoginAsync(Login login)
        {
            var user = await this._repository.GetUserAsync(login);
            if (user?.MainCampaign == null)
            {
                return this.NotFound();
            }

            return new LoginResponse
            {
                Id = user.Id,
                Username = user.Username,
                IsAdmin = user.IsAdmin,
                MainCampaignId = user.MainCampaign.Id,
                MainCampaignName = user.MainCampaign.Name,
                Campaigns = user.MainCampaign.SubCampaigns.ToList(),
                WalkSheetOptions = user.MainCampaign.UsesPrecinctWalkSheets
                    ? new WalkSheetOptions(await this._repository.GetPrecinctWalkSheetVotersAsync(user.MainCampaign.Id))
                    : new WalkSheetOptions()
            };
        }

        [HttpPost("{mainCampaignId}/account-management/password-change")]
        public async Task<IActionResult> UpdatePasswordAsync(long mainCampaignId, Login updatedLogin)
        {
            var mainCampaign = await this.GetCampaignAsync(mainCampaignId);
            if (mainCampaign == null)
            {
                return this.NotFound();
            }

            var user = await this._repository.GetUserAsync(updatedLogin.Username);
            if (user == null)
            {
                return this.NotFound();
            }

            user.Password = updatedLogin.Password;
            await this._repository.SaveChangesAsync();
            return this.Ok();
        }

        [HttpPost("{mainCampaignId}/account-management/subcampaign-addition")]
        public async Task<ActionResult<Campaign>> AddSubCampaignAsync(long mainCampaignId, AvailableCampaign subCampaign)
        {
            var mainCampaign = await this.GetCampaignAsync(mainCampaignId);
            if (mainCampaign == null)
            {
                return this.NotFound();
            }

            var campaign = new Campaign
            {
                MainCampaignId = mainCampaignId,
                Name = subCampaign.Name,
                PetitionSheetLineCount = subCampaign.PetitionSheetLineCount
            };

            await this._repository.SaveSubCampaignAsync(campaign);
            return campaign;
        }

        [HttpGet("{mainCampaignId}/{campaignId}/dashboard")]
        public async Task<ActionResult<CampaignDashboardSummary>> GetDashboardSummaryAsync(long mainCampaignId, long campaignId)
        {
            var campaignSummary = await this.GetCampaignSummaryAsync(mainCampaignId, campaignId);
            if (campaignSummary == null)
            {
                return this.NotFound();
            }

            return new CampaignDashboardSummary
            {
                UploadedSheetCount = campaignSummary.UploadedSheetCount,
                ReviewedSheetCount = campaignSummary.ReviewedSheetCount,
                ReviewedSignatureCount = campaignSummary.ReviewedSignaturesCount,
                ValidSignatureCount = campaignSummary.ValidSignaturesCount,
                ApproximateTotalSignatureCount = campaignSummary.ApproximateTotalSignaturesCount,
                ReviewedSheetPercentage = campaignSummary.ReviewedSheetPercentage,
                UnreviewedSheetPercentage = campaignSummary.UnreviewedSheetPercentage,
                ValidSignaturesPercentage = campaignSummary.ValidSignaturesPercentage,
                NotFoundSignaturesPercentage = AtlasController.CalculatePercentage(campaignSummary.NotFoundSignaturesCount, campaignSummary.ReviewedSignaturesCount),
                CrossedOffSignaturesPercentage = AtlasController.CalculatePercentage(campaignSummary.CrossedOffSignaturesCount, campaignSummary.ReviewedSignaturesCount),
                BlankSignaturesPercentage = AtlasController.CalculatePercentage(campaignSummary.BlankSignaturesCount, campaignSummary.ReviewedSignaturesCount),
                InvalidSignaturesPercentage = AtlasController.CalculatePercentage(campaignSummary.InvalidSignaturesCount, campaignSummary.ReviewedSignaturesCount),
                HasVoters = await this._repository.HasVotersAsync(mainCampaignId),
                ReviewedSheetNumbers = campaignSummary.ReviewedSheetNumbers,
                UnreviewedSheetIds = campaignSummary.UnreviewedSheetIds,
                UsesMapWalkSheets = campaignSummary.UsesMapWalkSheets,
                UsesPrecinctWalkSheets = campaignSummary.UsesPrecinctWalkSheets
            };
        }

        [HttpPost("{mainCampaignId}/{campaignId}/document-upload/petition")]
        [DisableFormValueModelBinding]
        public async Task<IActionResult> UploadPetitionSheetsAsync(long mainCampaignId, long campaignId)
        {
            var mainCampaign = await this.GetCampaignAsync(mainCampaignId);
            if (mainCampaign == null)
            {
                return this.NotFound();
            }

            var campaign = await this.GetCampaignWithPetitionSheetsAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            PdfDocument pdf;
            try
            {
                await using var stream = new MemoryStream();
                await this.Request.StreamFileAsync(stream);
                pdf = new PdfDocument(stream.GetBuffer());
            }
            catch
            {
                return this.BadRequest();
            }

            var nextReviewPriorityNumber = AtlasController.GetNewLowestPriorityReviewNumberAsync(campaign.PetitionSheets);
            for (var pageIndex = 0; pageIndex < pdf.PageCount; pageIndex++)
            {
                var petitionSheet = new PetitionSheet
                {
                    Campaign = campaign,
                    SheetNumber = null,
                    Notes = "",
                    Circulator = "",
                    Notary = "",
                    Date = "",
                    ReviewPriorityNumber = nextReviewPriorityNumber
                };

                await this._repository.SavePetitionSheetAsync(petitionSheet);

                var filePath = $"{AtlasController.SheetImageRepositoryDirectory}{mainCampaign.Name}-{campaign.Name}-{petitionSheet.Id}.pdf";
                await this._repository.SavePetitionSheetPathAsync(petitionSheet.Id, filePath);
                var page = pdf.CopyPage(pageIndex);
                page.SaveAs(filePath);

                var sheetLines = new List<SheetLine>();
                for (var lineNumber = 1; lineNumber <= campaign.PetitionSheetLineCount; lineNumber++)
                {
                    sheetLines.Add(new SheetLine
                    {
                        Sheet = petitionSheet,
                        LineNumber = lineNumber,
                        Status = LineStatus.Unreviewed,
                        SignatureValidation = SignatureValidation.NotValidated
                    });
                }

                await this._repository.AddSheetLinesAsync(sheetLines);
                nextReviewPriorityNumber++;
            }

            return this.Ok();
        }

        [HttpPost("{mainCampaignId}/document-upload/voters")]
        [DisableFormValueModelBinding]
        public async Task<ActionResult<WalkSheetOptions>> UploadVoterDataAsync(long mainCampaignId)
        {
            var mainCampaign = await this.GetCampaignAsync(mainCampaignId);
            if (mainCampaign == null)
            {
                return this.NotFound();
            }

            string csv;
            using (var stream = new MemoryStream())
            {
                await this.Request.StreamFileAsync(stream);
                stream.Position = 0;
                using (var reader = new StreamReader(stream))
                {
                    csv = await reader.ReadToEndAsync();
                }
            }

            var voters = await VoterDocumentReader.ParseDocumentAsync(mainCampaign, csv, mainCampaign.UsesMapWalkSheets);
            if (voters.Count < 1)
            {
                return this.BadRequest();
            }

            await this._repository.UpdateCampaignVotersAsync(mainCampaign, voters);

            return mainCampaign.UsesPrecinctWalkSheets
                ? new WalkSheetOptions(voters.Select(v => new PrecinctWalkSheetVoter(v.County, v.City, v.Ward, v.Precinct)))
                : new WalkSheetOptions();
        }

        [HttpGet("{mainCampaignId}/{campaignId}/sheet-review")]
        public async Task<ActionResult<PetitionSheetResponse>> GetPetitionSheetAsync(long campaignId,
            // URI Query parameters
            long? sheetNumber,
            long? sheetId)
        {
            var campaign = await this.GetCampaignWithPetitionSheetsAndLinesAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            PetitionSheet sheet;
            if (sheetNumber == null)
            {
                if (sheetId == null)
                {
                    var orderedSheets = campaign.PetitionSheets.OrderBy(s => s.ReviewPriorityNumber).ToList();
                    sheet = orderedSheets.FirstOrDefault(s => !s.SheetNumber.HasValue) ?? orderedSheets.FirstOrDefault();
                }
                else
                {
                    sheet = campaign.PetitionSheets.FirstOrDefault(s => s.Id == sheetId);
                }

                if (sheet == null)
                {
                    return this.NotFound();
                }

                sheet.ReviewPriorityNumber = AtlasController.GetNewLowestPriorityReviewNumberAsync(campaign.PetitionSheets);
                await this._repository.SaveChangesAsync();
            }
            else
            {
                sheet = campaign.PetitionSheets.FirstOrDefault(s => s.SheetNumber == sheetNumber);
                if (sheet == null)
                {
                    return this.NotFound();
                }
            }

            var sheetLines = sheet.Lines.Select(l => new SheetLineResponse(l, sheet, campaign.Name)).ToList();

            return new PetitionSheetResponse
            {
                Id = sheet.Id,
                SheetNumber = sheet.SheetNumber,
                Notes = sheet.Notes,
                Circulator = sheet.Circulator,
                Notary = sheet.Notary,
                Date = sheet.Date,
                Objections = sheet.Objections.Select(o => o.Objection).ToList(),
                EncodedImage = Convert.ToBase64String(System.IO.File.ReadAllBytes(sheet.Filepath)),
                Lines = sheetLines
            };
        }

        [HttpPost("{mainCampaignId}/{campaignId}/sheet-update")]
        public async Task<ActionResult<PetitionSheetResponse>> SavePetitionSheetAsync(long campaignId, PetitionSheetUpdate sheetUpdate)
        {
            var campaign = await this.GetCampaignWithPetitionSheetsAndLinesAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            var sheet = campaign.PetitionSheets.FirstOrDefault(s => s.Id == sheetUpdate.Id);
            if (sheet == null)
            {
                return this.NotFound();
            }

            await this._repository.DeletePetitionSheetObjectionsAsync(sheet.Id);
            if (sheetUpdate.Objections.Count > 0)
            {
                await this._repository.SavePetitionSheetObjectionsAsync(sheet, sheetUpdate.Objections);
            }

            sheet.SheetNumber = sheetUpdate.SheetNumber;
            sheet.Notes = sheetUpdate.Notes;
            sheet.Circulator = sheetUpdate.Circulator;
            sheet.Notary = sheetUpdate.Notary;
            sheet.Date = sheetUpdate.Date;
            sheet.ReviewPriorityNumber = AtlasController.GetNewLowestPriorityReviewNumberAsync(campaign.PetitionSheets);
            for (var lineIndex = 0; lineIndex < campaign.PetitionSheetLineCount; lineIndex++)
            {
                var lineUpdate = sheetUpdate.Lines[lineIndex];
                var line = sheet.Lines[lineIndex];

                line.Status = lineUpdate.Status;
                if (line.Status == LineStatus.ConfirmedVoter)
                {
                    line.Voter = await this._repository.GetVoterAsync(lineUpdate.VoterId);
                }
            }

            await this._repository.SaveChangesAsync();

            return await this.GetPetitionSheetAsync(campaignId, null, null);
        }

        [HttpDelete("{mainCampaignId}/{campaignId}/sheet-delete/{sheetId}")]
        public async Task<ActionResult<PetitionSheetResponse>> DeletePetitionSheetAsync(long campaignId, long sheetId)
        {
            var campaign = await this.GetCampaignWithPetitionSheetsAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            var sheet = campaign.PetitionSheets.FirstOrDefault(s => s.Id == sheetId);
            if (sheet == null)
            {
                return this.NotFound();
            }

            await this._repository.DeletePetitionSheetAsync(sheet);

            return await this.GetPetitionSheetAsync(campaignId, null, null);
        }

        [HttpGet("{mainCampaignId}/sheet-review/voters")]
        public async Task<ActionResult<List<VoterSearchResponse>>> GetVotersAsync(long mainCampaignId,
            // URI Query parameters
            string firstName,
            string lastName,
            string streetNumber,
            string streetName)
        {
            // Ensure there is at least one criteria selected
            if (string.IsNullOrWhiteSpace(firstName)
                && string.IsNullOrWhiteSpace(lastName)
                && string.IsNullOrWhiteSpace(streetNumber)
                && string.IsNullOrWhiteSpace(streetName))
            {
                return this.NotFound();
            }

            var mainCampaign = await this.GetCampaignAsync(mainCampaignId);
            return mainCampaign == null
                ? (ActionResult<List<VoterSearchResponse>>)this.NotFound() 
                : await this._repository.SearchVotersAsync(mainCampaignId, firstName, lastName, streetNumber, streetName);
        }

        [HttpGet("{campaignId}/valid-signatures-verification")]
        public async Task<ActionResult<List<SheetLineResponse>>> GetSignatureVerificationAsync(long campaignId)
        {
            var verifiedLines = await this.GetConfirmedVoterLinesAsync(campaignId);
            return verifiedLines ?? (ActionResult<List<SheetLineResponse>>)this.NotFound();
        }

        [HttpPut("{campaignId}/valid-signatures-verification")]
        public async Task<IActionResult> UpdateSignatureValidationAsync(long campaignId, SignatureValidationUpdate signatureValidationUpdate)
        {
            var campaign = await this.GetCampaignAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            await this._repository.UpdateSignatureValidationAsync(signatureValidationUpdate);
            return this.Ok();
        }

        [HttpGet("{campaignId}/reports/valid-signatures-csv")]
        public async Task<ActionResult<CsvReport>> GetValidSignatureCsvReportAsync(long campaignId)
        {
            var sheetLines = await this.GetConfirmedVoterLinesAsync(campaignId);
            if (sheetLines == null)
            {
                return this.NotFound();
            }

            var sb = new StringBuilder("Signature Validation Report");
            sb.AppendLine();
            sb.Append("Sheet,Line,Name,Address,City,Zip,Voter ID,Circulator,Notary,Date,Signature Match");
            foreach (var line in sheetLines)
            {
                sb.AppendLine();
                sb.Append($"{line.SheetNumber},{line.LineNumber},{line.VoterName},{line.VoterAddress},{line.VoterCity},{line.VoterZip},{line.VoterRegistrationId},");
                sb.Append($"{line.Circulator},{line.Notary},{line.Date},");
            }

            return new CsvReport
            {
                Report = sb.ToString()
            };
        }

        [HttpGet("{campaignId}/reports/valid-signatures-pdf")]
        public async Task<ActionResult<PdfReport>> GetValidSignaturePdfReportAsync(long campaignId)
        {
            var campaign = await this.GetCampaignAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            var renderedPdf = new HtmlToPdf().RenderHtmlAsPdf(@"<H4>This is a test .pdf objections report</H4>");
            var renderedPdfBytes = renderedPdf.BinaryData;
            var convertedPdfString = Convert.ToBase64String(renderedPdfBytes);

            return new PdfReport
            {
                EncodedReport = convertedPdfString
            };
        }

        [HttpGet("{campaignId}/reports/sheet-csv")]
        public async Task<ActionResult<CsvReport>> GetSheetCsvReportAsync(long campaignId)
        {
            var campaign = await this.GetCampaignWithCheckedPetitionSheetsAndLinesAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            var sb = new StringBuilder("Sheet Report");
            sb.AppendLine();
            sb.Append("Sheet,Valid Signatures,Crossed Out Lines,Blank Lines,Signer Not Registered at Address,Signer's Address Missing or Incomplete,Circulator,Notary,Date");

            foreach (var sheet in campaign.PetitionSheets)
            {
                sb.AppendLine();
                sb.Append($"{sheet.SheetNumber},{sheet.Lines.Count(l => l.Status == LineStatus.ConfirmedVoter)},{sheet.Lines.Count(l => l.Status == LineStatus.LineCrossedOff)},");
                sb.Append($"{sheet.Lines.Count(l => l.Status == LineStatus.LineBlank)},{sheet.Lines.Count(l => l.Status == LineStatus.VoterNotFound)},{sheet.Lines.Count(l => l.Status == LineStatus.LineInvalid)},");
                sb.Append($"{sheet.Circulator},{sheet.Notary},{sheet.Date}");
            }

            return new CsvReport
            {
                Report = sb.ToString()
            };
        }

        [HttpGet("{campaignId}/reports/sheet-pdf")]
        public async Task<ActionResult<PdfReport>> GetSheetPdfReportAsync(long campaignId)
        {
            var campaign = await this.GetCampaignAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            var renderedPdf = new HtmlToPdf().RenderHtmlAsPdf(@"<H4>This is a test .pdf sheet report</H4>");
            var renderedPdfBytes = renderedPdf.BinaryData;
            var convertedPdfString = Convert.ToBase64String(renderedPdfBytes);

            return new PdfReport
            {
                EncodedReport = convertedPdfString
            };
        }

        [HttpGet("{mainCampaignId}/reports/duplicate-signatures-csv")]
        public async Task<ActionResult<CsvReport>> GetDuplicateSignatureCsvReportAsync(long mainCampaignId)
        {
            var mainCampaign = await this._repository.GetMainCampaignWithAllSheetInfoAsync(mainCampaignId);
            if (mainCampaign == null)
            {
                return this.NotFound();
            }

            var signatureLinesByVoter = AtlasController.GetConfirmedSignatureLinesByVoterAsync(mainCampaign);
            var duplicateCountMax = Math.Min(signatureLinesByVoter.Max(g => g.Count()), AtlasController.DuplicateSignalOrdinalByInteger.Count);
            var sbReport = new StringBuilder("Duplicate Signatures Report" + Environment.NewLine);
            if (duplicateCountMax <= 1)
            {
                sbReport.Append("No duplicate signatures found.");
            }
            else
            {
                sbReport.Append("Voter ID,Voter Name,Voter Address,Voter City,Voter Zip Code");
                for (var signatureNumber = 1; signatureNumber <= duplicateCountMax; signatureNumber++)
                {
                    var ordinal = AtlasController.DuplicateSignalOrdinalByInteger[signatureNumber];
                    sbReport.Append($",{ordinal} Petition Date,{ordinal} Petition Candidate,{ordinal} Petition Sheet,{ordinal} Petition Line");
                }

                foreach (var voterSignatureLines in signatureLinesByVoter)
                {
                    var signatureLines = voterSignatureLines.OrderBy(l => l.Date).ToList();
                    if (signatureLines.Count <= 1)
                    {
                        continue;
                    }

                    sbReport.AppendLine();
                    var firstLine = voterSignatureLines.First();
                    sbReport.Append($"{firstLine.VoterRegistrationId},{firstLine.VoterName},{firstLine.VoterAddress},{firstLine.VoterCity},{firstLine.VoterZip}");

                    var lineCount = 0;
                    foreach (var line in signatureLines.Take(duplicateCountMax))
                    {
                        sbReport.Append($",{line.Date},{line.CampaignName},{line.SheetNumber},{line.LineNumber}");
                        lineCount++;
                    }

                    while (lineCount < duplicateCountMax)
                    {
                        sbReport.Append(",,,,");
                        lineCount++;
                    }
                }
            }

            return new CsvReport
            {
                Report = sbReport.ToString()
            };
        }

        [HttpGet("{mainCampaignId}/reports/duplicate-signatures-pdf")]
        public async Task<ActionResult<PdfReport>> GetDuplicateSignaturePdfReportAsync(long mainCampaignId)
        {
            var mainCampaign = await this.GetCampaignAsync(mainCampaignId);
            if (mainCampaign == null)
            {
                return this.NotFound();
            }

            var renderedPdf = new HtmlToPdf().RenderHtmlAsPdf(@"<H4>This is a test .pdf duplicate signatures report</H4>");
            var renderedPdfBytes = renderedPdf.BinaryData;
            var convertedPdfString = Convert.ToBase64String(renderedPdfBytes);

            return new PdfReport
            {
                EncodedReport = convertedPdfString
            };
        }

        [HttpGet("{campaignId}/reports/objections-csv")]
        public async Task<ActionResult<CsvReport>> GetObjectionsCsvReportAsync(long campaignId)
        {
            var campaign = await this.GetCampaignWithPetitionSheetsAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            campaign.PetitionSheets = AtlasController.GetCheckedPetitionSheets(campaign);

            var sb = new StringBuilder("Sheet Objection Report");
            sb.AppendLine();
            sb.Append("Sheet,Circulator,Notary,Date,No Issues, Date of Notary Missing, Circulator Is Not Qualified Under Law, Circulator Did Not Sign Petition Sheet,");
            sb.Append("Circulator Did Not Appear Before Notary,Circulator's Signature Not Genuine, Circulator Does Not Reside at Address Shown,");
            sb.Append("Circulator Circulated for a Candidate of Another Party,Circulator's Affidavit Is Incomplete,Circulator's Address Is Incomplete,");
            sb.Append("Notary Is Incomplete,Damage to Page Prevents Clear Reading,Other,Sheet Notes");

            foreach (var sheet in campaign.PetitionSheets.OrderBy(s => s.SheetNumber))
            {
                sb.AppendLine();
                sb.Append($"{sheet.SheetNumber},{sheet.Circulator},{sheet.Notary},{sheet.Date},");

                var objections = sheet.Objections.Select(o => o.Objection).ToList();
                if (objections.Count < 1)
                {
                    sb.Append("1,,,,,,,,,,,,,");
                }
                else
                {
                    sb.Append(",");
                    sb.Append(objections.Contains(PetitionObjection.NotaryDateMissing) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorNotLegallyQualified) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorSignatureMissing) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorNoNotaryAppearance) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorSignatureIncorrect) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorAddressIncorrect) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorAnotherParty) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorAffidavitIncomplete) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.CirculatorAddressIncomplete) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.NotaryIncomplete) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.DamagePreventsReading) ? "1," : ",");
                    sb.Append(objections.Contains(PetitionObjection.Other) ? "1," : ",");
                }

                sb.Append(sheet.Notes);
            }

            return new CsvReport
            {
                Report = sb.ToString()
            };
        }

        [HttpGet("{campaignId}/reports/objections-pdf")]
        public async Task<ActionResult<PdfReport>> GetObjectionsPdfReportAsync(long campaignId)
        {
            var campaign = await this.GetCampaignAsync(campaignId);
            if (campaign == null)
            {
                return this.NotFound();
            }

            var renderedPdf = new HtmlToPdf().RenderHtmlAsPdf(@"<H4>This is a test .pdf objections report</H4>");
            var renderedPdfBytes = renderedPdf.BinaryData;
            var convertedPdfString = Convert.ToBase64String(renderedPdfBytes);

            return new PdfReport
            {
                EncodedReport = convertedPdfString
            };
        }

        [HttpGet("{mainCampaignId}/{campaignId}/reports/total-valid-signatures-csv")]
        public async Task<ActionResult<CsvReport>> GetTotalValidSignaturesCsvReportAsync(long mainCampaignId, long campaignId)
        {
            var campaignSummary = await this.GetCampaignSummaryAsync(mainCampaignId, campaignId);
            if (campaignSummary == null)
            {
                return this.NotFound();
            }

            var sb = new StringBuilder("Campaign Summary Report");
            sb.AppendLine();
            sb.AppendLine();
            sb.AppendLine($"Total Petition Pages,{campaignSummary.ReviewedSheetCount}");
            sb.AppendLine($"Total Lines,{campaignSummary.ReviewedSignaturesCount}");
            sb.AppendLine($"Blank Lines,{campaignSummary.BlankSignaturesCount}");
            sb.AppendLine($"Crossed Out Lines,{campaignSummary.CrossedOffSignaturesCount}");
            sb.AppendLine($"Total Invalid,{campaignSummary.InvalidSignaturesCount}");
            sb.AppendLine($"Total Not Found,{campaignSummary.NotFoundSignaturesCount}");
            sb.AppendLine($"Total Found Signatures,{campaignSummary.ValidSignaturesCount}");
            sb.AppendLine();
            sb.AppendLine($"Total Validated Signatures,{campaignSummary.TotalValidatedSignaturesCount}");
            sb.AppendLine();
            sb.AppendLine($"Total Sheets with Objections,{campaignSummary.ObjectionSheetCount}");
            sb.AppendLine($"Total Validated Signatures on Objection Sheets,{campaignSummary.ObjectionSheetsValidatedSignaturesCount}");
            sb.AppendLine();
            sb.AppendLine($"Total Duplicate Signatures,{campaignSummary.DuplicateSignatureCount}");
            sb.AppendLine();
            sb.AppendLine($"Total Non-Duplicate/Non-Objected Validated Signatures,{campaignSummary.TotalValidatedSignaturesCount - campaignSummary.ObjectionSheetsValidatedSignaturesCount - campaignSummary.DuplicateSignatureCount}");

            return new CsvReport
            {
                Report = sb.ToString()
            };
        }

        [HttpGet("{mainCampaignId}/precinct-walksheets-csv")]
        public async Task<ActionResult<CsvReport>> GetPrecinctWalkSheetsCsvAsync(long mainCampaignId,
            // URI Query parameters
            string county,
            string city,
            string ward,
            string precinct)
        {
            return new CsvReport
            {
                Report = AtlasController.CreateCsvWalkSheet(await this.GetPrecinctWalkSheetVotersAsync(mainCampaignId, county, city, ward, precinct))
            };
        }

        [HttpGet("{mainCampaignId}/precinct-walksheets-pdf")]
        public async Task<ActionResult<PdfReport>> GetPrecinctWalkSheetsPdfAsync(long mainCampaignId,
            // URI Query parameters
            string county,
            string city,
            string ward,
            string precinct)
        {
            var voters = await this.GetPrecinctWalkSheetVotersAsync(mainCampaignId, county, city, ward, precinct);
            return await this._pdfWalkSheetGenerator.GenerateWalkSheetAsync(voters);
        }

        [HttpPost("{mainCampaignId}/map-walksheets-csv")]
        public async Task<ActionResult<CsvReport>> GetMapWalkSheetsCsvAsync(long mainCampaignId, List<GeoCoordinate> geoCoordinates)
        {
            if (!(await this.DoesMainCampaignUseMapWalkSheetsAsync(mainCampaignId)))
            {
                return this.BadRequest();
            }

            return new CsvReport
            {
                Report = AtlasController.CreateCsvWalkSheet(await this.GetMapWalkSheetVotersAsync(mainCampaignId, geoCoordinates))
            };
        }

        [HttpPost("{mainCampaignId}/map-walksheets-pdf")]
        public async Task<ActionResult<PdfReport>> GetMapWalkSheetsPdfAsync(long mainCampaignId, List<GeoCoordinate> geoCoordinates)
        {
            if (!(await this.DoesMainCampaignUseMapWalkSheetsAsync(mainCampaignId)))
            {
                return this.BadRequest();
            }

            var voters = await this.GetMapWalkSheetVotersAsync(mainCampaignId, geoCoordinates);
            return await this._pdfWalkSheetGenerator.GenerateWalkSheetAsync(voters);
        }

        #endregion

        public async Task<Campaign> GetCampaignAsync(long id)
        {
            return await this._repository.GetCampaignAsync(id);
        }

        private async Task<Campaign> GetCampaignWithPetitionSheetsAsync(long id)
        {
            return await this._repository.GetCampaignWithPetitionSheetsAsync(id);
        }

        private async Task<Campaign> GetCampaignWithPetitionSheetsAndLinesAsync(long id)
        {
            return await this._repository.GetCampaignWithPetitionSheetsAndLinesAsync(id);
        }

        private async Task<Campaign> GetCampaignWithCheckedPetitionSheetsAndLinesAsync(long id)
        {
            var campaign = await this.GetCampaignWithPetitionSheetsAndLinesAsync(id);
            campaign.PetitionSheets = AtlasController.GetCheckedPetitionSheets(campaign);
            return campaign;
        }

        private async Task<List<SheetLineResponse>> GetConfirmedVoterLinesAsync(long campaignId)
        {
            var campaign = await this.GetCampaignWithCheckedPetitionSheetsAndLinesAsync(campaignId);
            return campaign?.PetitionSheets
                .SelectMany(s => s.Lines
                    .Where(l => l.Status == LineStatus.ConfirmedVoter)
                    .Select(l => new SheetLineResponse(l, s, campaign.Name)))
                .ToList();
        }

        private static ICollection<PetitionSheet> GetCheckedPetitionSheets(Campaign campaign)
        {
            return campaign.PetitionSheets.Where(s => s.SheetNumber.HasValue).ToList();
        }

        private static double CalculatePercentage(int currentCount, int totalCount)
        {
            return totalCount == 0 ? 0.0 : currentCount * 100.0 / totalCount;
        }

        private static List<IGrouping<string, SheetLineResponse>> GetConfirmedSignatureLinesByVoterAsync(Campaign mainCampaign)
        {
            var confirmedSignatureLines = new List<SheetLineResponse>();
            foreach (var campaign in mainCampaign.SubCampaigns)
            {
                confirmedSignatureLines.AddRange(campaign?.PetitionSheets
                                                     .SelectMany(s => s.Lines
                                                         .Where(l => l.Status == LineStatus.ConfirmedVoter)
                                                         .Select(l => new SheetLineResponse(l, s, campaign.Name)))
                                                     .ToList() ?? new List<SheetLineResponse>());
            }

            return confirmedSignatureLines.GroupBy(l => l.VoterRegistrationId).ToList();
        }

        private async Task<CampaignSummary> GetCampaignSummaryAsync(long mainCampaignId, long summaryCampaignId)
        {
            var mainCampaign = await this._repository.GetMainCampaignWithAllSheetInfoAsync(mainCampaignId);
            var summaryCampaign = mainCampaign?.SubCampaigns.FirstOrDefault(c => c.Id == summaryCampaignId);
            if (summaryCampaign == null)
            {
                return null;
            }

            // Calculate statistics
            var reviewedSignaturesCount = 0;
            var confirmedSignaturesCount = 0;
            var notFoundSignaturesCount = 0;
            var crossedOffSignaturesCount = 0;
            var blankSignaturesCount = 0;
            var invalidSignaturesCount = 0;

            var signatureCountIncrementByStatus = new Dictionary<LineStatus, Action>
            {
                {LineStatus.ConfirmedVoter, () => confirmedSignaturesCount++ },
                {LineStatus.VoterNotFound, () => notFoundSignaturesCount++ },
                {LineStatus.LineCrossedOff, () => crossedOffSignaturesCount++ },
                {LineStatus.LineBlank, () => blankSignaturesCount++ },
                {LineStatus.LineInvalid, () => invalidSignaturesCount++ }
            };

            var reviewedSheetNumbers = new List<long>();
            var unreviewedSheetIds = new List<long>();
            var nonObjectionValidatedSignatures = new List<SheetLine>();
            var validatedSignaturesCount = 0;
            var objectionValidatedSignaturesCount = 0;
            var objectionSheetsCount = 0;
            foreach (var sheet in summaryCampaign.PetitionSheets)
            {
                if (sheet.SheetNumber == null)
                {
                    unreviewedSheetIds.Add(sheet.Id);
                    continue;
                }

                reviewedSheetNumbers.Add((long)sheet.SheetNumber);
                var sheetValidatedSignatures = new List<SheetLine>();
                foreach (var line in sheet.Lines)
                {
                    if (!signatureCountIncrementByStatus.TryGetValue(line.Status, out var incrementAction))
                    {
                        continue;
                    }

                    incrementAction();
                    reviewedSignaturesCount++;

                    if (line.SignatureValidation == SignatureValidation.Valid)
                    {
                        sheetValidatedSignatures.Add(line);
                    }
                }

                validatedSignaturesCount += sheetValidatedSignatures.Count;

                var sheetObjections = sheet.Objections;
                if (sheetObjections.Any())
                {
                    objectionValidatedSignaturesCount += sheetValidatedSignatures.Count;
                    objectionSheetsCount++;
                }
                else
                {
                    nonObjectionValidatedSignatures.AddRange(sheetValidatedSignatures);
                }
            }

            var signatureLinesByVoter = AtlasController.GetConfirmedSignatureLinesByVoterAsync(mainCampaign);
            var nonObjectedOrDuplicatedSignaturesCount = 0;
            var duplicatedSignatureCount = 0;
            if (signatureLinesByVoter != null)
            {
                foreach (var signature in nonObjectionValidatedSignatures)
                {
                    var voterSignatures = signatureLinesByVoter.First(s => s.Key == signature.Voter.RegistrationId).ToList();
                    if (voterSignatures.Count == 1)
                    {
                        nonObjectedOrDuplicatedSignaturesCount++;
                        continue;
                    }

                    var owningCampaignName = voterSignatures.OrderBy(v => v.Date).First().CampaignName;
                    if (owningCampaignName == summaryCampaign.Name)
                    {
                        nonObjectedOrDuplicatedSignaturesCount++;
                    }
                    else
                    {
                        duplicatedSignatureCount++;
                    }
                }
            }

            var reviewedSheetPercentage = AtlasController.CalculatePercentage(reviewedSheetNumbers.Count, summaryCampaign.PetitionSheets.Count);
            
            return new CampaignSummary
            {
                UploadedSheetCount = summaryCampaign.PetitionSheets.Count,
                ReviewedSheetCount = reviewedSheetNumbers.Count,
                ObjectionSheetCount = objectionSheetsCount,
                ReviewedSignaturesCount = reviewedSignaturesCount,
                ValidSignaturesCount = confirmedSignaturesCount,
                ApproximateTotalSignaturesCount = reviewedSignaturesCount == 0 ? 0 : (int)Math.Round((double)confirmedSignaturesCount / reviewedSignaturesCount * summaryCampaign.PetitionSheets.Count * summaryCampaign.PetitionSheetLineCount),
                ReviewedSheetPercentage = reviewedSheetPercentage,
                UnreviewedSheetPercentage = 100 - reviewedSheetPercentage,
                ValidSignaturesPercentage = AtlasController.CalculatePercentage(confirmedSignaturesCount, reviewedSignaturesCount),
                NotFoundSignaturesCount = notFoundSignaturesCount,
                CrossedOffSignaturesCount = crossedOffSignaturesCount,
                BlankSignaturesCount = blankSignaturesCount,
                InvalidSignaturesCount = invalidSignaturesCount,
                TotalValidatedSignaturesCount = validatedSignaturesCount,
                ObjectionSheetsValidatedSignaturesCount = objectionValidatedSignaturesCount,
                DuplicateSignatureCount = duplicatedSignatureCount,
                NonObjectedOrDuplicateValidatedSignaturesCount = nonObjectedOrDuplicatedSignaturesCount,
                ReviewedSheetNumbers = reviewedSheetNumbers,
                UnreviewedSheetIds = unreviewedSheetIds,
                UsesMapWalkSheets = mainCampaign.UsesMapWalkSheets,
                UsesPrecinctWalkSheets = mainCampaign.UsesPrecinctWalkSheets
            };
        }

        private static long GetNewLowestPriorityReviewNumberAsync(ICollection<PetitionSheet> petitionSheets)
        {
            return (petitionSheets.Any() ? petitionSheets.Max(s => s.ReviewPriorityNumber) : 0) + 1;
        }

        private async Task<List<List<VoterSearchResponse>>> GetPrecinctWalkSheetVotersAsync(long mainCampaignId, string county, string city, string ward, string precinct)
        {
            var precinctVoters = await this._repository.GetPrecinctVotersAsync(mainCampaignId, county, city, ward, precinct);
            var votersByStreet = precinctVoters.GroupBy(v => v.ExtractStreetNameFromAddress());

            return votersByStreet.Select(AtlasController.CreateStreetWalkRoute).ToList();
        }

        private async Task<List<List<VoterSearchResponse>>> GetMapWalkSheetVotersAsync(long mainCampaignId, IList<GeoCoordinate> coordinates)
        {
            const int MinimumCoordinateCountForValidMap = 3;
            var walkSheetVoters = new List<List<VoterSearchResponse>>();
            if (coordinates.Count < MinimumCoordinateCountForValidMap)
            {
                return walkSheetVoters;
            }

            var coordinateRegion = new GeoCoordinateRegion(coordinates);
            var votersByStreet = new Dictionary<string, List<Voter>>();
            var voters = await this._repository.GetCampaignVotersAsync(mainCampaignId);
            foreach (var voter in voters)
            {
                if (!coordinateRegion.ContainsPoint(new GeoCoordinate(voter.Latitude, voter.Longitude)))
                {
                    continue;
                }

                var streetName = voter.ExtractStreetNameFromAddress();
                if (votersByStreet.TryGetValue(streetName, out var streetVoters))
                {
                    streetVoters.Add(voter);
                }
                else
                {
                    votersByStreet[streetName] = new List<Voter> { voter };
                }
            }

            foreach (var streetVoters in votersByStreet)
            {
                walkSheetVoters.Add(AtlasController.CreateStreetWalkRoute(streetVoters.Value));
            }

            return walkSheetVoters;
        }

        private static List<VoterSearchResponse> CreateStreetWalkRoute(IEnumerable<Voter> voters)
        {
            var evenVoters = new List<VoterSearchResponse>();
            var oddVoters = new List<VoterSearchResponse>();

            var orderedVoters = voters.Select(v => new { StreetNumberDigits = v.ConvertStreetNumberToInt(), Voter = v}).Where(v => v.StreetNumberDigits >= 0).OrderBy(v => v.StreetNumberDigits);
            foreach (var orderedVoter in orderedVoters)
            {
                var voter = orderedVoter.Voter;
                var searchResponse = new VoterSearchResponse(voter.Id, voter.RegistrationId, voter.FirstName, voter.LastName, voter.StreetNumber, voter.StreetNameAndUnit, voter.City, voter.Zip);
                if (orderedVoter.StreetNumberDigits % 2 == 0)
                {
                    evenVoters.Add(searchResponse);
                }
                else
                {
                    oddVoters.Add(searchResponse);
                }
            }

            oddVoters.Reverse(); // Odd street numbers count down
            return evenVoters.Concat(oddVoters).ToList();
        }

        private static string CreateCsvWalkSheet(IEnumerable<List<VoterSearchResponse>> walkSheetVoters)
        {
            var sb = new StringBuilder("NH = Not Home,IN = Inaccessible,RF = Refused,,Support 1 = Supports Opponent, Support 3 = Undecided, Support 5 = Supports Candidate");
            sb.AppendLine();
            sb.AppendLine();
            sb.Append("VoterID,Name,Address,Result (NH/IN/RF),Signature (Y/N),Support (1-5),Notes for Campaign");
            foreach (var streetVoters in walkSheetVoters)
            {
                foreach (var voter in streetVoters)
                {
                    sb.AppendLine();
                    sb.Append($"{voter.RegistrationId},{voter.FullName},{voter.FullAddress},,,,");
                }
            }

            return sb.ToString();
        }

        private async Task<bool> DoesMainCampaignUseMapWalkSheetsAsync(long mainCampaignId)
        {
            var mainCampaign = await this.GetCampaignAsync(mainCampaignId);
            return mainCampaign != null && mainCampaign.UsesMapWalkSheets;
        }
    }
}
