﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddMainCampaignAndRegistrationIDVoterIndex : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_RegistrationId",
                table: "Voters",
                columns: new[] { "MainCampaignId", "RegistrationId" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_RegistrationId",
                table: "Voters");
        }
    }
}
