﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AllowForMultipleObjectionsPerSheet : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Objection",
                table: "PetitionSheets");

            migrationBuilder.CreateTable(
                name: "SheetObjections",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    PetitionSheetId = table.Column<long>(nullable: false),
                    Objection = table.Column<int>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SheetObjections", x => x.Id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "SheetObjections");

            migrationBuilder.AddColumn<int>(
                name: "Objection",
                table: "PetitionSheets",
                nullable: false,
                defaultValue: 0);
        }
    }
}
