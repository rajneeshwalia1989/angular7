﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class ReplaceVoterNameForSheetLinesToRegistrationId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "VoterName",
                table: "SheetLines",
                newName: "VoterRegistrationId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "VoterRegistrationId",
                table: "SheetLines",
                newName: "VoterName");
        }
    }
}
