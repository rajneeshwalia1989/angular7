﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddVoterCityAndCounty : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "City",
                table: "Voters",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "County",
                table: "Voters",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "City",
                table: "Voters");

            migrationBuilder.DropColumn(
                name: "County",
                table: "Voters");
        }
    }
}
