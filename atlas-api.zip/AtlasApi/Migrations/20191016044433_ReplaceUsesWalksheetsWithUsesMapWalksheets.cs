﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class ReplaceUsesWalksheetsWithUsesMapWalksheets : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UsesWalkSheets",
                table: "Campaigns",
                newName: "UsesMapWalkSheets");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "UsesMapWalkSheets",
                table: "Campaigns",
                newName: "UsesWalkSheets");
        }
    }
}
