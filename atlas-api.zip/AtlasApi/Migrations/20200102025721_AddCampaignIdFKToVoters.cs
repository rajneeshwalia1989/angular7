﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddCampaignIdFKToVoters : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_RegistrationId",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_StreetNameAndUnit",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_LastName_FirstName",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_County_City_Ward_Precinct",
                table: "Voters");

            migrationBuilder.AlterColumn<long>(
                name: "MainCampaignId",
                table: "Voters",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.CreateIndex(
                name: "IX_Voters_RegistrationId",
                table: "Voters",
                column: "RegistrationId");

            migrationBuilder.CreateIndex(
                name: "IX_Voters_StreetNameAndUnit",
                table: "Voters",
                column: "StreetNameAndUnit");

            migrationBuilder.CreateIndex(
                name: "IX_Voters_StreetNumber",
                table: "Voters",
                column: "StreetNumber");

            migrationBuilder.CreateIndex(
                name: "IX_Voters_LastName_FirstName",
                table: "Voters",
                columns: new[] { "LastName", "FirstName" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_County_City_Ward_Precinct",
                table: "Voters",
                columns: new[] { "County", "City", "Ward", "Precinct" });

            migrationBuilder.AddForeignKey(
                name: "FK_Voters_Campaigns_MainCampaignId",
                table: "Voters",
                column: "MainCampaignId",
                principalTable: "Campaigns",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Voters_Campaigns_MainCampaignId",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_RegistrationId",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_StreetNameAndUnit",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_StreetNumber",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_LastName_FirstName",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_County_City_Ward_Precinct",
                table: "Voters");

            migrationBuilder.AlterColumn<long>(
                name: "MainCampaignId",
                table: "Voters",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_RegistrationId",
                table: "Voters",
                columns: new[] { "MainCampaignId", "RegistrationId" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_StreetNameAndUnit",
                table: "Voters",
                columns: new[] { "MainCampaignId", "StreetNameAndUnit" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber",
                table: "Voters",
                columns: new[] { "MainCampaignId", "StreetNumber" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_LastName_FirstName",
                table: "Voters",
                columns: new[] { "MainCampaignId", "LastName", "FirstName" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_County_City_Ward_Precinct",
                table: "Voters",
                columns: new[] { "MainCampaignId", "County", "City", "Ward", "Precinct" });
        }
    }
}
