﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class DropRegistrationIdFromSheetLine : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_RegistrationId",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber_StreetNameAndUnit_LastName_FirstName",
                table: "Voters");

            migrationBuilder.DropColumn(
                name: "VoterRegistrationId",
                table: "SheetLines");

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId",
                table: "Voters",
                column: "MainCampaignId");

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_StreetNameAndUnit",
                table: "Voters",
                columns: new[] { "MainCampaignId", "StreetNameAndUnit" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber",
                table: "Voters",
                columns: new[] { "MainCampaignId", "StreetNumber" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_LastName_FirstName",
                table: "Voters",
                columns: new[] { "MainCampaignId", "LastName", "FirstName" });

            migrationBuilder.CreateIndex(
                name: "IX_SheetLines_Status",
                table: "SheetLines",
                column: "Status");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_StreetNameAndUnit",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_LastName_FirstName",
                table: "Voters");

            migrationBuilder.DropIndex(
                name: "IX_SheetLines_Status",
                table: "SheetLines");

            migrationBuilder.AddColumn<string>(
                name: "VoterRegistrationId",
                table: "SheetLines",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_RegistrationId",
                table: "Voters",
                columns: new[] { "MainCampaignId", "RegistrationId" });

            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber_StreetNameAndUnit_LastName_FirstName",
                table: "Voters",
                columns: new[] { "MainCampaignId", "StreetNumber", "StreetNameAndUnit", "LastName", "FirstName" });
        }
    }
}
