﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddPetitionSheetVoterSearchIndex : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber_StreetNameAndUnit_LastName_FirstName",
                table: "Voters",
                columns: new[] { "MainCampaignId", "StreetNumber", "StreetNameAndUnit", "LastName", "FirstName" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_StreetNumber_StreetNameAndUnit_LastName_FirstName",
                table: "Voters");
        }
    }
}
