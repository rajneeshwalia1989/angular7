﻿using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class RemoveUnnecessaryVoterColumns : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "PastVoteInfo");

            migrationBuilder.DropColumn(
                name: "BirthYear",
                table: "Voters");

            migrationBuilder.DropColumn(
                name: "Gender",
                table: "Voters");

            migrationBuilder.DropColumn(
                name: "Status",
                table: "Voters");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BirthYear",
                table: "Voters",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Gender",
                table: "Voters",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Status",
                table: "Voters",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "PastVoteInfo",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Date = table.Column<string>(nullable: true),
                    HowVoted = table.Column<string>(nullable: true),
                    Party = table.Column<string>(nullable: true),
                    VoterId = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PastVoteInfo", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PastVoteInfo_Voters_VoterId",
                        column: x => x.VoterId,
                        principalTable: "Voters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PastVoteInfo_VoterId",
                table: "PastVoteInfo",
                column: "VoterId");
        }
    }
}
