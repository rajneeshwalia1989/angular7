﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddCampaignIdFKToUsers : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "MainCampaignId",
                table: "Users",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.CreateIndex(
                name: "IX_Users_MainCampaignId",
                table: "Users",
                column: "MainCampaignId");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Campaigns_MainCampaignId",
                table: "Users",
                column: "MainCampaignId",
                principalTable: "Campaigns",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_Campaigns_MainCampaignId",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_MainCampaignId",
                table: "Users");

            migrationBuilder.AlterColumn<long>(
                name: "MainCampaignId",
                table: "Users",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldNullable: true);
        }
    }
}
