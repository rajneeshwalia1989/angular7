﻿using System;
using Microsoft.EntityFrameworkCore.Metadata;
using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class CreateAtlasDB : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Campaigns",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Name = table.Column<string>(nullable: true),
                    MainCampaignId = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Campaigns", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PetitionSheets",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    CampaignId = table.Column<long>(nullable: false),
                    SheetNumber = table.Column<long>(nullable: true),
                    Notes = table.Column<string>(nullable: true),
                    Circulator = table.Column<string>(nullable: true),
                    Notary = table.Column<string>(nullable: true),
                    Date = table.Column<string>(nullable: true),
                    Objection = table.Column<int>(nullable: false),
                    HasBeenUpdated = table.Column<bool>(nullable: false),
                    Image = table.Column<byte[]>(nullable: true),
                    ReviewPriorityNumber = table.Column<long>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PetitionSheets", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SheetLines",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    SheetId = table.Column<long>(nullable: false),
                    LineNumber = table.Column<long>(nullable: false),
                    Status = table.Column<int>(nullable: false),
                    VoterName = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SheetLines", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Username = table.Column<string>(nullable: true),
                    Password = table.Column<string>(nullable: true),
                    MainCampaignId = table.Column<long>(nullable: false),
                    IsAdmin = table.Column<bool>(nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Voters",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    MainCampaignId = table.Column<long>(nullable: false),
                    RegistrationId = table.Column<string>(nullable: true),
                    Ward = table.Column<string>(nullable: true),
                    Precinct = table.Column<string>(nullable: true),
                    FedRepDistrict = table.Column<int>(nullable: false),
                    StateSenateDistrict = table.Column<int>(nullable: false),
                    StateRepDistrict = table.Column<string>(nullable: true),
                    JudicialSubcircuit = table.Column<string>(nullable: true),
                    CensusCountyDivision = table.Column<string>(nullable: true),
                    BoardOfReviewDistrict = table.Column<string>(nullable: true),
                    FirstName = table.Column<string>(nullable: true),
                    LastName = table.Column<string>(nullable: true),
                    StreetNumber = table.Column<int>(nullable: false),
                    StreetName = table.Column<string>(nullable: true),
                    Zip = table.Column<string>(nullable: true),
                    Gender = table.Column<string>(nullable: true),
                    BirthYear = table.Column<int>(nullable: false),
                    Status = table.Column<string>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Voters", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "PastVoteInfo",
                columns: table => new
                {
                    Id = table.Column<long>(nullable: false)
                        .Annotation("SqlServer:ValueGenerationStrategy", SqlServerValueGenerationStrategy.IdentityColumn),
                    Date = table.Column<string>(nullable: true),
                    HowVoted = table.Column<string>(nullable: true),
                    Party = table.Column<string>(nullable: true),
                    VoterId = table.Column<long>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_PastVoteInfo", x => x.Id);
                    table.ForeignKey(
                        name: "FK_PastVoteInfo_Voters_VoterId",
                        column: x => x.VoterId,
                        principalTable: "Voters",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_PastVoteInfo_VoterId",
                table: "PastVoteInfo",
                column: "VoterId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Campaigns");

            migrationBuilder.DropTable(
                name: "PastVoteInfo");

            migrationBuilder.DropTable(
                name: "PetitionSheets");

            migrationBuilder.DropTable(
                name: "SheetLines");

            migrationBuilder.DropTable(
                name: "Users");

            migrationBuilder.DropTable(
                name: "Voters");
        }
    }
}
