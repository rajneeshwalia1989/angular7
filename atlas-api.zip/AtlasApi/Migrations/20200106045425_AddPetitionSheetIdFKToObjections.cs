﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddPetitionSheetIdFKToObjections : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "PetitionSheetId",
                table: "SheetObjections",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.CreateIndex(
                name: "IX_SheetObjections_PetitionSheetId",
                table: "SheetObjections",
                column: "PetitionSheetId");

            migrationBuilder.AddForeignKey(
                name: "FK_SheetObjections_PetitionSheets_PetitionSheetId",
                table: "SheetObjections",
                column: "PetitionSheetId",
                principalTable: "PetitionSheets",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SheetObjections_PetitionSheets_PetitionSheetId",
                table: "SheetObjections");

            migrationBuilder.DropIndex(
                name: "IX_SheetObjections_PetitionSheetId",
                table: "SheetObjections");

            migrationBuilder.AlterColumn<long>(
                name: "PetitionSheetId",
                table: "SheetObjections",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldNullable: true);
        }
    }
}
