﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddCampaignIdFKToPetitionSheets : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "CampaignId",
                table: "PetitionSheets",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.CreateIndex(
                name: "IX_PetitionSheets_CampaignId",
                table: "PetitionSheets",
                column: "CampaignId");

            migrationBuilder.AddForeignKey(
                name: "FK_PetitionSheets_Campaigns_CampaignId",
                table: "PetitionSheets",
                column: "CampaignId",
                principalTable: "Campaigns",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_PetitionSheets_Campaigns_CampaignId",
                table: "PetitionSheets");

            migrationBuilder.DropIndex(
                name: "IX_PetitionSheets_CampaignId",
                table: "PetitionSheets");

            migrationBuilder.AlterColumn<long>(
                name: "CampaignId",
                table: "PetitionSheets",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldNullable: true);
        }
    }
}
