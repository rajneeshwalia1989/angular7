﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddPrecinctVoterSearchIndex : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Voters_MainCampaignId_County_City_Ward_Precinct",
                table: "Voters",
                columns: new[] { "MainCampaignId", "County", "City", "Ward", "Precinct" });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropIndex(
                name: "IX_Voters_MainCampaignId_County_City_Ward_Precinct",
                table: "Voters");
        }
    }
}
