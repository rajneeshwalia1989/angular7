﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class SelfReferencingCampaigns : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateIndex(
                name: "IX_Campaigns_MainCampaignId",
                table: "Campaigns",
                column: "MainCampaignId");

            migrationBuilder.AddForeignKey(
                name: "FK_Campaigns_Campaigns_MainCampaignId",
                table: "Campaigns",
                column: "MainCampaignId",
                principalTable: "Campaigns",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Campaigns_Campaigns_MainCampaignId",
                table: "Campaigns");

            migrationBuilder.DropIndex(
                name: "IX_Campaigns_MainCampaignId",
                table: "Campaigns");
        }
    }
}
