﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class VoterDataUploadFKCampaign : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "MainCampaignId",
                table: "VoterDataUploads",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.CreateIndex(
                name: "IX_VoterDataUploads_MainCampaignId",
                table: "VoterDataUploads",
                column: "MainCampaignId");

            migrationBuilder.AddForeignKey(
                name: "FK_VoterDataUploads_Campaigns_MainCampaignId",
                table: "VoterDataUploads",
                column: "MainCampaignId",
                principalTable: "Campaigns",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_VoterDataUploads_Campaigns_MainCampaignId",
                table: "VoterDataUploads");

            migrationBuilder.DropIndex(
                name: "IX_VoterDataUploads_MainCampaignId",
                table: "VoterDataUploads");

            migrationBuilder.AlterColumn<long>(
                name: "MainCampaignId",
                table: "VoterDataUploads",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldNullable: true);
        }
    }
}
