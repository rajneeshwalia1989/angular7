﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class VoterSheetLineRelationship : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<long>(
                name: "VoterId",
                table: "SheetLines",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_SheetLines_VoterId",
                table: "SheetLines",
                column: "VoterId");

            migrationBuilder.AddForeignKey(
                name: "FK_SheetLines_Voters_VoterId",
                table: "SheetLines",
                column: "VoterId",
                principalTable: "Voters",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SheetLines_Voters_VoterId",
                table: "SheetLines");

            migrationBuilder.DropIndex(
                name: "IX_SheetLines_VoterId",
                table: "SheetLines");

            migrationBuilder.DropColumn(
                name: "VoterId",
                table: "SheetLines");
        }
    }
}
