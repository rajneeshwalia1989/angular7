﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace AtlasApi.Migrations
{
    public partial class AddPetitionSheetIdFKToSheetLines : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AlterColumn<long>(
                name: "SheetId",
                table: "SheetLines",
                nullable: true,
                oldClrType: typeof(long),
                oldType: "bigint");

            migrationBuilder.CreateIndex(
                name: "IX_SheetLines_SheetId",
                table: "SheetLines",
                column: "SheetId");

            migrationBuilder.AddForeignKey(
                name: "FK_SheetLines_PetitionSheets_SheetId",
                table: "SheetLines",
                column: "SheetId",
                principalTable: "PetitionSheets",
                principalColumn: "Id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_SheetLines_PetitionSheets_SheetId",
                table: "SheetLines");

            migrationBuilder.DropIndex(
                name: "IX_SheetLines_SheetId",
                table: "SheetLines");

            migrationBuilder.AlterColumn<long>(
                name: "SheetId",
                table: "SheetLines",
                type: "bigint",
                nullable: false,
                oldClrType: typeof(long),
                oldNullable: true);
        }
    }
}
