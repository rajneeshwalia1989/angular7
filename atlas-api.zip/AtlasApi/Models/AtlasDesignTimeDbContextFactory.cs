﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;

namespace AtlasApi.Models
{
    public class AtlasDesignTimeDbContextFactory : IDesignTimeDbContextFactory<AtlasContext>
    {
        public AtlasContext CreateDbContext(string[] args)
        {
            var optionsBuilder = new DbContextOptionsBuilder<AtlasContext>();
            optionsBuilder.UseSqlServer(
                Program.DbConnectionString,
                opts => opts.CommandTimeout((int)TimeSpan.FromMinutes(10).TotalSeconds)
            );

            return new AtlasContext(optionsBuilder.Options);
        }
    }
}