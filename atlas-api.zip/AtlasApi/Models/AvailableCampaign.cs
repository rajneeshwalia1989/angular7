﻿namespace AtlasApi.Models
{
    public class AvailableCampaign
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int PetitionSheetLineCount { get; set; }
    }
}