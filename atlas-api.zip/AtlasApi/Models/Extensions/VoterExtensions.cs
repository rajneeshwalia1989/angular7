﻿using System;
using System.Linq;
using AtlasApi.Models.Data;

namespace AtlasApi.Models.Extensions
{
    public static class VoterExtensions
    {
        public static int ConvertStreetNumberToInt(this Voter voter)
        {
            var trimmedNumberString = voter.StreetNumber.Trim();
            if (string.IsNullOrEmpty(trimmedNumberString))
            {
                return -1;
            }

            var digitString = new string(trimmedNumberString.TakeWhile(char.IsDigit).ToArray());
            return string.IsNullOrEmpty(digitString) ? -1 : int.Parse(digitString);
        }

        // Best attempt at parsing addresses to get the street name. Unfortunately, addresses aren't standardized. Each street name and suffix (and any cases of no suffix) combination
        // will be treated as a unique street for purposes of walk sheets. (Sometimes the same name is shared among avenue, street, court, etc.)
        // 1) Checks for street suffix, if one or more are there, we're all good at getting the street out. This should cover the vast majority of addresses
        // 2) If no street suffix found, checks for a unit designator, if one is found, assumes street name is right before the designator
        // 3) If neither is found, assumes street name is end of the string.
        // Case 3 is the dangerous one, if there is no suffix, and the unit is something non-standard like "2R", the unit will become part of the street. No good way to avoid this.
        public static string ExtractStreetNameFromAddress(this Voter voter)
        {
            var directionEndIndex = voter.StreetNameAndUnit.IndexOf(" ", StringComparison.OrdinalIgnoreCase);
            var direction = voter.StreetNameAndUnit.Substring(0, directionEndIndex).Trim();
            var directionInitial = direction[0].ToString();
            var directionValid = PostalAddressing.CardinalDirections.Contains(directionInitial, StringComparer.OrdinalIgnoreCase);
            var compassPoint = directionValid ? directionInitial : "";
            var streetNameStartIndex = directionValid ? directionEndIndex + 1 : 0;

            string standardSuffix;
            int streetNameEndIndex;
            var splitStreet = voter.StreetNameAndUnit.Split(" ");
            var streetSuffixes = PostalAddressing.StandardAbbreviationByStreetSuffixes.Keys.Intersect(splitStreet, StringComparer.OrdinalIgnoreCase).ToList();

            if (streetSuffixes.Any())
            {
                // There could be a street whose name is a suffix (e.g. Hill Street). So assume the highest index suffix is the desired one, but GARDEN and its variants are tricky.
                // Garden is both a street suffix and a unit designation so if garden exists and is the highest, use the second highest if there is more than one. There will probably
                // be more exceptions as this gets tested more and more. Long story short:  address parsing sucks.
                (string Text, int Index) highestIndexSuffix = ("", 0);
                (string Text, int Index) secondHighestIndexSuffix = ("", 0);
                foreach (var suffix in streetSuffixes)
                {
                    var suffixIndex = voter.StreetNameAndUnit.LastIndexOf(suffix, StringComparison.OrdinalIgnoreCase);
                    if (highestIndexSuffix.Index < suffixIndex)
                    {
                        secondHighestIndexSuffix = highestIndexSuffix;
                        highestIndexSuffix = (suffix, suffixIndex);
                    }
                    else if (secondHighestIndexSuffix.Index < suffixIndex)
                    {
                        secondHighestIndexSuffix = (suffix, suffixIndex);
                    }
                }

                // Check for Garden unit
                var (desiredSuffix, _) = streetSuffixes.Count > 1 && PostalAddressing.IsGardenSuffix(highestIndexSuffix.Text) ? secondHighestIndexSuffix : highestIndexSuffix;
                standardSuffix = PostalAddressing.StandardAbbreviationByStreetSuffixes[desiredSuffix];
                streetNameEndIndex = voter.StreetNameAndUnit.LastIndexOf(desiredSuffix, StringComparison.OrdinalIgnoreCase) - 1;
            }
            else
            {
                standardSuffix = "";

                var unit = PostalAddressing.SecondaryUnitDesignators.Find(u => voter.StreetNameAndUnit.Contains(u, StringComparison.OrdinalIgnoreCase));
                if (string.IsNullOrWhiteSpace(unit))
                {
                    streetNameEndIndex = voter.StreetNameAndUnit.Length - 1;
                }
                else
                {
                    streetNameEndIndex = voter.StreetNameAndUnit.LastIndexOf(unit, StringComparison.OrdinalIgnoreCase) - 1;
                }
            }

            var streetName = voter.StreetNameAndUnit.Substring(streetNameStartIndex, streetNameEndIndex - streetNameStartIndex + 1).Trim();
            return $"{compassPoint} {streetName} {standardSuffix}";
        }
    }
}