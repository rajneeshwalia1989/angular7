﻿using System;

namespace AtlasApi.Models.Extensions
{
    public static class DoubleExtensions
    {
        private const double DefaultEpsilonPrecisionMultiplier = 1E-15;

        public static bool IsNearlyZero(this double value, double epsilonPrecisionMultiplier = DoubleExtensions.DefaultEpsilonPrecisionMultiplier)
        {
            return value.IsNearlyEqual(0, epsilonPrecisionMultiplier);
        }

        public static bool IsNearlyEqual(this double value, double obj, double epsilonPrecisionMultiplier = DoubleExtensions.DefaultEpsilonPrecisionMultiplier)
        {
            var epsilon = Math.Max(Math.Abs(value), Math.Abs(obj)) * epsilonPrecisionMultiplier;
            return Math.Abs(value - obj) <= epsilon;
        }
    }
}