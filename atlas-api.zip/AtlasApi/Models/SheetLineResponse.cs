﻿using AtlasApi.Enums;
using AtlasApi.Models.Data;

namespace AtlasApi.Models
{
    public class SheetLineResponse
    {

        public long Id { get; }
        public long SheetId { get; }
        public long? SheetNumber { get; }
        public long LineNumber { get; }
        public LineStatus Status { get; }
        public SignatureValidation SignatureValidation { get; }

        // Only relevant if status indicates confirmed voter
        public long VoterId { get; }
        public string VoterRegistrationId { get; }
        public string VoterName { get; }
        public string VoterAddress { get; }
        public string VoterCity { get; }
        public string VoterZip { get; }
        public string CampaignName { get; }
        public string Circulator { get; }
        public string Notary { get; }
        public string Date { get; }

        public SheetLineResponse(SheetLine line, PetitionSheet sheet, string campaignName)
        {
            var voterInfo = new SheetLineVoterInfo(line.Voter);
            this.Id = line.Id;
            this.SheetId = line.Sheet.Id;
            this.SheetNumber = sheet.SheetNumber;
            this.LineNumber = line.LineNumber;
            this.Status = line.Status;
            this.SignatureValidation = line.SignatureValidation;
            this.VoterId = voterInfo.Id;
            this.VoterRegistrationId = voterInfo.RegistrationId;
            this.VoterName = voterInfo.Name;
            this.VoterAddress = voterInfo.Address;
            this.VoterCity = voterInfo.City;
            this.VoterZip = voterInfo.Zip;
            this.CampaignName = campaignName;
            this.Circulator = sheet.Circulator;
            this.Notary = sheet.Notary;
            this.Date = sheet.Date;
        }
    }
}