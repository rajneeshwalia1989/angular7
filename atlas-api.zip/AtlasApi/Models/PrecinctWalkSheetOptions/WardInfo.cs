﻿using System.Collections.Generic;
using System.Linq;

namespace AtlasApi.Models.PrecinctWalkSheetOptions
{
    public class WardInfo
    {
        public string Name { get; }
        public List<string> PrecinctNames { get; }

        public WardInfo(string name, IEnumerable<PrecinctWalkSheetVoter> voters)
        {
            this.Name = name;
            this.PrecinctNames = voters.Select(v => v.Precinct).Distinct().ToList();
        }
    }
}