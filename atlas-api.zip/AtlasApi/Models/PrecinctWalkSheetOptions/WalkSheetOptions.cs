﻿using System.Collections.Generic;
using System.Linq;

namespace AtlasApi.Models.PrecinctWalkSheetOptions
{
    public class WalkSheetOptions
    {
        public List<CountyInfo> CountyOptions { get; }

        public WalkSheetOptions()
        {
            this.CountyOptions = new List<CountyInfo>();
        }

        public WalkSheetOptions(IEnumerable<PrecinctWalkSheetVoter> voters)
        {
            this.CountyOptions = new List<CountyInfo>();

            var votersByCounty = voters.GroupBy(v => v.County);
            foreach (var countyVoters in votersByCounty)
            {
                this.CountyOptions.Add(new CountyInfo(countyVoters.Key, countyVoters.ToList()));
            }
        }
    }
}