﻿using System.Collections.Generic;
using System.Linq;

namespace AtlasApi.Models.PrecinctWalkSheetOptions
{
    public class CountyInfo
    {
        public string Name { get; }
        public List<CityInfo> CityOptions { get; }

        public CountyInfo(string name, IEnumerable<PrecinctWalkSheetVoter> voters)
        {
            this.Name = name;
            this.CityOptions = new List<CityInfo>();

            var votersByCity = voters.GroupBy(v => v.City);
            foreach (var cityVoters in votersByCity)
            {
                this.CityOptions.Add(new CityInfo(cityVoters.Key, cityVoters.ToList()));
            }
        }
    }
}