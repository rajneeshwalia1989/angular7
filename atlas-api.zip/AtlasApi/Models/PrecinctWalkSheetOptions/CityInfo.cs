﻿using System.Collections.Generic;
using System.Linq;

namespace AtlasApi.Models.PrecinctWalkSheetOptions
{
    public class CityInfo
    {
        public string Name { get; }
        public List<WardInfo> WardOptions { get; }

        public CityInfo(string name, IEnumerable<PrecinctWalkSheetVoter> voters)
        {
            this.Name = name;
            this.WardOptions = new List<WardInfo>();

            var votersByWard = voters.GroupBy(v => v.Ward);
            foreach (var wardVoters in votersByWard)
            {
                this.WardOptions.Add(new WardInfo(wardVoters.Key, wardVoters.ToList()));
            }
        }
    }
}