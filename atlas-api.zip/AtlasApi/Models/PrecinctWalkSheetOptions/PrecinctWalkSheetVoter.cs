﻿namespace AtlasApi.Models.PrecinctWalkSheetOptions
{
    public class PrecinctWalkSheetVoter
    {
        public string County { get; }
        public string City { get; }
        public string Ward { get; }
        public string Precinct { get; }

        public PrecinctWalkSheetVoter(string county, string city, string ward, string precinct)
        {
            this.County = county;
            this.City = city;
            this.Ward = ward;
            this.Precinct = precinct;
        }
    }
}