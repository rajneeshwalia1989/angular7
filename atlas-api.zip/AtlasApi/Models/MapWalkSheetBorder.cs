﻿namespace AtlasApi.Models
{
    public class MapWalkSheetBorder
    {
        public int StreetNumber { get; set; }
        public char CardinalDirection { get; set; }
    }
}