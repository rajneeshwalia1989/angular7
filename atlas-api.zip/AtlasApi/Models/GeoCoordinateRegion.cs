﻿using System;
using System.Collections.Generic;
using System.Linq;
using AtlasApi.Models.Extensions;

namespace AtlasApi.Models
{
    public class GeoCoordinateRegion
    {
        private const int HalfCircleDegrees = 180;

        private class RegionEdge
        {
            public GeoCoordinate BeginPoint { get; }
            public GeoCoordinate EndPoint { get; }

            public RegionEdge(GeoCoordinate beginPoint, GeoCoordinate endpoint)
            {
                this.BeginPoint = beginPoint;
                this.EndPoint = endpoint;
            }

            public bool ContainsPoint(GeoCoordinate point)
            {
                var edgeLengthLatitude = this.EndPoint.Latitude - this.BeginPoint.Latitude;
                var edgeLengthLongitude = this.EndPoint.Longitude - this.BeginPoint.Longitude;
                var distanceToPointLatitude = point.Latitude - this.BeginPoint.Latitude;
                var distanceToPointLongitude = point.Longitude - this.BeginPoint.Longitude;

                // Check if point is on line
                var crossProduct = distanceToPointLongitude * edgeLengthLatitude - distanceToPointLatitude * edgeLengthLongitude;
                if (!crossProduct.IsNearlyZero())
                {
                    return false;
                }

                // Check if point is between the endpoints
                var dotProduct = distanceToPointLatitude * edgeLengthLatitude + distanceToPointLongitude * edgeLengthLongitude;
                if (dotProduct < 0)
                {
                    return false;
                }

                var lineSquaredLength = edgeLengthLatitude * edgeLengthLatitude + edgeLengthLongitude * edgeLengthLongitude;
                return dotProduct <= lineSquaredLength;
            }
        }

        private class ScanningLineIntersectionEndpoints
        {
            public GeoCoordinate FirstEndpoint { get; } // The opposite end of the first line with intersection point/shared vertex
            public GeoCoordinate SecondEndpoint { get; } // The opposite end of the second line with intersection point/shared vertex

            public bool ArePointsValid => this.FirstEndpoint != null && this.SecondEndpoint != null;

            public ScanningLineIntersectionEndpoints(GeoCoordinate firstEndpoint, GeoCoordinate secondEndpoint)
            {
                this.FirstEndpoint = firstEndpoint;
                this.SecondEndpoint = secondEndpoint;
            }
        }

        private readonly List<RegionEdge> _regionEdges;

        public GeoCoordinateRegion(IList<GeoCoordinate> coordinates)
        {
            var firstCoordinate = coordinates.First();
            if (coordinates.First() != coordinates.Last())
            {
                coordinates.Add(firstCoordinate);
            }

            this._regionEdges = new List<RegionEdge>();
            var previousCoordinate = coordinates[0];
            foreach (var coordinate in coordinates.Skip(1))
            {
                //  If this point is equal to the previous point, skip making it a line
                if (coordinate.Latitude.IsNearlyEqual(previousCoordinate.Latitude) && coordinate.Longitude.IsNearlyEqual(previousCoordinate.Longitude))
                {
                    continue;
                }

                this._regionEdges.Add(new RegionEdge(previousCoordinate, coordinate));
                previousCoordinate = coordinate;
            }
        }

        // This method will work on any region, even non-convex ones (not that it should be an issue here). It uses a basic horizontal ray trace to determine status of a point.
        // Special cases such as a line laying precisely on a ray trace or a ray trace intersecting a region node are handled separately and explicitly.
        public bool ContainsPoint(GeoCoordinate point)
        {
            try
            {
                var intersectionPointsLatitude = new List<double> { double.NegativeInfinity };
                foreach (var edge in this._regionEdges)
                {
                    // If the point is on the line it's in the polygon
                    if (edge.ContainsPoint(point))
                    {
                        return true;
                    }

                    // Calculate the intersection point with region edge
                    double intersectionPointLatitude;  // Ray trace intersection point latitude value
                    if (edge.BeginPoint.Latitude.IsNearlyEqual(edge.EndPoint.Latitude))  //The region line is straight up and down and the trace will intersect it
                    {
                        intersectionPointLatitude = edge.EndPoint.Latitude;
                    }
                    else
                    {
                        var slope = (edge.EndPoint.Longitude - edge.BeginPoint.Longitude) / (edge.EndPoint.Latitude - edge.BeginPoint.Latitude);
                        var sum = -slope * edge.EndPoint.Latitude + edge.EndPoint.Longitude;
                        intersectionPointLatitude = slope.IsNearlyZero() ?  // I.e. Line is parallel to x-axis and won't intersect
                            double.NegativeInfinity : (point.Longitude - sum) / slope;
                    }

                    // Order the vertices
                    var minLatitude = Math.Min(edge.BeginPoint.Latitude, edge.EndPoint.Latitude);
                    var maxLatitude = Math.Max(edge.BeginPoint.Latitude, edge.EndPoint.Latitude);
                    var minLongitude = Math.Min(edge.BeginPoint.Longitude, edge.EndPoint.Longitude);
                    var maxLongitude = Math.Max(edge.BeginPoint.Longitude, edge.EndPoint.Longitude);

                    // Compare to see if the intersection point lies on the line segment of intersection
                    if (intersectionPointLatitude < minLatitude || maxLatitude < intersectionPointLatitude || point.Longitude < minLongitude || maxLongitude < point.Longitude)
                    {
                        continue;
                    }

                    // Check to see if the intersection point is itself a vertex
                    if (intersectionPointLatitude.IsNearlyEqual(edge.BeginPoint.Latitude) && point.Longitude.IsNearlyEqual(edge.BeginPoint.Longitude)
                        || intersectionPointLatitude.IsNearlyEqual(edge.EndPoint.Latitude) && point.Longitude.IsNearlyEqual(edge.EndPoint.Longitude))
                    {
                        var jointPoint = new GeoCoordinate(intersectionPointLatitude, point.Longitude);

                        var intersectionEndpoints = this.DetermineOrientationOfIntersectingSegments(jointPoint);

                        if (!intersectionEndpoints.ArePointsValid || !GeoCoordinateRegion.DoesRayTraceBisectPlane(jointPoint, intersectionEndpoints))
                        {
                            continue;
                        }

                        // In/out scenario
                        intersectionPointsLatitude.Add(intersectionPointLatitude);
                    }
                    else
                    {
                        intersectionPointsLatitude.Add(intersectionPointLatitude);
                    }
                }

                // Sort the intersection point list into ascending order.
                intersectionPointsLatitude.Sort();

                // The lowest value of the intersection points is set to be negative infinity so that it is definitely outside the polygon.
                // Under this condition the point is interior to the polygon if the point lies inside an interval specified by intersect information
                // where the index of this intersection is even and outside if it is odd.
                for (var index = 1; index < intersectionPointsLatitude.Count; index++)
                {
                    if (point.Latitude < intersectionPointsLatitude[index - 1] || intersectionPointsLatitude[index] < point.Latitude)
                    {
                        continue;
                    }

                    if (index % 2 == 0)
                    {
                        return true;
                    }
                }

                return false;
            }
            catch
            {
                return false;
            }
        }

        //This code determines which two lines of the polygonal line set have been intersected at their common vertex by a horizontal scanning line.
        //It accepts the common point of intersection where both polygonal lines and the scanning line have intersected.
        //It returns the other endpoints of the two polygonal lines involved in this intersection.
        private ScanningLineIntersectionEndpoints DetermineOrientationOfIntersectingSegments(GeoCoordinate jointPoint)
        {
            GeoCoordinate firstLineEndpoint = null;
            GeoCoordinate secondLineEndpoint = null;

            foreach (var line in this._regionEdges)
            {
                if (line.BeginPoint.Latitude.IsNearlyEqual(jointPoint.Latitude) && line.BeginPoint.Longitude.IsNearlyEqual(jointPoint.Longitude))
                {
                    secondLineEndpoint = new GeoCoordinate(line.EndPoint.Latitude, line.EndPoint.Longitude);
                }

                if (!line.EndPoint.Latitude.IsNearlyEqual(jointPoint.Latitude) || !line.EndPoint.Longitude.IsNearlyEqual(jointPoint.Longitude))
                {
                    continue;
                }

                firstLineEndpoint = new GeoCoordinate(line.BeginPoint.Latitude, line.BeginPoint.Longitude);
            }

            return new ScanningLineIntersectionEndpoints(firstLineEndpoint, secondLineEndpoint);
        }

        // Determines the angle of two lines that share a common vertex relative to the horizontal line passing through that common vertex.
        // Inputs are the endpoints of the two lines.  Using the angle of the first line and the angle of the second line it determines
        // whether the horizontal line passing through the lines common vertex divides the plane between the two lines.
        private static bool DoesRayTraceBisectPlane(GeoCoordinate commonPoint, ScanningLineIntersectionEndpoints endpoints)
        {
            var firstLineAngle = GeoCoordinateRegion.CalculateRayTraceAngle(commonPoint, endpoints.FirstEndpoint);
            var secondLineAngle = GeoCoordinateRegion.CalculateRayTraceAngle(commonPoint, endpoints.SecondEndpoint);

            return !firstLineAngle.IsNearlyZero() && firstLineAngle < GeoCoordinateRegion.HalfCircleDegrees && GeoCoordinateRegion.HalfCircleDegrees < secondLineAngle
                   || !secondLineAngle.IsNearlyZero() && GeoCoordinateRegion.HalfCircleDegrees < firstLineAngle && secondLineAngle < GeoCoordinateRegion.HalfCircleDegrees;
        }

        private static double CalculateRayTraceAngle(GeoCoordinate angleVertex, GeoCoordinate lineEndpoint)
        {
            const int OneQuarterCircleDegrees = 90;
            const int ThreeQuarterCircleDegrees = 270;
            const int FullCircleDegrees = 360;

            if (lineEndpoint.Latitude.IsNearlyEqual(angleVertex.Latitude))
            {
                return angleVertex.Longitude <= lineEndpoint.Longitude ? ThreeQuarterCircleDegrees : OneQuarterCircleDegrees;
            }

            var tempAngle = Math.Abs(Math.Atan((lineEndpoint.Longitude - angleVertex.Longitude) / (lineEndpoint.Latitude - angleVertex.Latitude)) * GeoCoordinateRegion.HalfCircleDegrees / Math.PI);

            if (angleVertex.Latitude <= lineEndpoint.Latitude)
            {
                return angleVertex.Longitude < lineEndpoint.Longitude ? FullCircleDegrees - tempAngle : tempAngle;
            }

            if (lineEndpoint.Longitude <= angleVertex.Longitude)
            {
                tempAngle *= -1;
            }

            return GeoCoordinateRegion.HalfCircleDegrees + tempAngle;
        }
    }
}