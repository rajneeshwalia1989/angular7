﻿namespace AtlasApi.Models
{
    public class CsvReport
    {
        public string Report { get; set; }
    }
}