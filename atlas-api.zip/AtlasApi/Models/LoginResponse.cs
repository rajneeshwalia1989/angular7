﻿using System.Collections.Generic;
using AtlasApi.Models.Data;
using AtlasApi.Models.PrecinctWalkSheetOptions;

namespace AtlasApi.Models
{
    public class LoginResponse
    {
        public long Id { get; set; }
        public string Username { get; set; }
        public bool IsAdmin { get; set; }
        public long MainCampaignId { get; set; }
        public string MainCampaignName { get; set; }
        public List<Campaign> Campaigns { get; set; }
        public WalkSheetOptions WalkSheetOptions { get; set; }
    }
}