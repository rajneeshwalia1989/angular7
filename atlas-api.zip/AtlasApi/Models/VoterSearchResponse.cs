﻿namespace AtlasApi.Models
{
    public class VoterSearchResponse
    {
        public long Id { get; }
        public string RegistrationId { get; }
        public string FullName { get; }
        public string FullAddress { get; }
        public string CityStateZip { get; }

        public VoterSearchResponse(long id, string registrationId, string firstName, string lastName, string streetNumber, string streetNameAndUnit, string city, string zip)
        {
            this.Id = id;
            this.RegistrationId = registrationId;
            this.FullName = $"{firstName} {lastName}";
            this.FullAddress = $"{streetNumber} {streetNameAndUnit}";
            this.CityStateZip = $"{city}, IL {zip}";
        }
    }
}