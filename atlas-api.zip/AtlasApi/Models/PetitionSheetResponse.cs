﻿using System.Collections.Generic;
using AtlasApi.Enums;

namespace AtlasApi.Models
{
    public class PetitionSheetResponse
    {
        public long Id { get; set; }
        public long? SheetNumber { get; set; }
        public string Notes { get; set; }
        public string Circulator { get; set; }
        public string Notary { get; set; }
        public string Date { get; set; }
        public List<PetitionObjection> Objections { get; set; }
        public string EncodedImage { get; set; }
        public List<SheetLineResponse> Lines { get; set; }
    }
}