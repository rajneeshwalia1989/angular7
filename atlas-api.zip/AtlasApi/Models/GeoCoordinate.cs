﻿using System;
using AtlasApi.Models.Extensions;

namespace AtlasApi.Models
{
    public class GeoCoordinate : IEquatable<GeoCoordinate>
    {
        public double Latitude { get; }
        public double Longitude { get; }

        public GeoCoordinate(double latitude, double longitude)
        {
            this.Latitude = latitude;
            this.Longitude = longitude;
        }

        public override bool Equals(object obj)
        {
            return this.Equals(obj as GeoCoordinate);
        }

        public bool Equals(GeoCoordinate other)
        {
            if (object.ReferenceEquals(other, null))
            {
                return false;
            }

            if (object.ReferenceEquals(this, other))
            {
                return true;
            }

            if (this.GetType() != other.GetType())
            {
                return false;
            }

            return this.Latitude.IsNearlyEqual(other.Latitude) && this.Longitude.IsNearlyEqual(other.Longitude);
        }

        public override int GetHashCode()
        {
            unchecked
            {
                return (this.Latitude.GetHashCode() * 397) ^ this.Longitude.GetHashCode();
            }
        }

        public static bool operator ==(GeoCoordinate lhs, GeoCoordinate rhs)
        {
            return lhs?.Equals(rhs) ?? object.ReferenceEquals(rhs, null);
        }

        public static bool operator !=(GeoCoordinate lhs, GeoCoordinate rhs)
        {
            return !(lhs == rhs);
        }
    }
}