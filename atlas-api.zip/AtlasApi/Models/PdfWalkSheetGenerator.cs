﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AtlasApi.Interfaces;
using IronPdf;

namespace AtlasApi.Models
{
    public class PdfWalkSheetGenerator : IPdfWalkSheetGenerator
    {
        private const string Header =
@"<head>
    <meta charset='utf-8'>
    <title>PDF Walk Sheet</title>

    <style>
        .walk-sheet {
            line-height: 15px;
            font-family: 'Calibri';
        }	

            .walk-sheet table {
				cellpadding: 0;
				cellspacing: 0;
            }
				.walk-sheet table td {
					white-space: nowrap;
				}				
				
					.walk-sheet table.key tr {
						width: 1195px;	
						font-size: 14px;			
						vertical-align: top;					
						height: 26px;
					}

						.walk-sheet table.key td.not-home {
							width: 156px;
						}

						.walk-sheet table.key td.inacessible {
							width: 164px;
						}

						.walk-sheet table.key td.refused {
							width: 220px;
						}

						.walk-sheet table.key td.opponent {
							padding-left: 45px;
							width: 185px;
						}

						.walk-sheet table.key td.undecided {
							padding-left: 12px;
							width: 179px;
						}

						.walk-sheet table.key td.candidate {
							width: 201px;
						}
				
					.walk-sheet table.main {
						width: 1195px;
						font-size: 15px;
						border-collapse: collapse;
						border-bottom: 1px solid black;
					}

						.walk-sheet table.main tr td {
                            padding-top: 0px;
                            padding-bottom: 0px;
							padding-left: 8px;
							border-left: 1px solid black;
						}
							
						.walk-sheet table.main tr td.personal-info {
							width: 386px;
						}
							
						.walk-sheet table.main tr td.result {
							width: 147px;
						}
							
							.walk-sheet table.main tr td.result table {
								width: 139px;
							}
							
								.walk-sheet table.main tr td.result table td {
									width: 45px;
									padding-left: 0px;
									border: none;
								}
							
						.walk-sheet table.main tr td.signature {
							width: 94px;
						}
							
						.walk-sheet table.main tr td.support {
							width: 230px;
						}
							
							.walk-sheet table.main tr td.support table {
								width: 222px;
							}
							
								.walk-sheet table.main tr td.support table td {
									padding-left: 0px;
									border: none;
								}
							
						.walk-sheet table.main tr td.notes {
							width: 338px;
							border-right: 1px solid black;
						}
						
						.walk-sheet table.main tr.name {
							font-weight: bold;
						}
							
							.walk-sheet table.main tr.name td {
								border-top: 1px solid black;
							}
    </style>
</head>";

        private const string KeyTable =
@"        <table class='key'>
            <tr>
				<td class='not-home'>
					NH = Not Home
				</td>
				
				<td class='inacessible'>
					IN = Inaccessible
				</td>
				
				<td class='refused'>
					RF = Refused
				</td>
				
				<td class='opponent'>
					Support 1 = Supports Opponent
				</td>
				
				<td class='undecided'>
					Support 3 = Undecided
				</td>
				
				<td class='candidate'>
					Support 5 = Supports Candidate
				</td>
            </tr>
        </table>";

        private const string MainTableNameRow =
@"            <tr class='name'>
				<td class='personal-info'>
					{0}
				</td>
				
				<td class='result'>
					Result
				</td>
				
				<td class='signature'>
					Signature
				</td>
				
				<td class='support'>
					Support
				</td>
				
				<td class='notes'>
					Notes for Campaign
				</td>
            </tr>";

        private const string MainTableAddressRow =
@"            <tr>
				<td class='personal-info'>
					{0} {1}
				</td>
				
				<td class='result'>
					<table>
						<td>
							NH
						</td>
						
						<td>
							IN
						</td>
						
						<td>
							RF
						</td>
					</table>
				</td>
				
				<td class='signature'>
					Y
				</td>
				
				<td class='support'>
					<table>
						<td>
							1
						</td>
						
						<td>
							2
						</td>
						
						<td>
							3
						</td>
						
						<td>
							4
						</td>
						
						<td>
							5
						</td>
					</table>
				</td>
				
				<td class='notes' />
            </tr>";

        private const string MainTableIdRow =
@"            <tr>
				<td class='personal-info'>
					{0}
				</td>
				
				<td class='result'>
					<table>
						<td>
							☐
						</td>
						
						<td>
							☐
						</td>
						
						<td>
							☐
						</td>
					</table>
				</td>
				
				<td class='signature'>
					☐
				</td>
				
				<td class='support'>
					<table>
						<td>
							☐
						</td>
						
						<td>
							☐
						</td>
						
						<td>
							☐
						</td>
						
						<td>
							☐
						</td>
						
						<td>
							☐
						</td>
					</table>
				</td>
				
				<td class='notes' />
            </tr>";

        public async Task<PdfReport> GenerateWalkSheetAsync(IReadOnlyCollection<List<VoterSearchResponse>> voters)
        {
            return await Task.Run(() => PdfWalkSheetGenerator.GenerateWalkSheet(voters));
        }

        private static PdfReport GenerateWalkSheet(IReadOnlyCollection<List<VoterSearchResponse>> voters)
        {
            string html;
            if (voters.Any())
            {
                var sb = new StringBuilder();
                sb.AppendLine("<!doctype html>");
                sb.AppendLine("<html>");
                sb.AppendLine(PdfWalkSheetGenerator.Header);

                sb.AppendLine("<body>");

                const int VotersPerSheetMax = 16;
                foreach (var streetVoters in voters)
                {
                    var pageVoterCount = 0;
                    PdfWalkSheetGenerator.BeginPage(sb);

                    foreach (var voter in streetVoters)
                    {
                        sb.AppendLine(string.Format(PdfWalkSheetGenerator.MainTableNameRow, voter.FullName));
                        sb.AppendLine(string.Format(PdfWalkSheetGenerator.MainTableAddressRow, voter.FullAddress, voter.CityStateZip));
                        sb.AppendLine(string.Format(PdfWalkSheetGenerator.MainTableIdRow, voter.RegistrationId));
                        pageVoterCount++;

                        if (pageVoterCount < VotersPerSheetMax)
                        {
                            continue;
                        }

                        PdfWalkSheetGenerator.EndPage(sb);
                        PdfWalkSheetGenerator.BeginPage(sb);
                        pageVoterCount = 0;
                    }

                    PdfWalkSheetGenerator.EndPage(sb);
                }

                sb.AppendLine("</body>");
                sb.AppendLine("</html>");
                html = sb.ToString();
            }
            else
            {
                html = @"<H4>No voters found</H4>";
            }

            var printOptions = new PdfPrintOptions
            {
                DPI = 96,
                PaperOrientation = PdfPrintOptions.PdfPaperOrientation.Landscape,

                // millimeters
                MarginTop = 8,
                MarginRight = 0,
                MarginBottom = 0,
                MarginLeft = 20
            };

            var htmlToPdf = new HtmlToPdf(printOptions);
            var pdf = htmlToPdf.RenderHtmlAsPdf(html);
            if (pdf.PageCount > 1)
            {
                pdf.RemovePage(pdf.PageCount - 1); // Extra page break generates blank page
            }

            var pdfBytes = pdf.BinaryData;
            var convertedPdfString = Convert.ToBase64String(pdfBytes);

            return new PdfReport
            {
                EncodedReport = convertedPdfString
            };
        }

        private static void BeginPage(StringBuilder sb)
        {
            sb.AppendLine("<div style='page-break-after: always;' class='walk-sheet'>");
            sb.AppendLine(PdfWalkSheetGenerator.KeyTable);
            sb.AppendLine("<table class='main'>");
        }

        private static void EndPage(StringBuilder sb)
        {
            sb.AppendLine("</table>");
            sb.AppendLine("</div>");
        }
    }
}