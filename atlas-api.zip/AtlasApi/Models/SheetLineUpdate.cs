﻿using AtlasApi.Enums;

namespace AtlasApi.Models
{
    public class SheetLineUpdate
    {
        public LineStatus Status { get; set; }
        public long VoterId { get; set; }  // Only relevant if status indicates confirmed voter
    }
}