﻿using AtlasApi.Enums;
using AtlasApi.Interfaces;
using AtlasApi.Models.Data;
using AtlasApi.Models.PrecinctWalkSheetOptions;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AtlasApi.Models
{
    // TODO:  Clean up this class. Consider a repository for each domain.
    public class AtlasRepository : IAtlasRepository
    {
        private readonly AtlasContext _context;

        public AtlasRepository(AtlasContext context)
        {
            this._context = context;
        }

        public async Task SaveChangesAsync()
        {
            await this._context.SaveChangesAsync();
        }

        public async Task<Campaign> GetCampaignAsync(long id)
        {
            return await this._context.Campaigns.FindAsync(id);
        }

        public async Task<Campaign> GetCampaignWithPetitionSheetsAsync(long id)
        {
            return await this._context.Campaigns
                .Include(c => c.PetitionSheets)
                .ThenInclude(s => s.Objections)
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task<Campaign> GetCampaignWithPetitionSheetsAndLinesAsync(long id)
        {
            return await this._context.Campaigns
                .Include(c => c.PetitionSheets).ThenInclude(s => s.Objections)
                .Include(c => c.PetitionSheets).ThenInclude(s => s.Lines).ThenInclude(l => l.Voter)
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task<Campaign> GetMainCampaignWithAllSheetInfoAsync(long id)
        {
            return await this._context.Campaigns
                .Include(main => main.SubCampaigns).ThenInclude(sub => sub.PetitionSheets).ThenInclude(sheet => sheet.Objections)
                .Include(main => main.SubCampaigns).ThenInclude(sub => sub.PetitionSheets).ThenInclude(sheet => sheet.Lines).ThenInclude(line => line.Voter)
                .FirstOrDefaultAsync(c => c.Id == id);
        }

        public async Task CreateUserAccountAsync(User user)
        {
            this._context.Users.Add(user);
            await this.SaveChangesAsync();
        }

        public async Task<User> GetUserAsync(long id)
        {
            return await this._context.Users.FindAsync(id);
        }

        public async Task<User> GetUserAsync(Login login)
        {
            return await this._context.Users
                .Include(u => u.MainCampaign)
                .Include(u => u.MainCampaign.SubCampaigns)
                .FirstOrDefaultAsync(u => u.Username == login.Username && u.Password == login.Password);
        }

        public async Task<User> GetUserAsync(string username)
        {
            return await this._context.Users
                .FirstOrDefaultAsync(u => u.Username == username);
        }

        public async Task SaveSubCampaignAsync(Campaign campaign)
        {
            this._context.Campaigns.Add(campaign);
            await this.SaveChangesAsync();
        }

        public async Task SavePetitionSheetAsync(PetitionSheet petitionSheet)
        {
            await this._context.PetitionSheets.AddAsync(petitionSheet);
            await this.SaveChangesAsync();
        }

        public async Task SavePetitionSheetObjectionsAsync(PetitionSheet sheet, IEnumerable<PetitionObjection> objections)
        {
            var sheetObjections = objections.Select(objection => new SheetObjection {PetitionSheet = sheet, Objection = objection}).ToList();
            await this._context.SheetObjections.AddRangeAsync(sheetObjections);
            await this.SaveChangesAsync();
        }

        public async Task DeletePetitionSheetObjectionsAsync(long sheetId)
        {
            this._context.SheetObjections.RemoveRange(this._context.SheetObjections.Where(o => o.PetitionSheet.Id == sheetId));
            await this.SaveChangesAsync();
        }

        public async Task SavePetitionSheetPathAsync(long sheetId, string filePath)
        {
            var sheet = await this._context.PetitionSheets.FindAsync(sheetId);
            if (sheet == null)
            {
                return;
            }

            sheet.Filepath = filePath;
            await this.SaveChangesAsync();
        }

        public async Task AddSheetLinesAsync(IEnumerable<SheetLine> sheetLines)
        {
            await this._context.SheetLines.AddRangeAsync(sheetLines);
            await this.SaveChangesAsync();
        }

        private async Task DeleteSheetLinesAsync(long sheetId)
        {
            this._context.SheetLines.RemoveRange(this._context.SheetLines.Where(l => l.Sheet.Id == sheetId));
            await this.SaveChangesAsync();
        }

        public async Task UpdateCampaignVotersAsync(Campaign mainCampaign, List<Voter> updatedVoters)
        {
            if (!updatedVoters.Any())
            {
                return;
            }

            await this._context.VoterDataUploads.AddAsync(new VoterDataUpload
            {
                MainCampaign = mainCampaign,
                Date = DateTime.UtcNow,
                VoterCount = updatedVoters.Count
            });

            var campaignVoters = this._context.Voters.Where(v => v.MainCampaign == mainCampaign);
            if (await campaignVoters.AnyAsync())
            {
                foreach (var updatedVoter in updatedVoters)
                {
                    var existingVoter = await campaignVoters.FirstOrDefaultAsync(v => v.RegistrationId == updatedVoter.RegistrationId);
                    if (existingVoter == null)
                    {
                        await this._context.Voters.AddAsync(updatedVoter);
                    }
                    else
                    {
                        existingVoter.Update(updatedVoter);
                        this._context.Voters.Update(existingVoter);
                    }
                }
            }
            else
            {
                await this._context.Voters.AddRangeAsync(updatedVoters);
            }

            await this.SaveChangesAsync();
        }

        public async Task DeletePetitionSheetAsync(PetitionSheet sheet)
        {
            await this.DeletePetitionSheetObjectionsAsync(sheet.Id);
            await this.DeleteSheetLinesAsync(sheet.Id);
            this._context.PetitionSheets.Remove(sheet);
            await this.SaveChangesAsync();
        }

        public async Task<Voter> GetVoterAsync(long voterId)
        {
            return await this._context.Voters.FindAsync(voterId);
        }

        public async Task<List<Voter>> GetCampaignVotersAsync(long mainCampaignId)
        {
            return await this._context.Voters.Where(v => v.MainCampaign.Id == mainCampaignId).ToListAsync();
        }

        public async Task<IEnumerable<PrecinctWalkSheetVoter>> GetPrecinctWalkSheetVotersAsync(long mainCampaignId)
        {
            return await this._context.Voters
                .Where(v => v.MainCampaign.Id == mainCampaignId)
                .Select(v => new PrecinctWalkSheetVoter(v.County, v.City, v.Ward, v.Precinct)).ToListAsync();
        }

        public async Task<List<VoterSearchResponse>> SearchVotersAsync(long mainCampaignId, string firstName, string lastName, string streetNumber, string streetName)
        {
            var query = this._context.Voters.Where(v => v.MainCampaign.Id == mainCampaignId);
            if (!string.IsNullOrWhiteSpace(streetNumber))
            {
                query = query.Where(v => EF.Functions.Like(v.StreetNumber, $"{streetNumber}%"));
            }

            if (!string.IsNullOrWhiteSpace(streetName))
            {
                query = query.Where(v => EF.Functions.Like(v.StreetNameAndUnit, $"%{streetName}%"));
            }

            if (!string.IsNullOrWhiteSpace(firstName))
            {
                query = query.Where(v => EF.Functions.Like(v.FirstName, $"{firstName}%"));
            }

            if (!string.IsNullOrWhiteSpace(lastName))
            {
                query = query.Where(v => EF.Functions.Like(v.LastName, $"%{lastName}%"));
            }


            return await query
                .Select(v => new VoterSearchResponse(v.Id, v.RegistrationId, v.FirstName, v.LastName, v.StreetNumber, v.StreetNameAndUnit, v.City, v.Zip))
                .ToListAsync();
        }

        public async Task<List<Voter>> GetPrecinctVotersAsync(long mainCampaignId, string county, string city, string ward, string precinct)
        {
            return await this._context.Voters
                .Where(v => v.MainCampaign.Id == mainCampaignId
                            && EF.Functions.Like(v.County, county)
                            && EF.Functions.Like(v.City, city)
                            && EF.Functions.Like(v.Ward, ward)
                            && EF.Functions.Like(v.Precinct, precinct))
                .ToListAsync();
        }

        public async Task<bool> HasVotersAsync(long mainCampaignId)
        {
            return await this._context.Voters.AnyAsync(v => v.MainCampaign.Id == mainCampaignId);
        }

        public async Task UpdateSignatureValidationAsync(SignatureValidationUpdate signatureValidationUpdate)
        {
            var sheetLine = await this._context.SheetLines.FindAsync(signatureValidationUpdate.SheetLineId);
            if (sheetLine == null)
            {
                return;
            }

            sheetLine.SignatureValidation = signatureValidationUpdate.SignatureValidation;
            await this.SaveChangesAsync();
        }
    }
}