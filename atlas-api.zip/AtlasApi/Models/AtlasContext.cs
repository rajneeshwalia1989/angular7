﻿using AtlasApi.Models.Data;
using Microsoft.EntityFrameworkCore;

namespace AtlasApi.Models
{
    public class AtlasContext : DbContext
    {
        public AtlasContext(DbContextOptions options)
            : base(options)
        {
            // No body
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Voter>()
                .HasIndex(v => new {v.RegistrationId});
            modelBuilder.Entity<Voter>()
                .HasIndex(v => new { v.County, v.City, v.Ward, v.Precinct });
            modelBuilder.Entity<Voter>()
                .HasIndex(v => new {v.StreetNumber});
            modelBuilder.Entity<Voter>()
                .HasIndex(v => new {v.StreetNameAndUnit});
            modelBuilder.Entity<Voter>()
                .HasIndex(v => new {v.LastName, v.FirstName});

            modelBuilder.Entity<SheetLine>()
                .HasIndex(l => l.Status);
        }

        public DbSet<Campaign> Campaigns { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<PetitionSheet> PetitionSheets { get; set; }
        public DbSet<SheetLine> SheetLines { get; set; }
        public DbSet<Voter> Voters { get; set; }
        public DbSet<SheetObjection> SheetObjections { get; set; }
        public DbSet<VoterDataUpload> VoterDataUploads { get; set; }
    }
 }