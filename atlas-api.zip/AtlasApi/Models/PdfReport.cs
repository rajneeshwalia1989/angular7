﻿namespace AtlasApi.Models
{
    public class PdfReport
    {
        public string EncodedReport { get; set; }  // Base64String
    }
}