﻿using AtlasApi.Models.Data;

namespace AtlasApi.Models
{
    public class SheetLineVoterInfo
    {
        public long Id { get; }
        public string RegistrationId { get; }
        public string Name { get; }
        public string Address { get; }
        public string City { get; }
        public string Zip { get; }

        public SheetLineVoterInfo(Voter voter)
        {
            this.Id = voter?.Id ?? 0;
            this.RegistrationId = voter?.RegistrationId ?? "";
            this.Name = voter == null ? "" : $"{voter.FirstName} {voter.LastName}";
            this.Address = voter == null ? "" : $"{voter.StreetNumber} {voter.StreetNameAndUnit}";
            this.City = voter?.City ?? "";
            this.Zip = voter?.Zip ?? "";
        }
    }
}