﻿using AtlasApi.Enums;

namespace AtlasApi.Models
{
    public class SignatureValidationUpdate
    {
        public long SheetLineId { get; set; }
        public SignatureValidation SignatureValidation { get; set; }
    }
}