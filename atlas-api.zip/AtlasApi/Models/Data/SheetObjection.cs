﻿using AtlasApi.Enums;

namespace AtlasApi.Models.Data
{
    public class SheetObjection
    {
        public long Id { get; set; }
        public PetitionObjection Objection { get; set; }
        
        public PetitionSheet PetitionSheet { get; set; }
    }
}