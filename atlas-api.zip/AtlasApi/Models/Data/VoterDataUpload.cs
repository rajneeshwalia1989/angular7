﻿using System;

namespace AtlasApi.Models.Data
{
    public class VoterDataUpload
    {
        public long Id { get; set; }
        public DateTime Date { get; set; }
        public int VoterCount { get; set; }

        public Campaign MainCampaign { get; set; }
    }
}