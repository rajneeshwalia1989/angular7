﻿using AtlasApi.Enums;

namespace AtlasApi.Models.Data
{
    public class SheetLine
    {
        public long Id { get; set; }
        public long LineNumber { get; set; }
        public LineStatus Status { get; set; }

        // Only relevant if status indicates confirmed voter
        public SignatureValidation SignatureValidation { get; set; }

        public PetitionSheet Sheet { get; set; }
        public Voter Voter { get; set; }
    }
}