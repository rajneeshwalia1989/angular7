﻿using System.ComponentModel.DataAnnotations;

namespace AtlasApi.Models.Data
{
    public class Voter
    {
        public long Id { get; set; }

        [Required]
        [MaxLength(50)]
        public string RegistrationId { get; set; }

        [MaxLength(20)]
        public string Ward { get; set; }

        [MaxLength(20)]
        public string Precinct { get; set; }

        public int FedRepDistrict { get; set; }
        public int StateSenateDistrict { get; set; }
        public string StateRepDistrict { get; set; }
        public string JudicialSubcircuit { get; set; }
        public string CensusCountyDivision { get; set; }
        public string BoardOfReviewDistrict { get; set; }

        [MaxLength(100)]
        public string FirstName { get; set; }

        [MaxLength(100)]
        public string LastName { get; set; }

        [MaxLength(50)]
        public string StreetNumber { get; set; }

        [MaxLength(300)]
        public string StreetNameAndUnit { get; set; }

        public string Zip { get; set; }

        [MaxLength(100)]
        public string City { get; set; }

        [MaxLength(100)]
        public string County { get; set; }

        public double Latitude { get; set; }
        public double Longitude { get; set; }

        public Campaign MainCampaign { get; set; }

        public void Update(Voter updatedVoter)
        {
            this.Ward = updatedVoter.Ward;
            this.Precinct = updatedVoter.Precinct;
            this.FedRepDistrict = updatedVoter.FedRepDistrict;
            this.StateSenateDistrict = updatedVoter.StateSenateDistrict;
            this.StateRepDistrict = updatedVoter.StateRepDistrict;
            this.JudicialSubcircuit = updatedVoter.JudicialSubcircuit;
            this.CensusCountyDivision = updatedVoter.CensusCountyDivision;
            this.BoardOfReviewDistrict = updatedVoter.BoardOfReviewDistrict;
            this.FirstName = updatedVoter.FirstName;
            this.LastName = updatedVoter.LastName;
            this.StreetNumber = updatedVoter.StreetNumber;
            this.Zip = updatedVoter.Zip;
            this.City = updatedVoter.City;
            this.County = updatedVoter.County;
            this.Latitude = updatedVoter.Latitude;
            this.Longitude = updatedVoter.Longitude;
        }
    }
}