﻿using System.Collections.Generic;

namespace AtlasApi.Models.Data
{
    public class PetitionSheet
    {
        public long Id { get; set; }
        public long? SheetNumber { get; set; }
        public string Notes { get; set; }
        public string Circulator { get; set; }
        public string Notary { get; set; }
        public string Date { get; set; }
        public string Filepath { get; set; }
        public long ReviewPriorityNumber { get; set; }

        public Campaign Campaign { get; set; }
        public ICollection<SheetObjection> Objections { get; set; }
        public IList<SheetLine> Lines { get; set; }
    }
}