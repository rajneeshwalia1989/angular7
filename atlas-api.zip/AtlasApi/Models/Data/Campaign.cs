﻿using System.Collections.Generic;

namespace AtlasApi.Models.Data
{
    public class Campaign
    {
        public long Id { get; set; }
        public string Name { get; set; }
        public int PetitionSheetLineCount { get; set; }
        public bool UsesMapWalkSheets { get; set; }
        public bool UsesPrecinctWalkSheets { get; set; }

        public long? MainCampaignId { get; set; }
        public Campaign MainCampaign { get; set; }

        public ICollection<Campaign> SubCampaigns { get; set; }
        public ICollection<PetitionSheet> PetitionSheets { get; set; }
    }
}