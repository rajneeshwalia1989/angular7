﻿using System.Collections.Generic;

namespace AtlasApi.Models
{
    public class CampaignDashboardSummary
    {
        public int UploadedSheetCount { get; set; }
        public int ReviewedSheetCount { get; set; }
        public int ReviewedSignatureCount { get; set; }
        public int ValidSignatureCount { get; set; }
        public int ApproximateTotalSignatureCount { get; set; }
        public double ReviewedSheetPercentage { get; set; }
        public double UnreviewedSheetPercentage { get; set; }
        public double ValidSignaturesPercentage { get; set; }
        public double NotFoundSignaturesPercentage { get; set; }
        public double CrossedOffSignaturesPercentage { get; set; }
        public double BlankSignaturesPercentage { get; set; }
        public double InvalidSignaturesPercentage { get; set; }
        public bool HasVoters { get; set; }
        public List<long> ReviewedSheetNumbers { get; set; }
        public List<long> UnreviewedSheetIds { get; set; }
        public bool UsesMapWalkSheets { get; set; }
        public bool UsesPrecinctWalkSheets { get; set; }
    }
}