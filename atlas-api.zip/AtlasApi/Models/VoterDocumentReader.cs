﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AtlasApi.Models.Data;
using GoogleMaps.LocationServices;

namespace AtlasApi.Models
{
    public static class VoterDocumentReader
    {
        private const int RegistrationIdColumnIndex = 0;
        private const int WardColumnIndex = 1;
        private const int PrecinctColumnIndex = 2;
        private const int FedRepDistrictColumnIndex = 3;
        private const int StateSenateDistrictColumnIndex = 4;
        private const int StateRepDistrictColumnIndex = 5;
        private const int JudicialSubcircuitColumnIndex = 6;
        private const int CensusCountyDivisionColumnIndex = 7;
        private const int BoardOfReviewDistrictColumnIndex = 8;
        private const int NameColumnIndex = 9;
        private const int AddressColumnIndex = 10;
        private const int ZipColumnIndex = 11;
        private const int CityColumnIndex = 12;
        private const int CountyColumnIndex = 13;

        public static async Task<List<Voter>> ParseDocumentAsync(Campaign mainCampaign, string csv, bool mainCampaignUsesMapWalkSheets)
        {
            return await Task.Run(() => VoterDocumentReader.ParseDocument(mainCampaign, csv, mainCampaignUsesMapWalkSheets));
        }

        private static List<Voter> ParseDocument(Campaign mainCampaign, string csv, bool usesMapWalkSheets)
        {
            var voters = new List<Voter>();
            var voterLines = csv.Split(Environment.NewLine);

            if (!VoterDocumentReader.IsHeaderValid(voterLines[0]))
            {
                return voters;
            }
                
            foreach (var voterLine in voterLines.Skip(1))
            {
                if (string.IsNullOrWhiteSpace(voterLine))
                {
                    continue;
                }

                var voterInfo = voterLine.Split(',');

                var registrationId = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.RegistrationIdColumnIndex);

                var fullAddress = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.AddressColumnIndex);
                var zip = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.ZipColumnIndex);

                var (firstName, lastName) = VoterDocumentReader.SplitColumnValueAtFirstSpace(voterInfo, VoterDocumentReader.NameColumnIndex);
                var (streetNumber, streetNameAndUnit) = VoterDocumentReader.SplitColumnValueAtFirstSpace(fullAddress);
                var (latitude, longitude) = usesMapWalkSheets ? VoterDocumentReader.GetGeoCoordinates(fullAddress, zip) : (0, 0);

                if (string.IsNullOrWhiteSpace(registrationId) || string.IsNullOrWhiteSpace(streetNumber))
                {
                    continue;
                }

                voters.Add(new Voter
                {
                    RegistrationId = registrationId,
                    Ward = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.WardColumnIndex),
                    Precinct = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.PrecinctColumnIndex),
                    FedRepDistrict = VoterDocumentReader.GetWorksheetIntValue(voterInfo, VoterDocumentReader.FedRepDistrictColumnIndex),
                    StateSenateDistrict = VoterDocumentReader.GetWorksheetIntValue(voterInfo, VoterDocumentReader.StateSenateDistrictColumnIndex),
                    StateRepDistrict = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.StateRepDistrictColumnIndex),
                    JudicialSubcircuit = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.JudicialSubcircuitColumnIndex),
                    CensusCountyDivision = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.CensusCountyDivisionColumnIndex),
                    BoardOfReviewDistrict = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.BoardOfReviewDistrictColumnIndex),
                    FirstName = firstName,
                    LastName = lastName,
                    StreetNumber = streetNumber,
                    StreetNameAndUnit = streetNameAndUnit,
                    Zip = zip,
                    City = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.CityColumnIndex),
                    County = VoterDocumentReader.GetWorksheetStringValue(voterInfo, VoterDocumentReader.CountyColumnIndex),
                    Latitude = latitude,
                    Longitude = longitude,
                    MainCampaign = mainCampaign
                });
            }

            return voters;
        }

        private static bool IsHeaderValid(string header)
        {
            const string DesiredHeader = "voter_reg_num,WRD,PCT,CON,LEG,REP,JUD,CCD,BOR,name,Address,Zip Code,City,County";

            var desiredColumns = DesiredHeader.Split(',');
            var headerColumns = header.Split(',');
            return desiredColumns.Length == headerColumns.Length && !desiredColumns.Where((c, index) => !c.Equals(headerColumns[index].Trim(), StringComparison.OrdinalIgnoreCase)).Any();
        }

        private static (string firstItem, string remainder) SplitColumnValueAtFirstSpace(IReadOnlyList<string> voterInfo, int columnIndex)
        {
            return VoterDocumentReader.SplitColumnValueAtFirstSpace(VoterDocumentReader.GetWorksheetStringValue(voterInfo, columnIndex));
        }

        private static (string firstItem, string remainder) SplitColumnValueAtFirstSpace(string fullValue)
        {
            var firstSpaceIndex = fullValue.IndexOf(' ');
            return firstSpaceIndex < 1 ?
                ("", fullValue)
                : (fullValue.Substring(0, firstSpaceIndex).Trim(), fullValue.Substring(firstSpaceIndex + 1).Trim());
        }

        private static (double latitude, double longitude) GetGeoCoordinates(string fullAddress, string zip)
        {
            var locationService = new GoogleLocationService("AIzaSyD-cmt934iaJw6VZp5iYFwbjBn05UeN-rk");
            var point = locationService.GetLatLongFromAddress($"{fullAddress} {zip}");
            return (point.Latitude, point.Longitude);
        }

        private static string GetWorksheetStringValue(IReadOnlyList<string> voterInfo, int columnIndex)
        {
            var value = voterInfo[columnIndex];
            return value == null ? "" : value.Trim();
        }

        private static int GetWorksheetIntValue(IReadOnlyList<string> voterInfo, int columnIndex)
        {
            return int.TryParse(VoterDocumentReader.GetWorksheetStringValue(voterInfo, columnIndex), out var value) ? value : -1;
        }
    }
}