﻿using System.Collections.Generic;

namespace AtlasApi.Models
{
    public class CampaignSummary
    {
        public int UploadedSheetCount { get; set; }
        public int ReviewedSheetCount { get; set; }
        public int ObjectionSheetCount { get; set; }
        public int ReviewedSignaturesCount { get; set; }
        public int ValidSignaturesCount { get; set; }
        public int ApproximateTotalSignaturesCount { get; set; }
        public double ReviewedSheetPercentage { get; set; }
        public double UnreviewedSheetPercentage { get; set; }
        public double ValidSignaturesPercentage { get; set; }
        public int NotFoundSignaturesCount { get; set; }
        public int CrossedOffSignaturesCount { get; set; }
        public int BlankSignaturesCount { get; set; }
        public int InvalidSignaturesCount { get; set; }
        public int TotalValidatedSignaturesCount { get; set; }
        public int ObjectionSheetsValidatedSignaturesCount { get; set; }
        public int DuplicateSignatureCount { get; set; }
        public int NonObjectedOrDuplicateValidatedSignaturesCount { get; set; }
        public List<long> ReviewedSheetNumbers { get; set; }
        public List<long> UnreviewedSheetIds { get; set; }
        public bool UsesMapWalkSheets { get; set; }
        public bool UsesPrecinctWalkSheets { get; set; }
    }
}