﻿using System.Collections.Generic;
using System.Threading.Tasks;
using AtlasApi.Models;

namespace AtlasApi.Interfaces
{
    public interface IPdfWalkSheetGenerator
    {
        Task<PdfReport> GenerateWalkSheetAsync(IReadOnlyCollection<List<VoterSearchResponse>> voters);
    }
}