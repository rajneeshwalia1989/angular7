﻿using AtlasApi.Enums;
using AtlasApi.Models;
using AtlasApi.Models.Data;
using AtlasApi.Models.PrecinctWalkSheetOptions;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AtlasApi.Interfaces
{
    public interface IAtlasRepository
    {
        Task SaveChangesAsync();
        Task<Campaign> GetCampaignAsync(long id);
        Task<Campaign> GetCampaignWithPetitionSheetsAsync(long id);
        Task<Campaign> GetCampaignWithPetitionSheetsAndLinesAsync(long id);
        Task<Campaign> GetMainCampaignWithAllSheetInfoAsync(long id);
        Task CreateUserAccountAsync(User user);
        Task<User> GetUserAsync(long id);
        Task<User> GetUserAsync(Login login);
        Task<User> GetUserAsync(string username);
        Task SaveSubCampaignAsync(Campaign campaign);
        Task SavePetitionSheetAsync(PetitionSheet petitionSheet);
        Task SavePetitionSheetObjectionsAsync(PetitionSheet sheet, IEnumerable<PetitionObjection> objections);
        Task DeletePetitionSheetObjectionsAsync(long sheetId);
        Task SavePetitionSheetPathAsync(long sheetId, string filePath);
        Task AddSheetLinesAsync(IEnumerable<SheetLine> sheetLines);
        Task UpdateCampaignVotersAsync(Campaign mainCampaign, List<Voter> updatedVoters);
        Task DeletePetitionSheetAsync(PetitionSheet sheet);
        Task<Voter> GetVoterAsync(long voterId);
        Task<List<Voter>> GetCampaignVotersAsync(long mainCampaignId);
        Task<IEnumerable<PrecinctWalkSheetVoter>> GetPrecinctWalkSheetVotersAsync(long mainCampaignId);
        Task<List<VoterSearchResponse>> SearchVotersAsync(long mainCampaignId, string firstName, string lastName, string streetNumber, string streetName);
        Task<List<Voter>> GetPrecinctVotersAsync(long mainCampaignId, string county, string city, string ward, string precinct);
        Task<bool> HasVotersAsync(long mainCampaignId);
        Task UpdateSignatureValidationAsync(SignatureValidationUpdate signatureValidationUpdate);
    }
}