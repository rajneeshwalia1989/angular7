﻿namespace AtlasApi.Enums
{
    public enum LineStatus
    {
        Unreviewed,
        ConfirmedVoter,
        VoterNotFound,
        LineCrossedOff,
        LineBlank,
        LineInvalid
    }
}