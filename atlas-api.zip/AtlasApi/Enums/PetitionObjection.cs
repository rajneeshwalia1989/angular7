﻿namespace AtlasApi.Enums
{
    public enum PetitionObjection
    {
        NotaryDateMissing,
        CirculatorNoNotaryAppearance,
        CirculatorAddressIncomplete,
        CirculatorAffidavitIncomplete,
        NotaryIncomplete,
        CirculatorSignatureMissing,
        CirculatorAddressIncorrect,
        CirculatorSignatureIncorrect,
        CirculatorNotLegallyQualified,
        CirculatorAnotherParty,
        DamagePreventsReading,
        Other
    }
}