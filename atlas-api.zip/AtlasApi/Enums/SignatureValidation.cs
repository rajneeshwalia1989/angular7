﻿namespace AtlasApi.Enums
{
    public enum SignatureValidation
    {
        NotValidated,
        Valid,
        Invalid
    }
}