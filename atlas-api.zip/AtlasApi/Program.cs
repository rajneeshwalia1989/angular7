﻿using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;

namespace AtlasApi
{
    public class Program
    {
        public const string DbConnectionString = @"Server=.\SQLEXPRESS;Database=AtlasDB;Trusted_Connection=True;";

        public static void Main(string[] args)
        {
            Program.CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>();
    }
}
