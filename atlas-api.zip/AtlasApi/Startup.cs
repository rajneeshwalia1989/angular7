﻿using AtlasApi.Interfaces;
using AtlasApi.Models;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Newtonsoft.Json;

namespace AtlasApi
{
    public class Startup
    {
        private const string CorsPolicy = "CorsPolicy";

        public Startup(IConfiguration configuration)
        {
            this.Configuration = configuration;

            IronPdf.License.LicenseKey = "IRONPDF-8435996C00-951065-539E3A-2FBA69D6BF-517504AC-UEx2FF20964C9217D8-EREHWONATLAS.IRO190726.1776.26158.PRO.1DEV.SUPPORTED.UNTIL.27.JUL.2019";
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddCors(options =>
            //{
            //    options.AddPolicy(Startup.CorsAllowedSpecificOriginsPolicy,
            //        builder =>
            //        {
            //            builder.WithOrigins("http://www.erehwonatlas.com/");
            //        });
            //});
            services.AddCors(c =>
            {
                c.AddPolicy(Startup.CorsPolicy, options => options
                    .AllowAnyOrigin()
                    .AllowAnyMethod()
                    .AllowAnyHeader());
            });

            services.AddDbContext<AtlasContext>(options =>
                options.UseSqlServer(Program.DbConnectionString));

            services.AddScoped<IAtlasRepository, AtlasRepository>();
            services.AddScoped<IPdfWalkSheetGenerator, PdfWalkSheetGenerator>();
            
            services.AddControllers().AddNewtonsoftJson(x => x.SerializerSettings.ReferenceLoopHandling = ReferenceLoopHandling.Ignore);
            services.Configure<IISServerOptions>(options =>
            {
                options.AutomaticAuthentication = false;
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseRouting();
            //app.UseCors(Startup.CorsAllowedSpecificOriginsPolicy);
            app.UseCors(Startup.CorsPolicy);

            app.UseHttpsRedirection();

            app.UseEndpoints(endpoints => {
                endpoints.MapControllers();
            });
        }
    }
}
