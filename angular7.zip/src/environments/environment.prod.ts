export const environment = {
  production: true,
  baseURL_local: 'http://localhost:49457/atlas',
  baseURL: 'http://35.208.172.83/atlas'
};
