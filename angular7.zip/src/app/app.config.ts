import { Injectable } from "@angular/core";
import { environment } from "src/environments/environment";

@Injectable({ providedIn: 'root' })
export class AppConfig {
    public baseURL = environment.baseURL;// 'https://localhost:44391/';//atlas';

    constructor(){ }
    
}