import { Injectable } from '@angular/core';
import { HttpEvent, HttpRequest, HttpResponse, HttpInterceptor, HttpHandler } from '@angular/common/http';
//import { Observable } from 'rxjs/Observable';
import { startWith, tap } from 'rxjs/operators';
//import 'rxjs/add/observable/of';
import { Observable, of } from 'rxjs';
import { AuthService } from '../auth.service';

const maxAge = 15000;

@Injectable()
export class CacheInterceptor implements HttpInterceptor {
  cache = new Map();

  constructor(private authService: AuthService) {
  }

  intercept(req: HttpRequest<any>, next: HttpHandler) {
    let cachedResponse = (req.method == "POST"
      || req.method == "DELETE"
      || req.method == "PUT") ? undefined : this.get(req);

    try {
      if (req.method == "POST"
        || req.method == "DELETE"
        || req.method == "PUT") {
        cachedResponse = undefined;
        this.cache.clear();
      }
      else {
        if (req.method == "GET"
          && req.url.toLowerCase().indexOf("sheet-review".toLowerCase()) > -1
          && this.authService.getItemFromLocalStorage('skip-clicked') == null) {
          cachedResponse = this.get(req);
        }
        else {
          cachedResponse = undefined;
          this.authService.removeFromLocalStorage('skip-clicked')
          //this.cache.clear();
        }
        try {
          this.cache.forEach(data => {
            if (data.url.toLowerCase().indexOf("sheet-review".toLowerCase()) < 0) {
              this.cache.delete(data.url)
              console.log(data.method + '-' + data.url)
            }
          });
        } catch (err) { }
      }
    } catch (err) { }

    return cachedResponse ? of(cachedResponse) : this.sendRequest(req, next);
  }

  sendRequest(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(req).pipe(
      tap(event => {
        if (event instanceof HttpResponse) {
          this.put(req, event);
        }
      })
    );
  }

  get(req: HttpRequest<any>): HttpResponse<any> | undefined {
    const url = req.urlWithParams;
    const cached = this.cache.get(url);

    if (!cached) {
      return undefined;
    }

    const isExpired = cached.lastRead < (Date.now() - maxAge);
    const expired = isExpired ? 'expired ' : '';
    return cached.response;
  }

  put(req: HttpRequest<any>, response: HttpResponse<any>): void {
    const url = req.url;
    const entry = {
      url,
      response,
      lastRead: Date.now(),
      body: req.body,
      method: req.method
    };
    this.cache.set(url, entry);

    const expired = Date.now() - maxAge;
    this.cache.forEach(expiredEntry => {
      if (expiredEntry.lastRead < expired) {
        this.cache.delete(expiredEntry.url);
      }
    });
  }
}
