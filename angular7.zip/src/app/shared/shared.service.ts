import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(private http: HttpClient) { }

  downloadCSVFile(data, filename = 'csv') {
    let utcDate = new Date().toString()
    try {
      utcDate = new Date().toJSON();
    } catch (err) { }
    filename = filename + '-' + utcDate + '.csv';
    data = data ? data : 'No Result Found.';

    if (navigator.msSaveBlob) {
      let blob = new Blob([data], {
        "type": "text/csv;charset=utf8;"
      });
      navigator.msSaveBlob(blob, filename);
    }
    else {
      let blob = new Blob(['\ufeff' + data], { type: 'text/csv;charset=utf-8;' });
      let $link = document.createElement("a");
      let url = URL.createObjectURL(blob);
      $link.setAttribute("target", "_blank");
      $link.setAttribute("href", url);
      $link.setAttribute("download", filename);
      $link.style.visibility = "hidden";
      document.body.appendChild($link);
      $link.click();
      document.body.removeChild($link);
    }

  }

  convertbase64toArrayBuffer(base64) {
    var binary_string = window.atob(base64);
    var len = binary_string.length;
    var bytes = new Uint8Array(len);
    for (var i = 0; i < len; i++) {
      bytes[i] = binary_string.charCodeAt(i);
    }
    return bytes.buffer;
  }

  downloadPdfFile(pdf, filename = 'pdf') {
    var byteArr = this.convertbase64toArrayBuffer(pdf);
    let utcDate = new Date().toString()
    try {
      utcDate = new Date().toJSON();
    } catch (err) { }
    filename = filename + '-' + utcDate + '.pdf';
    //var blob = new Blob([byteArr], { type: 'application/pdf' });

    const blob = new Blob([byteArr as BlobPart], { type: 'application/pdf', });


    //FileSaver.saveAs(blob, "filename" + filename);
    let $link = document.createElement("a");
    let url = URL.createObjectURL(blob);
    $link.setAttribute("target", "_blank");
    $link.setAttribute("href", url);
    $link.setAttribute("download", filename);
    $link.style.visibility = "hidden";
    document.body.appendChild($link);
    $link.click();
    document.body.removeChild($link);
  }


  downloadPDF(pdf, filename = 'pdf') {
    // pdf = pdf ? pdf : 'Tm8gUmVzdWx0IEZvdW5kLg==';
    // const linkSource = `data:application/pdf;base64,${pdf}`;
    // const downloadLink = document.createElement("a");
    // const fileName = "vct_illustration.pdf";
    // console.log('linkSource',linkSource)

    // downloadLink.href = linkSource;
    // downloadLink.download = fileName;
    // downloadLink.click();

    let utcDate = new Date().toString()
    try {
      utcDate = new Date().toJSON();
    } catch (err) { }
    filename = filename + '-' + utcDate + '.pdf';

    pdf = pdf ? pdf : 'Tm8gUmVzdWx0IEZvdW5kLg==';

    if (navigator.msSaveBlob) {
      let blob = new Blob([pdf], {
        "type": `data:application/pdf;base64`
      });
      navigator.msSaveBlob(blob, filename);
    }
    else {
      let blob = new Blob(['\ufeff' + pdf], { type: `data:application/pdf;base64,${pdf}` });
      let $link = document.createElement("a");
      let url = URL.createObjectURL(blob);
      $link.setAttribute("target", "_blank");
      $link.setAttribute("href", url);
      $link.setAttribute("download", filename);
      $link.style.visibility = "hidden";
      document.body.appendChild($link);
      $link.click();
      document.body.removeChild($link);

    }
  }


  getPosition(): Observable<Position> {
    return Observable.create(
      (observer) => {
        navigator.geolocation.watchPosition((pos: Position) => {
          observer.next(pos);
        }),
          () => {
            console.log('Position is not available');
          },
          {
            enableHighAccuracy: true
          };
      });
  }
}



