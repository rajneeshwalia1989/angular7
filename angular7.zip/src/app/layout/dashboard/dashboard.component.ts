import { Component, OnInit, ViewChild } from '@angular/core';
import { SidebarComponent } from '../sidebar/sidebar.component';
import { DashboardService } from './dashboard.service';
import { Router, ActivatedRoute } from '@angular/router';
import * as CanvasJS from '../../../assets/canvasjs.min';
import { CanvasChartsComponent } from '../charts/canvas-charts.component';
import { CampaignDashboardSummary } from '../models/campaignDashboardSummary';
import { LoginResult } from '../models/loginResult';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/auth.service';

@Component({
	selector: 'app-dashboard',
	templateUrl: './dashboard.component.html',
	styleUrls: [ './dashboard.component.css' ]
})
export class DashboardComponent implements OnInit {
	// @ViewChild('sidebarComponent') sidebarComponent: SidebarComponent;
	campaignId: number;
	dashboard = new CampaignDashboardSummary();
	pieChartData: number[] = [];
	sheetChecked: number;
	sheetUnchecked: number;
	mainCampaignId: number;
	_currentuser: LoginResult;
	public pieChartOptions: any = {};
	loading: boolean = false;

	constructor(
		private router: Router,
		private service: DashboardService,
		private route: ActivatedRoute,
		private toastr: ToastrService,
		private authService: AuthService
	) {
		// const _campaign = localStorage.getItem('campaignId');
		const _campaign = this.authService.getItemFromLocalStorage('campaignId');
		if (_campaign) {
			this.campaignId = +_campaign;
		}
	}

	ngOnInit() {
		this.route.params.subscribe(
			(params) => {
				this.campaignId = +params.id;
				this._currentuser = this.authService.getItemFromLocalStorage('CurrentUser');
				let campaignName = this.authService.getItemFromLocalStorage('campaignName');
				let mainCampaignId = this._currentuser.mainCampaignId;
				this.loading = true;
				this.toastr.clear();
				this.service
					.GetCampaignSummary<CampaignDashboardSummary>(+mainCampaignId, +this.campaignId)
					.subscribe((response) => {
						this.dashboard = response;
						this.dashboard.mainCampaignName = campaignName;
						this.dashboard.mainCampaignId = +mainCampaignId;
						this.dashboard.campaignId = +this.campaignId;

						// localStorage.removeItem("reviewedSheetNumbers")
						// localStorage.setItem("reviewedSheetNumbers", JSON.stringify(this.dashboard.reviewedSheetNumbers))
						this.authService.removeFromLocalStorage('reviewedSheetNumbers');
						this.authService.setItemToLocalStorage(
							'reviewedSheetNumbers',
							this.dashboard.reviewedSheetNumbers,
							true
						);
						this.authService.removeFromLocalStorage('unreviewedSheetIds');
						this.authService.setItemToLocalStorage(
							'unreviewedSheetIds',
							this.dashboard.unreviewedSheetIds,
							true
						);

						this.loading = false;
						//console.log('dashboard', this.dashboard, response)
					});
			},
			(error) => {
				console.log(error);
				this.loading = false;
			}
		);
	}

	onFormSubmit(dashboard: CampaignDashboardSummary) {
		//console.log(dashboard)
		this.router.navigate([ 'check-sheets', dashboard.campaignId, { sheet: dashboard.sheetNumber } ]);
	}
}
