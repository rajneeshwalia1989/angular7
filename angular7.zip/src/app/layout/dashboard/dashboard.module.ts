import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { DashboardComponent } from './dashboard.component';
import { FormsModule } from '@angular/forms';
import { CanvasChartsComponent } from '../charts/canvas-charts.component';
import { FusionChartsComponent } from '../charts/fusion-charts.component';
import {NgxChartsModule} from '@swimlane/ngx-charts';
//import { FusionChartsModule } from 'angular-fusioncharts';

//Import FusionCharts library
//import * as FusionCharts from 'fusioncharts';

//Load FusionCharts Individual Charts
//import * as Charts from 'fusioncharts/fusioncharts.charts';
 //FusionChartsModule.fcRoot(FusionCharts, Charts)
const routes: Routes = [
  { path: "", component: DashboardComponent, data: { title: "Dashboard" } }
];

@NgModule({
  declarations: [
    DashboardComponent,
    CanvasChartsComponent,
    FusionChartsComponent
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    FormsModule,
    NgxChartsModule
    //ChartsModule,
    //FusionChartsModule
  ],
 schemas: [CUSTOM_ELEMENTS_SCHEMA]


})
export class DashboardModule { }
