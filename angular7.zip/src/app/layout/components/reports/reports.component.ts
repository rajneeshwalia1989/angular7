import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router } from '@angular/router';
import { ReportsService } from './reports.service';
import { LoginResult } from '../../models/loginResult';
import { DomSanitizer } from '@angular/platform-browser';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/auth.service';
import { CSVResponse, CSVData } from '../../models/csv-response';
import { DatePipe } from '@angular/common';
import { Ordinal } from '../../models/enums';
import { SharedService } from 'src/app/shared/shared.service';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.css']
})
export class ReportsComponent implements OnInit {

  _loading: boolean = false;
  _currentUser: LoginResult;
  _campaignId: number;
  _mainCampaignId: number;
  itemsPerPage: number = 10;
  p: number = 1;
  _validSignaturesPdf: any;
  _sheetPdf: any;
  _duplicateSignaturesPdf: any;
  _objectionsPdf: any;
  ordinal = Ordinal;
  CSVResponse: CSVResponse = new CSVResponse();
  iHeader = [];

  constructor(private router: Router, private reportsService: ReportsService, private datePipe: DatePipe,
    public sanitizer: DomSanitizer, private toastr: ToastrService, private authService: AuthService,
    private _sharedService: SharedService) { }

  ngOnInit() {
    // this._currentuser = JSON.parse(localStorage.getItem('CurrentUser'));
    // this._campaignId = +localStorage.getItem('campaignId');
    this._currentUser = this.authService.getItemFromLocalStorage('CurrentUser');
    this._campaignId = +this.authService.getItemFromLocalStorage('campaignId');
    this.validSignaturesCsv(null);

  }

  validSignaturesCsv(element: HTMLElement) {
    this.p = 1
    let hasCollapsed = true;
    if (element)
      if (element.className.endsWith('collapsed')) hasCollapsed = true;
      else hasCollapsed = false;

    if (hasCollapsed) {
      this._loading = true;
      this.toastr.clear()
      this.CSVResponse = this.resetCSVResponse();
      this.reportsService.validSignaturesCsv<any>(this._campaignId)
        .subscribe(response => {
          this.CSVResponse._validSignaturesCsv.fullResponse = response.report;
          let _arrayCSV = response ? response.report.split('\n') : [];

          _arrayCSV.forEach((element, index) => {
            const cols: string[] = element.split(',');
            if (index == 0) this.CSVResponse._validSignaturesCsv.title = cols
            else if (index == 1) this.CSVResponse._validSignaturesCsv.header = cols
            else this.CSVResponse._validSignaturesCsv.cols.push(cols);
          });
          this._loading = false;
        }, error => {
          this._loading = false;
          this.toastr.error('Report not generated.', 'Error!');
        })
    }
  }

  validSignaturesPdf() {
    this._loading = true;
    this.toastr.clear()
    this.reportsService.validSignaturesPdf(this._campaignId)
      .subscribe(response => {
        this._validSignaturesPdf = this.sanitizer.bypassSecurityTrustResourceUrl('data:application/pdf;base64,' + response['encodedReport'] + '#toolbar=1')
        this._loading = false;
      }, error => {
        this._loading = false;
        this.toastr.error('Report not generated.', 'Error!');
      })
  }

  sheetCsv(element: HTMLElement) {
    this.p = 1
    let hasCollapsed = true;
    if (element)
      if (element.className.endsWith('collapsed')) hasCollapsed = true;
      else hasCollapsed = false;
    if (hasCollapsed) {
      //this.TAB.collapseFive =''
      this._loading = true;
      this.CSVResponse = this.resetCSVResponse();
      this.toastr.clear()
      this.reportsService.sheetCsv<any>(this._campaignId)
        .subscribe(response => {
          this.CSVResponse._sheetCsv.fullResponse = response.report;
          let _arrayCSV = response ? response.report.split('\n') : [];

          _arrayCSV.forEach((element, index) => {
            const cols: string[] = element.split(',');
            if (index == 0) this.CSVResponse._sheetCsv.title = cols
            else if (index == 1) this.CSVResponse._sheetCsv.header = cols
            else this.CSVResponse._sheetCsv.cols.push(cols);
          });
          this._loading = false;
        }, error => {
          // this._loading = false;
          this.toastr.error('Report not generated.', 'Error!');
        })
    }
  }

  totalValidSignCsv(element: HTMLElement) {
    this.p = 1
    let hasCollapsed = true;
    if (element)
      if (element.className.endsWith('collapsed')) hasCollapsed = true;
      else hasCollapsed = false;
    if (hasCollapsed) {
      //this.TAB.collapseFive =''
      this._loading = true;
      this.CSVResponse = this.resetCSVResponse();
      this.toastr.clear()
      this.reportsService.totalValidSignCsv<any>(this._currentUser.mainCampaignId, this._campaignId)
        .subscribe(response => {
          this.CSVResponse._totalValidSignatureCsv.fullResponse = response.report;
          let _arrayCSV = response ? response.report.split('\n') : [];

          _arrayCSV.forEach((element, index) => {
            element = element ? element.trim() : "";
            if (element) {
              const cols: string[] = element.split(',');
              if (index == 0) this.CSVResponse._totalValidSignatureCsv.title = cols
              else if (index == 1) this.CSVResponse._totalValidSignatureCsv.header = cols
              else this.CSVResponse._totalValidSignatureCsv.cols.push(cols);
            }
          });
          this._loading = false;
        }, error => {
          // this._loading = false;
          this.toastr.error('Report not generated.', 'Error!');
        })
    }
  }

  resetCSVResponse(): CSVResponse {
    return {
      _duplicateSignaturesCsv: this.clearCSVData(),
      _objectionsCsv: this.clearCSVData(),
      _sheetCsv: this.clearCSVData(),
      _validSignaturesCsv: this.clearCSVData(),
      _totalValidSignatureCsv: this.clearCSVData()
    }
  }

  clearCSVData(): CSVData {
    return { cols: [], header: [], title: [], fullResponse: [] }
  }

  getItem(item, index, type?) {
    let dateIndex = -1;
    switch (type) {
      case '_validSignaturesCsv':
        this.CSVResponse._validSignaturesCsv.header.map((x, i) => { if (x == 'Date') dateIndex = i })
        if (index == dateIndex) return this.datePipe.transform(item, 'MM/dd/yyyy');
        else return item;
        break;
      case '_sheetCsv':
        this.CSVResponse._sheetCsv.header.map((x, i) => { if (x.toString().trim() == 'Date') { dateIndex = i; } })
        if (index == dateIndex) return this.datePipe.transform(item, 'MM/dd/yyyy');
        else return item;
        break;
      case '_totalValidSignatureCsv':
        this.CSVResponse._sheetCsv.header.map((x, i) => { if (x.toString().trim() == 'Date') { dateIndex = i; } })
        if (index == dateIndex) return this.datePipe.transform(item, 'MM/dd/yyyy');
        else return item;
        break;
      case '_duplicateSignaturesCsv':
        if (this.iHeader.length == 0) {
          this.CSVResponse._duplicateSignaturesCsv.header.map((x, i) => {
            if (x == `${this.ordinal.First} Petition Date` ||
              x == `${this.ordinal.Owner} Petition Date` ||
              x == `${this.ordinal.Second} Petition Date` ||
              x == `${this.ordinal.Third} Petition Date` ||
              x == `${this.ordinal.Fourth} Petition Date` ||
              x == `${this.ordinal.Fifth} Petition Date` ||
              x == `${this.ordinal.Sixth} Petition Date` ||
              x == `${this.ordinal.Seventh} Petition Date` ||
              x == `${this.ordinal.Eighth} Petition Date` ||
              x == `${this.ordinal.Ninth} Petition Date` ||
              x == `${this.ordinal.Tenth} Petition Date`) {
              this.iHeader.push(i);
            }
          })
        }
        if (this.iHeader.indexOf(index) > -1) {
          this.iHeader.splice(this.iHeader.indexOf(index), 1);
          return this.datePipe.transform(item, 'MM/dd/yyyy');
        }
        else return item;
        break;
      case '_objectionsCsv':
        this.CSVResponse._objectionsCsv.header.map((x, i) => { if (x == 'Date') dateIndex = i })
        if (index == dateIndex) return this.datePipe.transform(item, 'MM/dd/yyyy');
        else return item;
        break;
        deafult: break;
    }
  }


  sheetPdf() {
    this._loading = true;
    this.toastr.clear()
    this.reportsService.sheetPdf(this._campaignId)
      .subscribe(response => {
        this._sheetPdf = this.sanitizer.bypassSecurityTrustResourceUrl('data:application/pdf;base64,' + response['encodedReport'] + '#toolbar=1')
        this._loading = false;
      }, error => {
        this._loading = false;
        this.toastr.error('Report not generated.', 'Error!');
      })
  }

  duplicateSignaturesCsv(element: HTMLElement) {
    this.p = 1
    let hasCollapsed = true;
    this.iHeader = [];
    if (element)
      if (element.className.endsWith('collapsed')) hasCollapsed = true;
      else hasCollapsed = false;
    if (hasCollapsed) {
      this._loading = true;
      this.CSVResponse = this.resetCSVResponse();
      this.toastr.clear()
      this.reportsService.duplicateSignaturesCsv<any>(this._currentUser.mainCampaignId)
        .subscribe(response => {
          this.CSVResponse._duplicateSignaturesCsv.fullResponse = response.report;
          let _arrayCSV = response ? response.report.split('\n') : [];

          _arrayCSV.forEach((element, index) => {
            const cols: string[] = element.split(',');
            if (index == 0) this.CSVResponse._duplicateSignaturesCsv.title = cols
            else if (index == 1) this.CSVResponse._duplicateSignaturesCsv.header = cols
            else this.CSVResponse._duplicateSignaturesCsv.cols.push(cols);

          });
          this._loading = false;
        }, error => {
          this._loading = false;
          this.toastr.error('Report not generated.', 'Error!');
        })
    }
  }

  duplicateSignaturesPdf() {
    this._loading = true;
    this.toastr.clear()
    this.reportsService.duplicateSignaturesPdf(this._currentUser.mainCampaignId)
      .subscribe(response => {
        this._duplicateSignaturesPdf = this.sanitizer.bypassSecurityTrustResourceUrl('data:application/pdf;base64,' + response['encodedReport'] + '#toolbar=1')
        this._loading = false;
      }, error => {
        this._loading = false;
        this.toastr.error('Report not generated.', 'Error!');
      })
  }

  objectionsCsv(element: HTMLElement) {
    this.p = 1
    let hasCollapsed = true;
    if (element)
      if (element.className.endsWith('collapsed')) hasCollapsed = true;
      else hasCollapsed = false;
    if (hasCollapsed) {
      this._loading = true;
      this.CSVResponse = this.resetCSVResponse();
      this.toastr.clear()
      this.reportsService.objectionsCsv<any>(this._campaignId)
        .subscribe(response => {
          this.CSVResponse._objectionsCsv.fullResponse = response.report;
          let _arrayCSV = response ? response.report.split('\n') : [];

          _arrayCSV.forEach((element, index) => {
            const cols: string[] = element.split(',');
            if (index == 0) this.CSVResponse._objectionsCsv.title = cols
            else if (index == 1) this.CSVResponse._objectionsCsv.header = cols
            else this.CSVResponse._objectionsCsv.cols.push(cols);
          });
          this._loading = false;
        }, error => {
          this._loading = false;
          this.toastr.error('Report not generated.', 'Error!');
        })
    }
  }

  objectionsPdf() {
    this._loading = true;
    this.toastr.clear()
    this.reportsService.objectionsPdf(this._campaignId)
      .subscribe(response => {
        this._objectionsPdf = this.sanitizer.bypassSecurityTrustResourceUrl('data:application/pdf;base64,' + response['encodedReport'] + '#toolbar=1');
        this._loading = false;
      }, error => {
        this._loading = false;
        this.toastr.error('Report not generated.', 'Error!');
      })
  }
  downloadFile(_csvData: string, filename, type) {
    let _arrayCSV = _csvData ? _csvData.split('\n') : [];
    let _title = []; let _header = []; let _cols = [];
    switch (type) {
      case '_validSignaturesCsv':
        _arrayCSV.forEach((element, index) => {

          const cols: string[] = element.split(',');
          if (index == 0) _title = cols
          else if (index == 1) _header = cols
          else {
            _cols.push(cols.map((item, i) => {
              return this.getItem(item, i, '_validSignaturesCsv')
            }));
          }
        })
        break;
      case '_sheetCsv':
        _arrayCSV.forEach((element, index) => {

          const cols: string[] = element.split(',');
          if (index == 0) _title = cols
          else if (index == 1) _header = cols
          else {
            _cols.push(cols.map((item, i) => {
              return this.getItem(item, i, '_sheetCsv')
            }));
          }
        })
        break;
      case '_totalValidSignatureCsv':
        _arrayCSV.forEach((element, index) => {

          const cols: string[] = element.split(',');
          if (index == 0) _title = cols
          else if (index == 1) _header = cols
          else {
            _cols.push(cols.map((item, i) => {
              return this.getItem(item, i, '_totalValidSignatureCsv')
            }));
          }
        })
        break;
      case '_duplicateSignaturesCsv':
        _arrayCSV.forEach((element, index) => {

          const cols: string[] = element.split(',');
          if (index == 0) _title = cols
          else if (index == 1) _header = cols
          else {
            _cols.push(cols.map((item, i) => {
              return this.getItem(item, i, '_duplicateSignaturesCsv')
            }));
          }
        })
        break;
      case '_objectionsCsv':
        _arrayCSV.forEach((element, index) => {

          const cols: string[] = element.split(',');
          if (index == 0) _title = cols
          else if (index == 1) _header = cols
          else {
            _cols.push(cols.map((item, i) => {
              return this.getItem(item, i, '_objectionsCsv')
            }));
          }
        })
        break;
    }
    let _fullResponse = _title.join();
    _fullResponse += '\n' + _header.join();
    _fullResponse += '\n' + _cols.join('\n');
    console.log('sheetResults', _fullResponse)
    this._sharedService.downloadCSVFile(_fullResponse, filename);
  }

}
