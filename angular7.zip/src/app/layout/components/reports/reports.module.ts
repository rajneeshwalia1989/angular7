import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ReportsComponent } from './reports.component';
import { NgxPaginationModule } from 'ngx-pagination';

const routes: Routes = [
  { path: "", component: ReportsComponent, data: { title: "Reports" } }
];

@NgModule({
  declarations: [ReportsComponent],
  imports: [
    NgxPaginationModule,
    RouterModule.forChild(routes),
    CommonModule,
    FormsModule
  ],
  providers: [DatePipe],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class ReportsModule { }
