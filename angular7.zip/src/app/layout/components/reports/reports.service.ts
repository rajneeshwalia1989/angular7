import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, pipe, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ReportsService {

  constructor(private _config: AppConfig, private http: HttpClient) { }

  validSignaturesCsv<T>(campaignId: number) {
    let endPoint = `${this._config.baseURL}/${campaignId}/reports/valid-signatures-csv`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  validSignaturesPdf<T>(campaignId: number) {
    let endPoint = `${this._config.baseURL}/${campaignId}/reports/valid-signatures-pdf`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  sheetCsv<T>(campaignId: number) {
    let endPoint = `${this._config.baseURL}/${campaignId}/reports/sheet-csv`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  sheetPdf<T>(campaignId: number) {
    let endPoint = `${this._config.baseURL}/${campaignId}/reports/sheet-pdf`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }
  totalValidSignCsv<T>(mainCampaignId: number, campaignId: number) {
    let endPoint = `${this._config.baseURL}/${mainCampaignId}/${campaignId}/reports/total-valid-signatures-csv`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }
    //{mainCampaignId}/{campaignId}/reports/total-valid-signatures-csv

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  duplicateSignaturesCsv<T>(mainCampaignId: number) {
    let endPoint = `${this._config.baseURL}/${mainCampaignId}/reports/duplicate-signatures-csv`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  duplicateSignaturesPdf<T>(mainCampaignId: number) {
    let endPoint = `${this._config.baseURL}/${mainCampaignId}/reports/duplicate-signatures-pdf`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  objectionsCsv<T>(campaignId: number) {
    let endPoint = `${this._config.baseURL}/${campaignId}/reports/objections-csv`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  objectionsPdf<T>(campaignId: number) {
    let endPoint = `${this._config.baseURL}/${campaignId}/reports/objections-pdf`
    // if(campaignId) {
    //   endPoint += `?&campaignId=${campaignId}`
    // }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  protected getRequestHeaders(): Object {
		let headers;
		headers = new HttpHeaders({
			//'Content-Type': 'application/x-www-form-urlencoded',
			//'Content-Type': 'text/plain; charset=utf-8',
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		});
		return { headers: headers, responseType: 'json' };
	}

}
