import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { CheckSheetsService } from '../check-sheets.service';
import { ToastrService } from 'ngx-toastr';
import { LoginResult } from 'src/app/layout/models/loginResult';
import { AuthService } from 'src/app/auth.service';


@Component({
  selector: 'app-skip-sheet-modal',
  templateUrl: './skip-sheet-modal.component.html',
  styleUrls: ['./skip-sheet-modal.component.css']
})
export class SkipSheetModalComponent implements OnInit {
  public event: EventEmitter<any> = new EventEmitter();
  pageTitle: string = "Skip Sheet";
  mainCampaignId: number;
  campaignId: number;
  sheet: any;
  yes;

  constructor(public bsModalRef: BsModalRef, private service: CheckSheetsService,
    private toastr: ToastrService, private authService: AuthService) {
    setTimeout(() => {
      this.sheet = this.bsModalRef.content.sheet;
    }, 0);
  }

  ngOnInit() {
    // let user = JSON.parse(localStorage.getItem('CurrentUser')) as LoginResult;
    let user = this.authService.getItemFromLocalStorage('CurrentUser') as LoginResult;
    if (user) {
      this.mainCampaignId = user.mainCampaignId;
    }
    this.authService.removeFromLocalStorage('skip-clicked')
  }

  /* Yes delete */
  Yes(sheet) {
    this.yes = true;
    this.toastr.clear()
    this.authService.setItemToLocalStorage('skip-clicked', 1)
    this.campaignId = +this.authService.getItemFromLocalStorage('campaignId');
    this.service.getSheetReview<any>(this.mainCampaignId, this.campaignId)
      .subscribe(response => {
        //console.log("###### SKIP RESPONSE ######", response);
        this.toastr.success('Sheet has been skipped!', 'Alert!');
        this.yes = false;
        this.event.emit({ lastSheetId: sheet.id, method: 'skip', response: response, sheetId: response.id });
        this.authService.removeFromLocalStorage('skip-clicked')
        this.bsModalRef.hide();
      }, error => {
        //console.log("###### SKIP error ######", error);
        this.yes = false;
        this.toastr.error('Error wile skipping this sheet.', 'Error!');
        this.authService.removeFromLocalStorage('skip-clicked')
      })
  }

  /* No delete */
  No(sheet) {
    this.bsModalRef.hide();
  }
}
