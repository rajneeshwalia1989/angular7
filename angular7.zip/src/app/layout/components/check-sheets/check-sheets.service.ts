import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, pipe, throwError } from 'rxjs';
import { of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { searchVM } from '../../models/searchVM';

@Injectable({
	providedIn: 'root'
})
export class CheckSheetsService {
	constructor(private _config: AppConfig, private http: HttpClient) {}

	getSheetReview<T>(mainCampaignId: number, campaignId: number, sheetNumber?: number): Observable<T> {
		let endPoint = `${this._config.baseURL}/${mainCampaignId}/${campaignId}/sheet-review`;
		if (sheetNumber || sheetNumber == 0) endPoint = endPoint + `?sheetNumber=${sheetNumber}`;

		return this.http.get<T>(endPoint, this.getRequestHeaders()).pipe(
			catchError((err) => {
				return throwError(err);
			})
		);
	}

	searchVoters<T>(mainCampaignId: number, search): Observable<T> {
		let endPoint = `${this._config.baseURL}/${mainCampaignId}/sheet-review/voters?`;

		if (search.firstName) {
			endPoint += `&firstName=${search.firstName}`;
		}
		if (search.lastName) {
			endPoint += `&lastName=${search.lastName}`;
		}
		if (search.streetName) {
			endPoint += `&streetName=${search.streetName}`;
		}
		if (search.streetNumber) {
			endPoint += `&streetNumber=${search.streetNumber}`;
		}

		return this.http.get<T>(endPoint, this.getRequestHeaders()).pipe(
			catchError((err) => {
				return throwError(err);
			})
		);
	}

	saveCheckSheet<T>(mainCampaignId, campaignId, sheet): Observable<T> {
		let endPoint = `${this._config.baseURL}/${mainCampaignId}/${campaignId}/sheet-update`;
		return this.http.post<T>(endPoint, sheet, this.getRequestHeaders()).pipe(
			catchError((err) => {
				return throwError(err);
			})
		);
	}

	sheetSkipping<T>(mainCampaignId, campaignId, sheetId): Observable<T> {
		let endPoint = `${this._config.baseURL}/${mainCampaignId}/${campaignId}/sheet-skipping/${sheetId}`;
		return this.http.post<T>(endPoint, null, this.getRequestHeaders()).pipe(
			catchError((err) => {
				return throwError(err);
			})
		);
	}

	sheetDeletion<T>(mainCampaignId, campaignId, sheetId): Observable<T> {
		let endPoint = `${this._config.baseURL}/${mainCampaignId}/${campaignId}/sheet-delete/${sheetId}`;
		return this.http.delete<T>(endPoint, this.getRequestHeaders()).pipe(
			catchError((err) => {
				return throwError(err);
			})
		);
	}

	GetCampaignSummary<T>(mainCampaignId: number, campaignId: number): Observable<T> {
		let body = new HttpParams();
		//body = body.set("campaignName", campaignName);

		return (
			this.http
				.get<any>(`${this._config.baseURL}/${mainCampaignId}/${campaignId}/dashboard`, this.getRequestHeaders())
				//.map((res: Response) => res.text())
				.pipe(
					catchError((err) => {
						return throwError(err);
					})
				)
		);

		//return of(this.getCampaigns().find(x=> x.CampaignId == campaignId));
	}

	protected getRequestHeaders(): Object {
		let headers;
		headers = new HttpHeaders({
			//'Content-Type': 'application/x-www-form-urlencoded',
			//'Content-Type': 'text/plain; charset=utf-8',
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		});
		return { headers: headers, responseType: 'json' };
	}
}
