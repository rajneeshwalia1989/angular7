import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { CheckSheetsComponent } from './check-sheets.component';
import { FormsModule } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

const routes: Routes = [
  { path: "", component: CheckSheetsComponent, data: { title: "Check-Sheets" } }
];

@NgModule({
  declarations: [
    CheckSheetsComponent    
  ],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    FormsModule,
    BsDatepickerModule.forRoot(),
    NgMultiSelectDropDownModule.forRoot()
  ],  
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class CheckSheetsModule { }
