import { Component, OnInit, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { CheckSheetsService } from '../check-sheets.service';
import { ToastrService } from 'ngx-toastr';
import { LoginResult } from 'src/app/layout/models/loginResult';
import { AuthService } from 'src/app/auth.service';


@Component({
  selector: 'app-delete-sheet-modal',
  templateUrl: './delete-sheet-modal.component.html',
  styleUrls: ['./delete-sheet-modal.component.css']
})
export class DeleteSheetModalComponent implements OnInit {
  public event: EventEmitter<any> = new EventEmitter();
  pageTitle: string = "Delete Sheet";
  mainCampaignId: number;
  campaignId: number;
  sheet: any;
  yes;

  constructor(public bsModalRef: BsModalRef, private service: CheckSheetsService,
    private toastr: ToastrService, private authService:AuthService) {
    setTimeout(() => {
      this.sheet = this.bsModalRef.content.sheet;
    }, 0);
  }

  ngOnInit() {
    // let user = JSON.parse(localStorage.getItem('CurrentUser')) as LoginResult;
    let user = this.authService.getItemFromLocalStorage('CurrentUser') as LoginResult;
    if (user) {
      this.mainCampaignId = user.mainCampaignId;
    }
  }

  /* Yes delete */
  Yes(sheet) {
    this.yes = true;
    this.toastr.clear()
    // this.campaignId = +localStorage.getItem('campaignId')
    this.campaignId = +this.authService.getItemFromLocalStorage('campaignId')
    this.service.sheetDeletion<any>(this.mainCampaignId, this.campaignId, sheet.id)
      .subscribe(response => {
        //console.log("###### DELETE RESPONSE ######", response);
        this.toastr.success('Sheet has been deleted successfully!','Alert!');
        this.yes = false;
        this.event.emit({ lastSheetId: sheet.id, method: 'delete', response: response, sheetId: response.id  });
        this.bsModalRef.hide();
      }, error => {
        console.log("###### DELETE error ######", error);
        this.toastr.error('Error wile deleting this sheet.','Error!');
        this.yes = false;
      })
  }

  /* No delete */
  No(sheet) {
    this.bsModalRef.hide();
  }
}
