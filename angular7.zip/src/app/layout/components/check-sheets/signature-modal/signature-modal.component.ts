import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-signature-modal',
  templateUrl: './signature-modal.component.html',
  styleUrls: ['./signature-modal.component.css']
})
export class SignatureModalComponent implements OnInit {

  constructor(public bsModalRef: BsModalRef) {
    setTimeout(() => {
      console.log("Signatrue Modal!!!!!");
    }, 0);
  }

  ngOnInit() {
  }

  ConfirmSignature() {
    console.log("Signatrue!!!!!!!!!!! ");
    this.bsModalRef.hide();
  }

}
