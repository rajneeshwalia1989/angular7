import { Component, OnInit, HostListener, ChangeDetectorRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { SkipSheetModalComponent } from './skip-sheet-modal/skip-sheet-modal.component';
import { Router, ActivatedRoute } from '@angular/router';
import { CheckSheetsService } from './check-sheets.service';
import { STATUS, OBJECTIONS, OBJECTIONS_STATUS, STATUS_CODE } from '../../models/enums';
import { searchVM } from '../../models/searchVM';
import { VoterSearchResult } from '../../models/searchVM';
import { saveSheetVM } from '../../models/saveSheet';
import { LoginResult } from '../../models/loginResult';
import { ToastrService } from 'ngx-toastr';
import { DeleteSheetModalComponent } from './delete-sheet-modal/delete-sheet-modal.component';
import { sheetLineMock, sheetObjectionsMock } from '../../models/mock-data';
import { NgForm } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
import { AuthService } from 'src/app/auth.service';
import { CampaignDashboardSummary } from '../../models/campaignDashboardSummary';

declare var $;

@Component({
	selector: 'app-check-sheets',
	templateUrl: './check-sheets.component.html',
	styleUrls: [ './check-sheets.component.css' ]
})
export class CheckSheetsComponent implements OnInit {
	loading: boolean = false;
	_currentUser: LoginResult;
	_campaignId: number;
	//sheetNumber: number;
	sheetReview: any;
	search: searchVM = new searchVM();
	saveSheet: saveSheetVM = new saveSheetVM();
	selectedStatus = '';
	statusList = STATUS;
	statusKey = Object.keys;
	sheetObjections = OBJECTIONS;
	objectionStatus = OBJECTIONS_STATUS;
	checked;
	circulator: string;
	notary: string;
	date;
	readonly: boolean = false;
	lineId: number;
	save: boolean = false;
	findVoters: boolean = false;

	show4Options: boolean = true;
	checkSheetNum: boolean = false;
	showVoters: boolean = false;
	selectedVoter = -1;
	selectedListOption = -1;
	addressList: any = [];
	selectedVoterName: any;
	selectedVoterRegID: any;
	deleteModelValue: any;
	voterId: number;
	reviewedSheetNumbers: any[] = [];

	optionsList: any[] = [];
	bsModalRef: BsModalRef;

	dropdownList = [];
	selectedItems = [];
	dropdownSettings = {};
	duplicate: boolean = false;
	campaignName: string;
	_interval;
	_pdfLoading = false;

	@HostListener('window:beforeunload')
	goToPage() {}

	constructor(
		private modalService: BsModalService,
		private route: ActivatedRoute,
		private router: Router,
		private checkSheetService: CheckSheetsService,
		public sanitizer: DomSanitizer,
		private toastr: ToastrService,
		private authService: AuthService,
		private cdr: ChangeDetectorRef
	) {
		this.campaignName = this.authService.getItemFromLocalStorage('campaignName');
		this.sheetReview = {};

		let sheetLineMockList = [];
		let petitionSheetLineCount = this.authService.getItemFromLocalStorage('petitionSheetLineCount')
			? this.authService.getItemFromLocalStorage('petitionSheetLineCount')
			: 10;
		for (let i = 1; i <= petitionSheetLineCount; i++) {
			sheetLineMockList.push({
				id: i,
				sheetId: 1,
				lineNumber: i,
				status: 0,
				voterName: '',
				voterRegistrationId: '',
				voterId: 0
			});
		}
		this.sheetReview.lines = sheetLineMockList;

		this.route.params.subscribe((params) => {
			if (params['id']) {
			}
		});
		this.route.queryParams.subscribe((params) => {
			this.saveSheet.sheetNumber = +params['sheetnumber'];
			$('#rla').addClass('isActive');
			//localStorage.setItem('currentSheetNumber', +params['sheetnumber']);
			//localStorage.setItem('saveSheet',this.saveSheet)
		});
	}

	ngOnInit() {
		this.sheeObjectionsDD();
		this._currentUser = this.authService.getItemFromLocalStorage('CurrentUser');
		this._campaignId = +this.authService.getItemFromLocalStorage('campaignId');
		this.getCampaignSummary();
		this.toastr.clear();
		this.saveSheet.id ? (this.readonly = false) : (this.readonly = true);
		this.getSheetReview();
	}

	getSheetReview() {
		this.loading = true;
		this._pdfLoading = true;
		this._interval = setInterval(() => {
			if (this.saveSheet.encodedImage) {
				this._pdfLoading = false;
				clearInterval(this._interval);
			} else this._pdfLoading = true;
		}, 100);

		this.checkSheetService
			.getSheetReview(this._currentUser.mainCampaignId, this._campaignId, this.saveSheet.sheetNumber)
			.subscribe(
				(response) => {
					this.sheetReview = response;
					this.sheetOnReview(response);
					this.loading = false;
				},
				(error) => {
					if (this.saveSheet.sheetNumber)
						this.toastr.error('Please check the sheet number.', 'No Sheet Found');
					else {
						this.saveSheet.sheetNumber = null;
						this.toastr.warning('Please Upload Petition Sheet(s).', 'No Sheet Found');
					}
					this.loading = false;
				}
			);
	}

	private sheetOnReview(sheet) {
		this.saveSheet = new saveSheetVM();
		this.saveSheet.id = sheet.id;
		this.saveSheet.id ? (this.readonly = false) : (this.readonly = true);

		this.saveSheet.Circulator = sheet.circulator;
		this.saveSheet.Notes = sheet.notes;
		this.saveSheet.Notary = sheet.notary;
		//this.saveSheet.Objection = sheet.objection;
		this.saveSheet.Objections = sheet.objections;
		//this.saveSheet.encodedImage = sheet.encodedImage
		this.saveSheet.encodedImage = this.sanitizer.bypassSecurityTrustResourceUrl(
			'data:application/pdf;base64,' + sheet.encodedImage + '#toolbar=1'
		);

		this.saveSheet.sheetNumber = sheet.sheetNumber;
		this.saveSheet.sheetNumberDB = sheet.sheetNumber;
		//console.log('sheetNumber', sheet.sheetNumber);
		this.saveSheet.isReviewed = sheet.isReviewed;
		this.saveSheet.Date = sheet.date ? new Date(sheet.date).toLocaleDateString() : new Date().toLocaleDateString();

		if (sheet.lines.length > 0) {
			sheet.lines.map((x) => {
				switch (x.status) {
					case 0:
						x.value = STATUS.Empty;
						break;
					case 1:
						x.value = x.voterName;
						break;
					case 2:
						x.value = STATUS.VoterNotFound;
						break;
					case 3:
						x.value = STATUS.LineCrossedOff;
						break;
					case 4:
						x.value = STATUS.LineBlank;
						break;
					case 5:
						x.value = STATUS.LineInvalid;
						break;
					default:
						x.value = STATUS.Empty;
						break;
				}
			});
		}

		this.selectedItems = [];
		let objectionsDllList = sheetObjectionsMock;
		sheet.objections.map((x) => {
			this.selectedItems.push(objectionsDllList.find((y) => y.value == +x));
		});
		this.cdr.detectChanges();
		//console.log('##### SHEET REVIEW RESPONSE Model #####', this.saveSheet);
	}

	//sheet Objection Multiselect Drop Down
	sheeObjectionsDD() {
		this.dropdownList = sheetObjectionsMock;
		this.dropdownSettings = {
			singleSelection: false,
			idField: 'value',
			textField: 'text',
			enableCheckAll: false,
			allowSearchFilter: false
		};
	}

	// On item select sheet Objection result
	onItemSelect(event: any) {
		//console.log('onItemSelect', event, this.selectedItems);
	}

	OnItemDeSelect(event: any) {
		//onsole.log('OnItemDeSelect', event, this.selectedItems);
	}

	//show hide radio button options
	ShowLine10(checked?: boolean) {
		if (checked) {
			this.show4Options = checked;
		} else if (this.addressList.length == 0) {
			this.show4Options = true;
		} else {
			this.show4Options = false;
		}
	}

	CheckSign(sheet) {
		let sheetNumber = sheet.sheetNumber;
		//if (sheetNumber) {
		this.loading = true;
		this.checkSheetNum = false;
		this.readonly = false;
		this.checkSheetService
			.getSheetReview<any>(this._currentUser.mainCampaignId, this._campaignId, sheetNumber)
			.subscribe(
				(response) => {
					//console.log('##CheckSign', response);
					this.sheetReview = response;
					this.sheetOnReview(response);
					this.loading = false;
				},
				(error) => {
					this.saveSheet.id ? (this.readonly = false) : (this.readonly = true);
					this.loading = false;
					this.toastr.error('No sheet number found.', 'Error!');
				}
			);
	}

	// Open Delete sheet Modal
	DeleteSheet(sheet) {
		if (sheet) {
			this.checkSheetNum = false;
			this.bsModalRef = this.modalService.show(DeleteSheetModalComponent);
			this.bsModalRef.content.sheet = sheet;
			this.bsModalRef.content.event.subscribe((data) => {
				//console.log('### SHEET DELETE RESPONSE ###', data);
				this.saveSheet.sheetNumber = this.saveSheet.sheetNumber + 1;
				//this.getSheetReview()
				this.sheetReview = data.response;
				this.sheetOnReview(data.response);
			});
			//
		} else {
			this.checkSheetNum = true;
		}
	}

	// Open Skip sheet Modal
	SkipSheet(sheet) {
		if (sheet) {
			this.checkSheetNum = false;
			this.bsModalRef = this.modalService.show(SkipSheetModalComponent);
			this.bsModalRef.content.sheet = sheet;
			this.bsModalRef.content.event.subscribe((data) => {
				this.loading = true;
				//console.log('### SHEET SKIP RESPONSE ###', data);
				this.saveSheet.sheetNumber = this.saveSheet.sheetNumber + 1;
				//this.getSheetReview()
				this.sheetReview = data.response;
				this.sheetOnReview(data.response);
				this.ClearSearch();
				this.selectedListOption = null;
				this.showVoters = false;
				this.loading = false;
			});
			//
		} else {
			this.checkSheetNum = true;
		}
	}

	// Move NotMatchedRecords to EMPTY list
	NotMatchedRecords(value) {
		this.checked = STATUS_CODE[value];
		this.sheetReview.lines.map((x) => {
			if (x.id == this.lineId) {
				x.status = STATUS_CODE[value];
				if (value == 'ConfirmedVoter') {
					x.value = x.voterName;
				} else {
					x.value = STATUS[value];
				}
			}
		});
	}

	// Move Voter Name to EMPTY List
	MoveVoterName() {
		if (this.selectedVoterName) {
			this.checked = 1;
			//this.show4Options = false;
			this.selectedVoter = null;
			this.sheetReview.lines.map((x, index) => {
				if (x.id == this.lineId) {
					x.status = 1;
					x.voterName = this.selectedVoterName;
					x.value = this.selectedVoterName;
					x.voterRegistrationId = this.selectedVoterRegID;
					x.voterId = this.voterId;
					//this.selectedListOption = (this.sheetReview.lines.length == (index+1) ? index : (index+1))
				}
			});
		}
	}

	ClearSearch() {
		this.showVoters = false;
		this.addressList = [];
		this.search.streetNumber = null;
		this.search.streetName = '';
		this.search.firstName = '';
		this.search.lastName = '';
		this.show4Options = true;
		//this.selectedListOption = null;
		//this.lineId = 0;

		this.selectedVoter = undefined;
		this.selectedVoterName = undefined;
		this.selectedVoterRegID = undefined;
		this.voterId = 0;
	}

	// Get & heighlight selected record from 10 EMPTY list record
	SelectedOption(e, item, index) {
		//this.ClearSearch()
		this.show4Options = true;
		this.checked = item.status;
		this.lineId = item.id;
		this.selectedStatus = '';

		this.selectedListOption = index;
	}

	// select address from addressList
	SelectAddress(selectedItem: any, index?) {
		this.selectedVoter = index;
		this.selectedVoterName = selectedItem.fullName;
		this.selectedVoterRegID = selectedItem.registrationId;
		this.voterId = selectedItem.id;
	}

	// getVoters or addressList
	SearchVoter(search: searchVM, selectedInput?) {
		if (search && selectedInput) {
			this.showVoters = true;
			this.findVoters = true;
			this.readonly = true;
			//let mainCampaignId = this.authService.getItemFromLocalStorage('campaignId');
			let mainCampaignId = this._currentUser.mainCampaignId;
			this.checkSheetService.searchVoters<searchVM>(+mainCampaignId, search).subscribe(
				(response) => {
					//console.log('###### SearchVoter RESPONSE ######', response);
					if (response) {
						this.addressList = response;
						this.show4Options = this.addressList.length > 0 ? false : true;
						this.findVoters = false;
						this.readonly = false;
					} else {
						this.findVoters = false;
						this.readonly = false;
						this.toastr.error(
							'The application has encountered an unknown error. Please try again.',
							'Error!'
						);
					}
				},
				(error) => {
					this.addressList = [];
					this.show4Options = true;
					this.findVoters = false;
					this.showVoters = true;
					this.readonly = false;
				}
			);
			this.ShowLine10();
		}
	}

	compareSheets() {
		//console.log('sheetNumber', this.saveSheet.sheetNumber);
		if (this.saveSheet.sheetNumber) {
			this.reviewedSheetNumbers.map((x) => {
				if (this.saveSheet.sheetNumber == x) {
					this.duplicate = true;
					//	return false;
				}
			});
		}
	}

	getCampaignSummary() {
		this.loading = true;
		this.checkSheetService
			.GetCampaignSummary<CampaignDashboardSummary>(this._currentUser.mainCampaignId, this._campaignId)
			.subscribe(
				(response) => {
					if (response) {
						//console.log('response', response.reviewedSheetNumbers);
						this.authService.removeFromLocalStorage('reviewedSheetNumbers');
						this.authService.setItemToLocalStorage(
							'reviewedSheetNumbers',
							response.reviewedSheetNumbers,
							true
						);
						this.loading = false;
					}
				},
				(error) => {
					console.log(error);
					this.loading = false;
				}
			);
	}

	Save_Next(f: NgForm) {
		this.save = true;
		this.loading = true;
		let invalidLines = this.sheetReview.lines.find((x) => x.value == 'Empty') ? true : false;
		this.reviewedSheetNumbers = this.authService.getItemFromLocalStorage('reviewedSheetNumbers');
		this.compareSheets();
		//console.log('duplicate', this.duplicate);
		if (invalidLines) {
			this.toastr.error('Please finish the current sheet before move on to another sheet', 'Validation Error!');
			this.save = false;
			this.loading = false;
			event.preventDefault();
			return false;
		} else if (this.duplicate) {
			this.toastr.error('A sheet with that number already exists', 'Duplication Error!');
			this.save = false;
			this.loading = false;
			this.duplicate = false;
			return false;
		} else {
			let objectionsList = [];
			this.selectedItems.map((x) => {
				objectionsList.push(x.value);
			});

			let saveCheckSheet: any = {
				Id: this.sheetReview.id,
				Notes: this.saveSheet.Notes,
				Circulator: this.saveSheet.Circulator,
				Notary: this.saveSheet.Notary,
				Date: this.saveSheet.Date,
				Objection: this.sheetReview.objection,
				Objections: objectionsList,
				Lines: this.sheetReview.lines
			};

			if (this.saveSheet.sheetNumber || this.saveSheet.sheetNumber == 0)
				saveCheckSheet.sheetNumber = this.saveSheet.sheetNumber;

			//console.log('saveCheckSheet', saveCheckSheet)

			this.checkSheetService
				.saveCheckSheet(this._currentUser.mainCampaignId, this._campaignId, saveCheckSheet)
				.subscribe(
					(response) => {
						try {
							f.resetForm();
						} catch (err) {}
						//console.log('SAVE AND NEXT: ', response);
						this.save = false;
						this.loading = false;
						this.checked = 0;
						this.toastr.success('Sheet has been saved successfully!', 'Alert!');
						this.sheetReview = response;
						this.sheetOnReview(response);
						this.ClearSearch();
						this.selectedListOption = null;
						this.showVoters = false;
						this.getCampaignSummary();
					},
					(error) => {
						this.save = false;
						this.loading = false;
						this.toastr.error('Error while updating the sheet.', 'Error!');
					}
				);
		}
	}
}
