import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { WalkSheetDDL } from './walk-sheets.component';


@Injectable({
  providedIn: 'root'
})
export class WalkSheetsService {

  constructor(private _config: AppConfig, private http: HttpClient) { }


  GetPrecinctWalksheetsCsv<T>(_mainCampaignId: number, walkSheetDDL: WalkSheetDDL) {
    let endPoint = `${this._config.baseURL}/${_mainCampaignId}/precinct-walksheets-csv?`
    if (walkSheetDDL.county) {
      endPoint += `county=${walkSheetDDL.county}`
    }
    if (walkSheetDDL.city) {
      endPoint += `&city=${walkSheetDDL.city}`
    }
    if (walkSheetDDL.ward) {
      endPoint += `&ward=${walkSheetDDL.ward}`
    }
    if (walkSheetDDL.precinct) {
      endPoint += `&precinct=${walkSheetDDL.precinct}`
    }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  GetPrecinctWalksheetsPdf<T>(_mainCampaignId: number, walkSheetDDL: WalkSheetDDL) {
    let endPoint = `${this._config.baseURL}/${_mainCampaignId}/precinct-walksheets-pdf?`
    if (walkSheetDDL.county) {
      endPoint += `county=${walkSheetDDL.county}`
    }
    if (walkSheetDDL.city) {
      endPoint += `&city=${walkSheetDDL.city}`
    }
    if (walkSheetDDL.ward) {
      endPoint += `&ward=${walkSheetDDL.ward}`
    }
    if (walkSheetDDL.precinct) {
      endPoint += `&precinct=${walkSheetDDL.precinct}`
    }

    return this.http.get<T>(endPoint, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  ExportMapWalkSheetsCsv<T>(_mainCampaignId: number, coordinates): Observable<T> {
    let endPoint = `${this._config.baseURL}/${_mainCampaignId}/map-walksheets-csv`
    return this.http.post<any>(endPoint, coordinates, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  ExportMapWalkSheetsPdf<T>(_mainCampaignId: number, coordinates): Observable<T> {
    let endPoint = `${this._config.baseURL}/${_mainCampaignId}/map-walksheets-pdf`
    return this.http.post<any>(endPoint, coordinates, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }


  protected getRequestHeaders(): Object {
    let headers;
    headers = new HttpHeaders({
      'Content-Type': 'application/json',
      //'Content-Type': 'text/plain; charset=utf-8',
      //'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*'
    });
    return { headers: headers, responseType: 'json' };
  }
}
