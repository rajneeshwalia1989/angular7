import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { WalkSheetsComponent } from './walk-sheets.component';
import { AgmCoreModule } from '@agm/core'
//import { TabsModule } from 'ngx-bootstrap/tabs';



const routes: Routes = [
  { path: "", component: WalkSheetsComponent, data: { title: "Walk-Sheets" } }
];

@NgModule({
  declarations: [WalkSheetsComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule,
    FormsModule,
    //TabsModule.forRoot(),
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyAEyoTNOLPJi8Hu-kBN2Xb_azmS1HJB2z8',
      libraries: ["places","drawing"]
    })
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class WalkSheetsModule { }
