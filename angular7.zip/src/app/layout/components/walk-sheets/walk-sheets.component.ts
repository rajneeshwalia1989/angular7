import { Component, ElementRef, OnInit, NgZone, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { LoginResult } from '../../models/loginResult';
import { FormControl } from "@angular/forms";
import { MapsAPILoader, AgmMap } from '@agm/core';
import { MouseEvent } from "@agm/core";
import { find } from 'rxjs/operators';
import { AuthService } from 'src/app/auth.service';
import { ToastrService } from 'ngx-toastr';
import { WalkSheetsService } from './walk-sheets.service';
import { SharedService } from 'src/app/shared/shared.service';
import { LatLngLiteral } from '@agm/core';

declare var google: any;
declare var $;


export class WalkSheetDDL {
  public county = '';
  public city = '';
  public ward = '';
  public precinct = '';
}

@Component({
  selector: 'app-walk-sheets',
  templateUrl: './walk-sheets.component.html',
  styleUrls: ['./walk-sheets.component.css']
})
export class WalkSheetsComponent implements OnInit {

  paths: Array<LatLngLiteral> = [];
  _loadingPDF: boolean = false;
  _loadingCSV: boolean = false;

  options: any = {
    lat: 33.5362475,
    lng: -111.9267386,
    zoom: 10,
    fillColor: '#DC143C',
    draggable: true,
    editable: true,
    visible: true
  };

  _currentuser: LoginResult;
  _campaignId: number;
  _mainCampaignId: number;
  lat: number;
  lng: number;
  county: string = 'Cook';
  city: string = 'Chicago';
  address: string;
  mapData: any = [];
  loading = false;
  name: string;
  zoom: number;
  counties: any[];
  cities: any[];
  wards: any[];
  precincts: any[];
  walkSheetDDL = new WalkSheetDDL();
  precinctWalksheets: any = [];
  precinctWalksheetsPdf: any;
  public searchControl: FormControl;
  walkSheetOptions: any = [];
  polygon: any;
  coordinates: any = [];
  latitude: any = [];
  longitude: any = [];
  contentType: string;
  streetNumbers: any = [];
  arrayLatitude: any;
  arrayLongitude: any;
  _currentCampaign: any;

  @ViewChild("search")
  public searchElementRef: ElementRef;

  constructor(private router: Router, private mapsAPILoader: MapsAPILoader,
    private ngZone: NgZone, private toastr: ToastrService, private _sharedService: SharedService,
    private authService: AuthService, private service: WalkSheetsService) { }

  icon = {
    url: './assets/images/marker-icon.png',
    scaledSize: { height: 40, width: 50 }
  }

  ngOnInit() {
    // this._currentuser = JSON.parse(localStorage.getItem('CurrentUser'));
    // this._campaignId = +localStorage.getItem('campaignId');
    this._currentuser = this.authService.getItemFromLocalStorage('CurrentUser');
    this._campaignId = +this.authService.getItemFromLocalStorage('campaignId');
    this._currentCampaign = this.authService.getItemFromLocalStorage('currentCampaign');
    this._mainCampaignId = this._currentuser.mainCampaignId;
    this.walkSheetOptions = this._currentuser.walkSheetOptions;
    this.counties = this.walkSheetOptions.countyOptions;
    this.lat = 41.882114;
    this.lng = -87.639710;
    this.zoom = 7;
    this.searchControl = new FormControl();
    this.findAdress();
    this.toastr.clear()
    // if(navigator){
    //   navigator.geolocation.getCurrentPosition( pos => {
    //   this.lat = pos.coords.latitude;
    //   this.lng = pos.coords.longitude;
    //   })
    //   }
    //
    // this._sharedService.getPosition().subscribe(
    //   (pos: Position) => {
    //     debugger
    //     this.lat = +pos.coords.latitude;
    //     this.lng = +pos.coords.longitude;
    //   });
  }



  onSelectCounty(county) {
    if (!county) {
      this.ngOnInit()
    }
    this.walkSheetDDL.county = county;
    this.walkSheetDDL.city = '';
    this.walkSheetDDL.ward = '';
    this.wards = [];
    this.precincts = [];
    let _selectedCounty = this.counties.find((x) => x.name === county);
    this.cities = _selectedCounty ? _selectedCounty.cityOptions : [];
    this.setLocation(county);
  }

  onSelectCity(city) {
    if (!city) {
      this.setLocation(this.walkSheetDDL.county)
    }
    this.walkSheetDDL.city = city;
    this.walkSheetDDL.ward = '';
    this.precincts = [];
    let _selectedCity = this.cities.find((x) => x.name === city);
    this.wards = _selectedCity ? _selectedCity.wardOptions : [];
    //this.findAdress(_selectedCity)
    this.setLocation(city);
  }

  onSelectWard(ward) {
    this.walkSheetDDL.ward = ward;
    this.walkSheetDDL.precinct = '';
    let _selectedWard = this.wards.find((x) => x.name === ward);
    this.precincts = _selectedWard ? _selectedWard.precinctNames : [];
  }

  onSelectPrecinct = (precinct) => this.walkSheetDDL.precinct = precinct;

  exportCsv() {
    this.toastr.clear()
    //console.log('param', this.walkSheetDDL)
    if (!this.walkSheetDDL.county) {
      this.toastr.error('Please select county.', 'Validation Error!')
      return;
    } else if (!this.walkSheetDDL.city) {
      this.toastr.error('Please select city.', 'Validation Error!')
      return;
    } else if (!this.walkSheetDDL.ward) {
      this.toastr.error('Please select ward.', 'Validation Error!')
      return;
    } else if (!this.walkSheetDDL.precinct) {
      this.toastr.error('Please select precinct.', 'Validation Error!')
      return;
    } else {
      this.toastr.clear();
      this.loading = true;
      this._loadingCSV = true;
      this.service.GetPrecinctWalksheetsCsv<any>(this._mainCampaignId, this.walkSheetDDL)
        .subscribe(response => {
          this.precinctWalksheets = response;
          this._sharedService.downloadCSVFile(response.report, this.walkSheetDDL.precinct)
          this.loading = false;
          this._loadingCSV = false;
        },
          error => {
            this.loading = false;
            this._loadingCSV = false;
            this.toastr.error('The application has encountered an unknown error. Please try again.', 'Error!')
          })
    }
  }

  onTabSelect = () => this.walkSheetDDL = new WalkSheetDDL();

  exportPdf() {
    this.toastr.clear();
    //console.log('param', this.walkSheetDDL)

    if (!this.walkSheetDDL.county) {
      this.toastr.error('Please select county.', 'Validation Error!')
      return;
    } else if (!this.walkSheetDDL.city) {
      this.toastr.error('Please select city.', 'Validation Error!')
      return;
    } else if (!this.walkSheetDDL.ward) {
      this.toastr.error('Please select ward.', 'Validation Error!')
      return;
    } else if (!this.walkSheetDDL.precinct) {
      this.toastr.error('Please select precinct.', 'Validation Error!')
      return;
    } else {
      this.loading = true;
      this._loadingPDF = true;
      this.toastr.clear();
      this.service.GetPrecinctWalksheetsPdf<any>(this._mainCampaignId, this.walkSheetDDL)
        .subscribe(response => {
          this.loading = false;
          this._loadingPDF = false;
          this.precinctWalksheetsPdf = response;
          if (response) {
            this.contentType = `data:application/pdf;base64`
            this._sharedService.downloadPdfFile(response.encodedReport, this.walkSheetDDL.precinct)
          }
          else {
            this.toastr.error('The application has encountered an unknown error. Please try again.', 'Error!')
          }
        },
          error => {
            this.loading = false;
            this._loadingPDF = false;
            this.toastr.error('The application has encountered an unknown error. Please try again.', 'Error!')
            event.preventDefault();
          })
    }
  }

  findAdress() {
    this.mapsAPILoader.load().then(() => {
      var options = {
        //types: ['(cities)'],
        componentRestrictions: { country: "us" }
      };
      var input = this.searchElementRef.nativeElement
      // if(city){
      //   var input = city.name;
      //   this.address = city.name;
      // }
      let autocomplete = new google.maps.places.Autocomplete(input, options);
      autocomplete.addListener("place_changed", () => {
        this.ngZone.run(() => {

          // some details
          let place: google.maps.places.PlaceResult = autocomplete.getPlace();
          //this.address = place.formatted_address;
          //this.web_site = place.website;
          this.zoom = 8;
          this.name = place.name;
          //this.zip_code = place.address_components[place.address_components.length - 1].long_name;
          //set latitude, longitude and zoom
          this.lat = place.geometry.location.lat();
          this.lng = place.geometry.location.lng();
        });
      });
    });
  }

  // placeMarker($event) {
  //   // let clickCrd = { lat: $event.coords.lat, lng: $event.coords.lng };
  //   // this.paths.push(clickCrd);
  //   // let newArray = Array<LatLngLiteral>();
  //   // this.paths.forEach((item) => {
  //   //   newArray.push(item);
  //   // });
  //   // this.paths = newArray;
  //   // console.log('paths',this.paths)
  //   this.lat = $event.coords.lat;
  //   this.lng = $event.coords.lng;

  //   this.getAddress(this.lat, this.lng)
  // }

  onMapReady(map) {
    this.initDrawingManager(map);
  }

  setLocation(address) {
    var geocoder = new google.maps.Geocoder();
    geocoder.geocode({ 'address': address }, (results, status) => {
      this.ngZone.run(() => {
        if (status === 'OK') {
          this.lat = results[0].geometry.location.lat();
          this.lng = results[0].geometry.location.lng();
          this.zoom = 6;
        }
      })
    });
  }


  initDrawingManager(map: any) {

    var shapes = [];
    const options = {
      drawingControl: true,
      drawingControlOptions: {
        drawingModes: ["polygon"]
      },
      polygonOptions: {
        draggable: true,
        editable: true,
        //strokeColor: '#FF0000',
        strokeOpacity: 0.8,
        strokeWeight: 2,
        //fillColor: '#FF0000',
        fillOpacity: 0.35,
      },
      drawingMode: google.maps.drawing.OverlayType.POLYGON
    };

    const drawingManager = new google.maps.drawing.DrawingManager(options);
    drawingManager.setMap(map);
    google.maps.event.addListener(drawingManager, "overlaycomplete", (event) => {
      var newShape = event.overlay;
      newShape.type = event.type;
      shapes.push(newShape);
      if (drawingManager.getDrawingMode()) {
        drawingManager.setDrawingMode(null);
      }

    });


    // add a listener for the drawing mode change event, delete any existing polygons

    google.maps.event.addListener(drawingManager, "drawingmode_changed", () => {
      this.ngZone.run(() => {
        if (drawingManager.getDrawingMode() != null) {
          for (var i = 0; i < shapes.length; i++) {
            shapes[i].setMap(null);
          }
          shapes = [];
        }
        if (drawingManager.drawingMode) {
          //this.markerClickEvent.next({data:{name: 'another'}});
          this.coordinates = [];
        }
      })
    });

    google.maps.event.addListener(drawingManager, 'polygoncomplete', (polygon) => {

      google.maps.event.addListener(polygon, 'dragend', () => {
        this.ngZone.run(() => {
          this.coordinates = [];
          var path = polygon.getPath();
          for (var i = 0; i < path.length; i++) {
            this.coordinates.push({
              latitude: path.getAt(i).lat(),
              longitude: path.getAt(i).lng()
            });
          }
          console.log('coordinates', this.coordinates);
        })
      });

      google.maps.event.addListener(polygon.getPath(), 'set_at', () => {
        this.ngZone.run(() => {
          this.coordinates = [];
          var path = polygon.getPath();
          for (var i = 0; i < path.length; i++) {
            this.coordinates.push({
              latitude: path.getAt(i).lat(),
              longitude: path.getAt(i).lng()
            });
          }
          // console.log('event', polygon.getPath())
          //$('#vertices').val(event.getPath().getArray());
        })
      });

      google.maps.event.addListener(polygon.getPath(), 'insert_at', () => {
        // let new_lentgh = polygon.getLength();
        // let new_paths = polygon
        this.ngZone.run(() => {
          this.coordinates = [];
          var path = polygon.getPath();
          for (var i = 0; i < path.length; i++) {
            this.coordinates.push({
              latitude: path.getAt(i).lat(),
              longitude: path.getAt(i).lng()
            });
          }
          // console.log('event', polygon.getPath())
          //$('#vertices').val(event.getPath().getArray());
        })
      })

      google.maps.event.addListener(polygon.getPath(), 'remove_at', () => {
        this.ngZone.run(() => {
          this.coordinates = [];
          var path = polygon.getPath();
          for (var i = 0; i < path.length; i++) {
            this.coordinates.push({
              latitude: path.getAt(i).lat(),
              longitude: path.getAt(i).lng()
            });
          }
        })
      })

    });
    // Add a listener for the "drag" event.
    google.maps.event.addListener(drawingManager, "overlaycomplete", (event) => {
      if (event.type === google.maps.drawing.OverlayType.POLYGON) {
        var path = event.overlay.getPath()

        for (var i = 0; i < path.length; i++) {
          this.coordinates.push({
            latitude: path.getAt(i).lat(),
            longitude: path.getAt(i).lng()
          });
          //bounds.extend(path.getAt(i));
        }
        console.log('coordinates', this.coordinates);
        for (let latlng of this.coordinates) {
          this.getAddress(latlng.latitude, latlng.latitude);
        }

      }
    });
  }

  exportMapPdf() {
    this.toastr.clear()
    if (this.coordinates.length > 0) {
      this._loadingPDF = true;
      this.service.ExportMapWalkSheetsPdf<any>(this._mainCampaignId, this.coordinates)
        .subscribe(response => {
          this._sharedService.downloadPdfFile(response.encodedReport);
          this.loading = false;
          this._loadingPDF = false;
        },
          error => {
            this.loading = false;
            this._loadingPDF = false;
            this.toastr.error('The application has encountered an unknown error. Please try again.', 'Error!')
            event.preventDefault();
          })
    }
    else {
      this.toastr.error('Please draw polygon on map.', 'Error!')
    }
  }

  exportMapCsv() {
    this.toastr.clear()
    if (this.coordinates.length > 0) {
      this._loadingCSV = true;
      this.service.ExportMapWalkSheetsCsv<any>(this._mainCampaignId, this.coordinates)
        .subscribe(response => {
          this._sharedService.downloadCSVFile(response.report);
          this.loading = false;
          this._loadingCSV = false;
        },
          error => {
            this.loading = false;
            this._loadingCSV = false;
            this.toastr.error('The application has encountered an unknown error. Please try again.', 'Error!')
          })
    }

    else {
      this.toastr.error('Please draw polygon on map.', 'Error!')
    }
  }

  getAddress(latitude, longitude) {
    if (navigator.geolocation) {
      let geocoder = new google.maps.Geocoder();
      let latlng = new google.maps.LatLng(latitude, longitude);
      let request = { latLng: latlng };

      geocoder.geocode(request, (results, status) => {
        if (status == google.maps.GeocoderStatus.OK) {
          let result = results[0];
          let rsltAdrComponent = result.address_components;
          let resultLength = rsltAdrComponent.length;
          if (result != null) {
            let street_number = rsltAdrComponent.filter(x => x.types == 'street_number');
            if (street_number.length > 0) {
            }
            for (let name of street_number) {
              this.streetNumbers.push(name.long_name)
            }
            // this.marker.streetName = rsltAdrComponent.find(x => x.types == 'route').long_name;
          } else {
            alert("No address available!");
          }
        }
      });

    }
    // if (navigator.geolocation) {
    //   let geocoder = new google.maps.Geocoder();
    //   let latlng = new google.maps.LatLng(lat, long);

    //   let request = [{ latLng: latlng }];
    //   this.loading = true;
    //   geocoder.geocode(request, (results, status) => {
    //     this.ngZone.run(() => {
    //       this.mapData = []
    //       results.map(m => {
    //         let _fullAdreess = "";
    //         m.address_components.map(n => {
    //           _fullAdreess += n.long_name + " "
    //         });
    //         this.mapData.push({
    //           address: m.formatted_address,
    //           fullAdreess: _fullAdreess,
    //           place_id: m.place_id,
    //           types: m.types.join(", ")
    //         });

    //       });
    //       this.loading = false;
    //       console.log(results); // read data from here
    //       console.log(status);
    //       // console.log(results[0]);
    //       if (status === google.maps.GeocoderStatus.OK && results.length) {
    //         this.address = results[0].formatted_address;
    //         let result = results[0];
    //         let rsltAdrComponent = result.address_components;
    //         let resultLength = rsltAdrComponent.length;
    //         if (result != null) {
    //           this.county = rsltAdrComponent[resultLength - 4].short_name;
    //         } else {
    //           alert('No address available!');
    //         }
    //       }
    //     });
    //   });
    // }
  }


  markerDragEnd($event: MouseEvent) {
    this.lat = $event.coords.lat;
    this.lng = $event.coords.lng;
    const geocoder = new google.maps.Geocoder();
    const latlng = new google.maps.LatLng(this.lat, this.lng);
    const request = {
      latLng: latlng
    };
    this.loading = true;
    geocoder.geocode(request, (results, status) => {
      // this.tournament.venue.address = results[0].formatted_address;
      this.ngZone.run(() => {
        this.mapData = []
        results.map(m => {
          let _fullAdreess = "";
          m.address_components.map(n => {
            _fullAdreess += n.long_name + " "
          });
          this.mapData.push({
            address: m.formatted_address,
            fullAdreess: _fullAdreess,
            place_id: m.place_id,
            types: m.types.join(", ")
          });

        });
        this.loading = false;
        console.log(results[0]);
        // some details
        this.address = results[0].formatted_address;
        this.county = results[0].address_components[results[0].address_components.length - 4].short_name;
      });
    });
  }

}
