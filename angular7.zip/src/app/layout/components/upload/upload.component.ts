import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { UploadService } from './upload.service';
import { Router } from '@angular/router';
import { CampaignDashboardSummary } from '../../models/campaignDashboardSummary';
import { LoginResult } from '../../models/loginResult';
import { PetitionDocument } from '../../models/petitionDocument';
import { VoterDocument } from '../../models/voterDocument';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/auth.service';

@Component({
	selector: 'app-upload',
	templateUrl: './upload.component.html',
	styleUrls: [ './upload.component.css' ]
})
export class UploadComponent implements OnInit {
	@ViewChild('csvInput') csvInput: ElementRef;
	@ViewChild('pdfInput') pdfInput: ElementRef;

	pdfFile;
	xlsFile;
	pdfName = 'Choose File';
	xlsName = 'Choose File';
	campaignList: CampaignDashboardSummary[] = [];
	petitionDoc = new PetitionDocument();
	voterDoc = new VoterDocument();
	campaignID: number;
	_loadingPDF: boolean = false;
	_loadingCSV: boolean = false;

	constructor(
		private service: UploadService,
		private router: Router,
		private toastr: ToastrService,
		private authService: AuthService
	) {}

	ngOnInit() {
		this.getAvailableCampaigns();
		this.toastr.clear();
	}

	getAvailableCampaigns() {
		let user = this.authService.getItemFromLocalStorage('CurrentUser') as LoginResult;
		let campaignId = this.authService.getItemFromLocalStorage('campaignId');
		this.campaignList = user.campaigns;
		this.campaignID = +campaignId;
		this.petitionDoc.CampaignId = +campaignId;
		this.voterDoc.CampaignId = +campaignId;
	}

	getCampaignValue(event) {
		this.campaignID = +event.target.value;
		this.petitionDoc.CampaignId = +event.target.value;
		this.voterDoc.CampaignId = +event.target.value;
	}

	uploadCampaignDocument() {
		this._loadingPDF = true;
		this.toastr.clear();
		let user = this.authService.getItemFromLocalStorage('CurrentUser') as LoginResult;
		let mainCampaignId = user.mainCampaignId;
		let campaignId = this.authService.getItemFromLocalStorage('campaignId');
		if (!this.pdfFile) {
			this.toastr.error('No file selected', 'Validation Error!');
			this._loadingPDF = false;
			event.preventDefault();
		} else {
			const _formData: FormData = new FormData();
			_formData.append('form-data', this.pdfFile[0], this.pdfFile[0].name);

			this.service.uploadCampaignDocument<any>(+mainCampaignId, campaignId, _formData).subscribe(
				(response) => {
					//	console.log('####### RESPONSE #######', response);
					this._loadingPDF = false;
					this.toastr.success('Petition Sheet Uploaded Successfully!!', 'Alert!');
					//this.pdfName = null;
				},
				(error) => {
					//this.toastr.error('Please do not upload more than 25 pages at a time.', 'Upload Error!');
					this.toastr.error(
						'Something went wrong. Please try again or contact administrator.',
						'Upload Error!'
					);
					this._loadingPDF = false;
					console.log(error);
				}
			);
		}
	}

	uploadCampaignVoter() {
		this._loadingCSV = true;
		this.toastr.clear();
		let user = this.authService.getItemFromLocalStorage('CurrentUser') as LoginResult;
		let mainCampaignId = user.mainCampaignId;
		if (!this.xlsFile) {
			this._loadingCSV = false;
			this.toastr.error('No file selected', 'Validation Error!');
			event.preventDefault();
		} else {
			const _formData: FormData = new FormData();
			_formData.append('form-data', this.xlsFile[0], this.xlsFile[0].name);
			this.service.uploadCampaignVoter<any>(+mainCampaignId, _formData).subscribe(
				(response) => {
					//console.log('####### RESPONSE #######', response);
					user.walkSheetOptions = response;
					this.toastr.success('Voter Data File Uploaded Successfully!!', 'Alert!');
					//this.xlsName = null;
					this._loadingCSV = false;
				},
				(error) => {
					this._loadingCSV = false;
					this.toastr.error(
						'Uploaded file is not valid. Please Check Voter Template file for valid format.',
						'Upload Error!'
					);
					console.log(error);
				}
			);
		}
	}

	clear(_type) {
		if (_type == 'pdf') {
			this.pdfFile = null;
			this.pdfName = '';
			this.pdfInput.nativeElement.value = '';
		} else if (_type == 'xls') {
			this.xlsFile = null;
			this.xlsName = '';
			this.csvInput.nativeElement.value = '';
		}
	}

	async handleFileInput(file, _type) {
		this.toastr.clear();
		if (this.checkfile(file[0], _type)) {
			//this.files = file;
			if (_type == 'pdf') {
				this.pdfFile = file;
				this.pdfName = file[0].name;
				//this.xlsName = ''
			} else if (_type == 'xls') {
				this.xlsFile = file;
				this.xlsName = file[0].name;
				//this.pdfName = ''
			}

			let reader = new FileReader();
			reader.readAsDataURL(file[0]);
			reader.onload = await this.handleReaderLoad.bind(this, _type);
			reader.onerror = function(error) {
				console.log('Error: ', error);
			};
		}
	}

	handleReaderLoad(_type, e) {
		let reader = e.target;
		if (_type == 'pdf') this.petitionDoc.EncodedPdf = reader.result.split('base64,')[1];
		else if (_type == 'xls') this.voterDoc.EncodedCsv = reader.result.split('base64,')[1];
		else {
			//console.log('handleReaderLoad');
			this.pdfFile = null;
			this.xlsFile = null;
		}
	}

	checkfile(sender, _type): boolean {
		try {
			var validExts = _type == 'pdf' ? new Array('.pdf') : new Array('.xlsx', '.xls', '.csv');
			var fileExt = sender.name;
			fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
			if (validExts.indexOf(fileExt) < 0) {
				//alert("Invalid file selected, valid files are of " + validExts.toString() + " types.");
				this.toastr.error(
					'Invalid file selected, please select valid file eg. ' + validExts.toString() + '',
					'Validation Error!'
				);
				return false;
			} else return true;
		} catch (err) {
			return false;
		}
	}
}
