import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { PetitionDocument } from '../../models/petitionDocument';
import { VoterDocument } from '../../models/voterDocument';

@Injectable({
	providedIn: 'root'
})
export class UploadService {
	constructor(private _config: AppConfig, private http: HttpClient) {}

	getAvailableCampaigns() {
		return this.http.get(`${this._config.baseURL}/document-upload`, this.getRequestHeaders()).pipe(
			catchError((err) => {
				return throwError(err);
			})
		);
	}

	getMainCampaignList<T>(mainCampaignId: number): Observable<T> {
		return this.http
			.get<T>(`${this._config.baseURL}/${mainCampaignId}/document-upload`, this.getRequestHeaders())
			.pipe(
				catchError((err) => {
					return throwError(err);
				})
			);
	}

	uploadCampaignDocument<T>(mainCampaignId: number, campaignId: number, model: FormData): Observable<T> {
		return this.http
			.post<any>(
				`${this._config.baseURL}/${mainCampaignId}/${campaignId}/document-upload/petition`,
				model,
				this.getRequestHeadersFormData()
			)
			.pipe(
				catchError((err) => {
					return throwError(err);
				})
			);
	}

	uploadCampaignVoter<T>(mainCampaignId: number, model: FormData): Observable<T> {
		return this.http
			.post<any>(
				`${this._config.baseURL}/${mainCampaignId}/document-upload/voters`,
				model,
				this.getRequestHeadersFormData()
			)
			.pipe(
				catchError((err) => {
					return throwError(err);
				})
			);
	}

	//SET HEADERS
	protected getRequestHeaders(): Object {
		let headers;
		headers = new HttpHeaders({
			//'Content-Type': 'application/x-www-form-urlencoded',
			//'Content-Type': 'text/plain; charset=utf-8',
			'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		});
		return { headers: headers, responseType: 'json' };
	}

	protected getRequestHeadersFormData(): Object {
		let headers;
		headers = new HttpHeaders({
			//'Content-Type': 'application/x-www-form-urlencoded',
			//'Content-Type': 'text/plain; charset=utf-8',
			Accept: 'application/json',
			'Access-Control-Allow-Origin': '*'
		});
		return { headers: headers, responseType: 'json' };
	}
}
