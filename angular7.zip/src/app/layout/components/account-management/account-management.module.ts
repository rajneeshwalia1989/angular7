import { NgModule,CUSTOM_ELEMENTS_SCHEMA} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { AccountManagementComponent } from './account-management.component';

const routes: Routes = [
  { path: "", component: AccountManagementComponent, data: { title: "Account" } }
];

@NgModule({
  declarations: [AccountManagementComponent],
  imports: [
    RouterModule.forChild(routes),
    CommonModule
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AccountManagementModule { }
