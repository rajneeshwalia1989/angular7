import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';
import { ToastrService } from 'ngx-toastr';
import { LoginResult } from '../../models/loginResult';

@Component({
  selector: 'app-account-management',
  templateUrl: './account-management.component.html',
  styleUrls: ['./account-management.component.css']
})
export class AccountManagementComponent implements OnInit {
  campaignId: number;
  _currentuser: LoginResult;
  constructor(private router: Router, private authService: AuthService, private toastr: ToastrService) {
    // const _campaign = localStorage.getItem('campaignId');
    const _campaign = this.authService.getItemFromLocalStorage('campaignId');
    if (_campaign) {
      this.campaignId = +_campaign
    }
  }

  ngOnInit() {
    this.toastr.clear()
    this._currentuser = this.authService.getItemFromLocalStorage('CurrentUser');

  }

}
