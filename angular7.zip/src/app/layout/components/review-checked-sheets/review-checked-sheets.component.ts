import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { ReviewCheckedSheetsService } from './review-checked-sheets.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CampaignDashboardSummary } from '../../models/campaignDashboardSummary';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-review-checked-sheets',
  templateUrl: './review-checked-sheets.component.html',
  styleUrls: ['./review-checked-sheets.component.css']
})
export class ReviewCheckedSheetsComponent implements OnInit {
  bsModalRef: BsModalRef;
  campaigns: any[] = [];
  _currentUser;
  campaignId: number;
  loading: boolean = false;
  reviewedSheetNumbers: number[] = [];
  unreviewedSheetIds: number[] = [];
  sortReviewedSheetNumbers: number[] = [];

  constructor(private modalService: BsModalService, private service: ReviewCheckedSheetsService,
    private toastr: ToastrService, private router: Router, private route: ActivatedRoute,
    private authService: AuthService) { }

  ngOnInit() {
    this._currentUser = this.authService.getItemFromLocalStorage('CurrentUser');
    this.campaigns = this._currentUser.campaigns
    this.campaignId = +this.authService.getItemFromLocalStorage('campaignId');
    this.reviewedSheetNumbers = this.authService.getItemFromLocalStorage("reviewedSheetNumbers")
    this.unreviewedSheetIds = this.authService.getItemFromLocalStorage("unreviewedSheetIds")
    this.sortReviewedSheetNumbers = this.reviewedSheetNumbers.sort((a, b) => 0 - (a > b ? -1 : 1));

    if (this._currentUser == null) {
      this.router.navigate(['./login']);
    }

    this.route.params.subscribe(params => {
      this.campaignId = +params.id
      let mainCampaignId = this._currentUser.mainCampaignId;
      this.loading = true;
      this.toastr.clear()

      this.service.GetCampaignSummary<CampaignDashboardSummary>(+mainCampaignId, +this.campaignId)
        .subscribe(response => {
          this.reviewedSheetNumbers = response.reviewedSheetNumbers;
          this.sortReviewedSheetNumbers = this.reviewedSheetNumbers.sort((a, b) => 0 - (a > b ? -1 : 1));
          this.unreviewedSheetIds = response.unreviewedSheetIds;
          this.authService.removeFromLocalStorage('reviewedSheetNumbers');
          this.authService.setItemToLocalStorage('reviewedSheetNumbers', response.reviewedSheetNumbers, true);
          this.authService.removeFromLocalStorage('unreviewedSheetIds');
          this.authService.setItemToLocalStorage('unreviewedSheetIds', response.unreviewedSheetIds, true);
          this.loading = false;
          //console.log('dashboard', this.dashboard, response)
        })
    }, error => {
      console.log(error)
      this.loading = false;
    })
  }


}




