import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ReviewCheckedSheetsService {

  constructor(private _config: AppConfig, private http: HttpClient) { }

  GetCampaignSummary<T>(mainCampaignId:number,campaignId: number): Observable<T> {
    let body = new HttpParams();
    //body = body.set("campaignName", campaignName);

    return this.http.get<any>(`${this._config.baseURL}/${mainCampaignId}/${campaignId}/dashboard`, this.getRequestHeaders())
      //.map((res: Response) => res.text())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )

    //return of(this.getCampaigns().find(x=> x.CampaignId == campaignId));

  }

  getCampaign<T>(mainCampaignId:number,campaignId: number): Observable<T> {
    return this.http.get<any>(`${this._config.baseURL}/${mainCampaignId}/${campaignId}/dashboard`, this.getRequestHeaders())
      //.map((res: Response) => res.text())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  //SET HEADERS
	protected getRequestHeaders(): Object {
		let headers;
		headers = new HttpHeaders({
			'Content-Type': 'application/json',
			//'Content-Type': 'text/plain; charset=utf-8',
			//'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		});
		return { headers: headers, responseType: 'json' };
	}

}
