import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginResult } from '../../models/loginResult';

@Component({
  selector: 'app-help',
  templateUrl: './help.component.html',
  styleUrls: ['./help.component.css']
})
export class HelpComponent implements OnInit {
  campaigns: any[] = [];
  _currentuser: LoginResult;
  _campaignId: number;
  constructor(private toastr: ToastrService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
  }

}
