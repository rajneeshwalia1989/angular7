import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { HelpComponent} from './help.component';

const routes: Routes = [
  { path: "", component: HelpComponent, data: { title: "Help" } }
];

@NgModule({
  declarations: [
    HelpComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)    
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class HelpModule { }
