import { Component, OnInit } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { AdminVolunteerService } from '../admin-volunteer.service';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/auth.service';

@Component({
	selector: 'app-change-password',
	templateUrl: './change-password.component.html',
	styleUrls: [ './change-password.component.css' ]
})
export class ChangePasswordComponent implements OnInit {
	title: string;
	user;

	constructor(
		public bsModalRef: BsModalRef,
		private service: AdminVolunteerService,
		private toastr: ToastrService,
		private authService: AuthService
	) {
		setTimeout(() => {
			//console.log(this.bsModalRef.content.title);
		}, 0);
	}

	ngOnInit() {
		this.user = {
			password: '',
			confirmPassword: ''
		};
	}

	changePassword() {
		// let _user = JSON.parse(localStorage.getItem('CurrentUser'));
		let _user = this.authService.getItemFromLocalStorage('CurrentUser');
		this.service.changePassword(+_user.mainCampaignId, _user.username, this.user.password).subscribe(
			(response) => {
				//console.log("####### RESPONSE #######", response)
				this.toastr.success('Password has been changed successfully!', 'Alert!');
			},
			(error) => {
				this.toastr.error('Please enter valid password.', 'Validation Error!');
			}
		);
		this.bsModalRef.hide();
	}
}
