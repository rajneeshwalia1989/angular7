import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AdminVolunteerService {

  constructor(private _config: AppConfig, private http: HttpClient) { }

  changePassword(mainCampaignId: number, username: string, password: string) {
    // let body = new HttpParams();
    // body = body.set('Username', username);
    // body = body.set('Password', password);
    let updatedLogin = {
      'Username': username, 'Password': password
    }

    return this.http.post<any>(`${this._config.baseURL}/${mainCampaignId}/account-management/password-change
    `, updatedLogin, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }


  //SET HEADERS
	protected getRequestHeaders(): Object {
		let headers;
		headers = new HttpHeaders({
			'Content-Type': 'application/json',
			//'Content-Type': 'text/plain; charset=utf-8',
			//'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		});
		return { headers: headers, responseType: 'json' };
	}

}
