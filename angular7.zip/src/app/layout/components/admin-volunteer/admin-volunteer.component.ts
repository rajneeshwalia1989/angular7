import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ChangePasswordComponent } from './change-password/change-password.component';
import { Router } from '@angular/router';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-admin-volunteer',
  templateUrl: './admin-volunteer.component.html',
  styleUrls: ['./admin-volunteer.component.css']
})
export class AdminVolunteerComponent implements OnInit {
  bsModalRef: BsModalRef;
  _currentUser;

  constructor(private modalService: BsModalService, private router: Router,
    private authService: AuthService) { }

  ngOnInit() {
    // this._currentUser = JSON.parse(localStorage.getItem('CurrentUser'));
    this._currentUser = this.authService.getItemFromLocalStorage('CurrentUser');
  }
  changePassword(title) {
    this.bsModalRef = this.modalService.show(ChangePasswordComponent);
    this.bsModalRef.content.title = title;
  }
}
