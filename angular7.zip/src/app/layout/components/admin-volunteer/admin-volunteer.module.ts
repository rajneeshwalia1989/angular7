import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { AdminVolunteerComponent } from './admin-volunteer.component';

const routes: Routes = [
  { path: "", component: AdminVolunteerComponent, data: { title: "Campaign" } }
];

@NgModule({
  declarations: [
    AdminVolunteerComponent
  ],
  imports: [
    CommonModule,
    RouterModule.forChild(routes)
  ], 
 schemas: [CUSTOM_ELEMENTS_SCHEMA]

})
export class AdminVolunteerModule { }
