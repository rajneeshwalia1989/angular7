import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { VerifyValidSignatureComponent } from './verify-valid-signature.component';
import { FormsModule } from '@angular/forms';
import { NgxPaginationModule } from 'ngx-pagination';
import { FilterPipe } from 'src/app/shared/pipes/filter.pipe';

const routes: Routes = [
  { path: "", component: VerifyValidSignatureComponent, data: { title: "Verify Valid Signature" } }
];

@NgModule({
  declarations: [
    VerifyValidSignatureComponent,
    FilterPipe
  ],
  imports: [
    NgxPaginationModule,
    CommonModule,
    FormsModule,
    RouterModule.forChild(routes)    
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class VerifyValidSignatureModule { }
