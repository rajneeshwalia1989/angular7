import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/auth.service';
import { VerifyValidSignatureService } from './verify-valid-signature.service';
import { ToastrService } from 'ngx-toastr';
import { Router, ActivatedRoute } from '@angular/router';
import { SignatureValidation, STATUS_CODE, STATUS } from '../../models/enums';
import { SheetLineResponse } from '../../models/sheetLineResponse';

@Component({
  selector: 'app-verify-valid-signature',
  templateUrl: './verify-valid-signature.component.html',
  styleUrls: ['./verify-valid-signature.component.css']
})
export class VerifyValidSignatureComponent implements OnInit {
  _currentUser;
  signValidation = SignatureValidation;
  campaignId: number;
  loading: boolean = false;
  verifyValidSignature: any = [];
  itemsPerPage = 10;
  mainCampaignId: number;
  p: number = 1;
  searchText: string;

  constructor(private authService: AuthService, private service: VerifyValidSignatureService,
    private toastr: ToastrService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit() {
    this._currentUser = this.authService.getItemFromLocalStorage('CurrentUser');
    this.campaignId = +this.authService.getItemFromLocalStorage('campaignId');
    this.mainCampaignId = this._currentUser.mainCampaignId;
    this.toastr.clear()
    this.getSignatureData();

  }


  getStatus = (status) => status == 0 ? 'Unreviewed' : STATUS[STATUS_CODE[status]];
  totalPage = (total) => isNaN(parseInt(total)) ? 0 : parseInt(total);

  getSignatureData() {
    this.loading = true;
    this.service.GetSignatureData<SheetLineResponse>(this.campaignId)
      .subscribe(response => {
        this.verifyValidSignature = response;
        this.loading = false;
      },
      error => {
        this.loading = false;
      })
  }

  setSignatureValid(sheet, type) {
    sheet.signatureValidation = type
    this.toastr.clear()
    this.loading = true;
    let _signature = { SheetLineId: sheet.id, signatureValidation: type }
    this.service.SetValidSignature(this.campaignId, _signature)
      .subscribe(response => {
        this.toastr.success('Signature validation status updated!', 'Alert!')
        this.loading = false;
      },
        error => {
          this.toastr.error('Signature validation status not updated!', 'Error!')
        })

  }
}

