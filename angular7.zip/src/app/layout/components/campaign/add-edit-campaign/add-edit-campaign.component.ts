import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { BsModalRef } from 'ngx-bootstrap/modal';
import { CampaignService } from '../campaign.service';
import { LoginResult } from 'src/app/layout/models/loginResult';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/auth.service';

@Component({
	selector: 'app-add-edit-campaign',
	templateUrl: './add-edit-campaign.component.html',
	styleUrls: [ './add-edit-campaign.component.css' ]
})
export class AddEditCampaignComponent implements OnInit {
	@Output() addCampaign = new EventEmitter();

	title: string;
	campaignName: string;
	campaignId: number;
	_user: LoginResult;
	petitionSheetLineCount: number;

	constructor(
		public bsModalRef: BsModalRef,
		private service: CampaignService,
		private toastr: ToastrService,
		private authService: AuthService
	) {}

	ngOnInit() {
		setTimeout(() => {
			this.title = this.bsModalRef.content.BtnName;
			this.campaignName = this.bsModalRef.content.campaign ? this.bsModalRef.content.campaign.name : '';
		}, 0);
	}

	addEditCampaign() {
		// this._user = JSON.parse(localStorage.getItem('CurrentUser'));
		this._user = this.authService.getItemFromLocalStorage('CurrentUser');

		if (this.title == 'Add') {
			this.toastr.clear();
			this.service
				.createCampaign(+this._user.mainCampaignId, this.campaignName, this.petitionSheetLineCount)
				.subscribe(
					(response) => {
						this.addCampaign.emit(response);
						//console.log("####### RESPONSE #######", response)
						this.toastr.success('Campaign has been created successfully!', 'Alert!');
					},
					(error) => {
						console.log(error);
						this.toastr.error('Campaign has not been saved!.', 'Error!');
					}
				);

			this.bsModalRef.hide();
		} else {
			this.service.editCampaign(this.campaignName).subscribe((response) => {
				//console.log('####### RESPONSE #######', response)
			});
			this.bsModalRef.hide();
		}
	}
}
