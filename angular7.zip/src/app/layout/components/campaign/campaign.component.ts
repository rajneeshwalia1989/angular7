import { Component, OnInit } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { AddEditCampaignComponent } from './add-edit-campaign/add-edit-campaign.component';
import { CampaignService } from './campaign.service';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'src/app/auth.service';

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.css']
})
export class CampaignComponent implements OnInit {
  bsModalRef: BsModalRef;
  campaigns: any[] = [];
  _currentUser;
  campaignId: number;
  loading: boolean = false;
  itemsPerPage = 10;
  p: number = 1;

  constructor(private modalService: BsModalService, private service: CampaignService,
    private toastr: ToastrService,
    private authService: AuthService) { }

  ngOnInit() {
    this._currentUser = this.authService.getItemFromLocalStorage('CurrentUser');
    this.campaigns = this._currentUser.campaigns
    this.campaignId = +this.authService.getItemFromLocalStorage('campaignId');
  }

  editCampaign(campaign) {
    this.bsModalRef = this.modalService.show(AddEditCampaignComponent);
    this.bsModalRef.content.BtnName = 'Update';
    this.bsModalRef.content.campaign = campaign;
  }

  public addCampaign() {
    this.bsModalRef = this.modalService.show(AddEditCampaignComponent);
    this.bsModalRef.content.BtnName = 'Add';
    // Add Campaign to list
    this.bsModalRef.content.addCampaign
      .subscribe((result) => {
        this.campaigns.push({ id: result.id, name: result.name, mainCampaignId: result.mainCampaignId, petitionSheetLineCount: result.petitionSheetLineCount, usesMapWalkSheets: result.usesMapWalkSheets })
        this._currentUser.campaigns = this.campaigns
        // localStorage.setItem('CurrentUser', JSON.stringify(this._currentUser))
        this.authService.setItemToLocalStorage('CurrentUser', this._currentUser, true);

      }, (err) => {
        console.log(err)
      });
  }

  deleteCampaign(campaign) {
    this.toastr.error('', 'Not been implemented.');
    // const index = this.campaigns.findIndex(o => o.Name == campaign.name);
    // this.campaigns.splice(index, 1)
    // this.service.deleteCampaign(campaign.name)
    //   .subscribe(response => {
    //     console.log("###### RESPONSE ######", response);
    //   })
  }
}




