import { Injectable } from '@angular/core';
import { AppConfig } from 'src/app/app.config';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CampaignService {

  constructor(private _config: AppConfig, private http: HttpClient) { }

  createCampaign(mainCampaignId: number, name: string, count: number) {
   let body = {'Name': name, 'PetitionSheetLineCount':count}
    return this.http.post<any>(`${this._config.baseURL}/${mainCampaignId}/account-management/subcampaign-addition`, body, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  getCampaign<T>(mainCampaignId:number,campaignId: number): Observable<T> {
    return this.http.get<any>(`${this._config.baseURL}/${mainCampaignId}/${campaignId}/dashboard`, this.getRequestHeaders())
      //.map((res: Response) => res.text())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  editCampaign(name: string) {
    let body = new HttpParams();
    body = body.set('campaignName', name);

    return this.http.post<any>(`${this._config.baseURL}/account-management/campaign`, body, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  deleteCampaign(name: string) {
    let body = new HttpParams();
    body = body.set('campaignName', name);

    return this.http.delete<any>(`${this._config.baseURL}/account-management/campaign`, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err)
        })
      )
  }

  //SET HEADERS
	protected getRequestHeaders(): Object {
		let headers;
		headers = new HttpHeaders({
			'Content-Type': 'application/json',
			//'Content-Type': 'text/plain; charset=utf-8',
			//'Content-Type': 'application/json',
			'Access-Control-Allow-Origin': '*'
		});
		return { headers: headers, responseType: 'json' };
	}

}
