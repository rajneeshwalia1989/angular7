import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { CampaignComponent } from './campaign.component';
import { NgxPaginationModule } from 'ngx-pagination';
import { FormsModule } from '@angular/forms';

const routes: Routes = [
  { path: "", component: CampaignComponent, data: { title: "Campaign" } }
];

@NgModule({
  declarations: [
    CampaignComponent
  ],
  imports: [
    CommonModule,
    NgxPaginationModule,
    FormsModule,
    RouterModule.forChild(routes)    
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})

export class CampaignModule { }
