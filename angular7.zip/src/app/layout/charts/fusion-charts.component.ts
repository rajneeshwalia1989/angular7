import { Component, OnInit, Input } from '@angular/core';

@Component({
	selector: 'fusion-charts',
	templateUrl: './fusion-charts.component.html'
})
export class FusionChartsComponent implements OnInit {
	@Input() dashboard: any = {};
	sheetChecked: number;
	sheetUnchecked: number;
	dataSource: any = [];

	constructor() {}

	ngOnInit() {
		//console.log(this.dashboard);
		this.sheetChecked = this.dashboard.sheetChecked;
		this.sheetUnchecked = this.dashboard.sheetUploaded - this.dashboard.sheetChecked;
		this.dataSource = {
			chart: {
				caption: 'Recommended Portfolio Split',
				subCaption: 'For a net-worth of $1M',
				showValues: '1',
				showPercentValues: '1',
				showPercentInTooltip: '0',
				numberSuffix: '$',
				enableMultiSlicing: '1',
				theme: 'fusion'
			},
			data: [
				{
					label: 'Equity',
					value: this.sheetChecked
				},
				{
					label: 'Debt',
					value: this.sheetUnchecked
				}
			]
		};
	}
}
