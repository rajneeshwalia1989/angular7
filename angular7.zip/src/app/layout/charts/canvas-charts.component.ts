import { Component, OnInit, Input } from '@angular/core';
import * as CanvasJS from '../../../assets/canvasjs.min';
import { CampaignDashboardSummary } from '../models/campaignDashboardSummary';

@Component({
	selector: 'app-charts',
	templateUrl: './canvas-charts.component.html',
	styleUrls: [ '../dashboard/dashboard.component.css' ]
})
export class CanvasChartsComponent implements OnInit {
	@Input() dashboard = new CampaignDashboardSummary();
	ChartOne: any[];
	ChartTwo: any[];
	noSignatures: boolean = false;

	constructor() {}

	view: any[] = [ 600, 300 ];
	colorSchemeOne = {
		domain: [ '#2ecae4', '#e06528' ]
	};
	colorSchemeTwo = {
		domain: [ '#28a745', '#e06528', '#a5a5a5', '#ffc000', '#2ecae4' ]
	};

	onSelect(event) {
		//console.log(event);
	}

	ngOnInit() {
		if (
			!this.dashboard.validSignaturesPercentage &&
			!this.dashboard.invalidSignaturesPercentage &&
			!this.dashboard.blankSignaturesPercentage &&
			!this.dashboard.crossedOffSignaturesPercentage
		)
			this.noSignatures = true;
		else this.noSignatures = false;

		this.ChartOne = this.getChartOne(this.dashboard);
		this.ChartTwo = this.getChartTwo(this.dashboard);

		// let chart = new CanvasJS.Chart("chartContainer", {
		//   theme: "light2",
		//   animationEnabled: true,
		//   exportEnabled: true,
		//   creditText: "",
		//   title: {
		//     text: "Petition Sheets"
		//   },
		//   data: [{
		//     type: "pie",
		//     showInLegend: true,
		//     toolTipContent: "<b>{name}</b>:(#percent%)",
		//     indexLabel: "{name} - #percent%",
		//     dataPoints: [
		//       { y: this.dashboard.reviewedSheetPercentage, name: "Reviewed", color: "#e06528" },
		//       { y: this.dashboard.unreviewedSheetPercentage, name: "Unreviewed", color: "#2ecae4" }
		//     ]
		//   }]
		// });

		// chart.render();

		// let chart1 = new CanvasJS.Chart("chartContainer1", {
		//   theme: "light2",
		//   animationEnabled: true,
		//   exportEnabled: true,
		//   creditText: "",
		//   title: {
		//     text: "Checked Signatures"
		//   },
		//   data: [{
		//     type: "pie",
		//     showInLegend: true,
		//     toolTipContent: "<b>{name}</b>: (#percent%)",
		//     indexLabel: "{name} - #percent%",
		//     dataPoints: [
		//       { y: this.dashboard.validSignaturesPercentage, name: "Valid", color: "#28a745" },
		//       { y: this.dashboard.invalidSignaturesPercentage, name: "Invalid", color: "#e06528" },
		//       { y: this.dashboard.crossedOffSignaturesPercentage, name: "Crossed Out", color: "#a5a5a5" },
		//       { y: this.dashboard.blankSignaturesPercentage, name: "Blank", color: "#ffc000" },
		//       { y: this.dashboard.notFoundSignaturesPercentage, name: "Not Found", color: "#2ecae4" }
		//     ]
		//   }]
		// });

		// chart1.render();
	}

	getChartOne(dashboard) {
		return [
			{
				name: 'Reviewed (' + dashboard.reviewedSheetPercentage.toFixed(2) + ' %) ',
				value: dashboard.reviewedSheetPercentage.toFixed(2)
			},
			{
				name: 'Unreviewed (' + dashboard.unreviewedSheetPercentage.toFixed(2) + ' %) ',
				value: dashboard.unreviewedSheetPercentage.toFixed(2)
			}
		];
	}

	formatLabel(e) {
		//console.log(e)
		return e;
	}

	getChartTwo(dashboard) {
		return [
			{
				name: 'Valid (' + dashboard.validSignaturesPercentage.toFixed(2) + ' %) ',
				value: dashboard.validSignaturesPercentage.toFixed(2)
			},
			{
				name: 'Invalid (' + dashboard.invalidSignaturesPercentage.toFixed(2) + ' %) ',
				value: dashboard.invalidSignaturesPercentage.toFixed(2)
			},
			{
				name: 'Crossed Out (' + dashboard.crossedOffSignaturesPercentage.toFixed(2) + ' %) ',
				value: dashboard.crossedOffSignaturesPercentage.toFixed(2)
			},
			{
				name: 'Blank (' + dashboard.blankSignaturesPercentage.toFixed(2) + ' %) ',
				value: dashboard.blankSignaturesPercentage.toFixed(2)
			},
			{
				name: 'Not Found (' + dashboard.notFoundSignaturesPercentage.toFixed(2) + ' %) ',
				value: dashboard.notFoundSignaturesPercentage
			}
		];
	}
}
