import { Component, OnInit, ElementRef, Input, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginResult } from '../models/loginResult';
import { Campaign } from '../models/campaign';
import { CampaignDashboardSummary } from '../models/campaignDashboardSummary';
import { AuthService } from 'src/app/auth.service';
declare var $;

@Component({
	selector: 'app-sidebar',
	templateUrl: './sidebar.component.html',
	styleUrls: [ './sidebar.component.css' ]
})
export class SidebarComponent implements OnInit {
	campaignList: CampaignDashboardSummary[] = [];
	url: any;
	campaignName: string;
	campaignID: number;
	currentUser = new LoginResult();
	campaignsList: Campaign[] = [];
	currentCampaign: any;
	sheetNumber: number;

	@HostListener('window:scroll', [ '$event' ])
	onWindowScroll($event) {
		this.setSidebar();
	}
	@HostListener('window:resize', [ '$event' ])
	onResize($event) {
		if ($event.target.innerWidth < 992) {
			$('body').addClass('sidebar-mini');
			this.setSidebar();
		}
	}

	constructor(private activatedRoute: ActivatedRoute, private router: Router, public _auth: AuthService) {
		this.setSidebar();
	}

	ngOnInit() {
		$('#rla').removeClass('isActive');
		console.log('sheetNumber', this.sheetNumber);
		$(window).on('load', function() {
			setTimeout(function() {
				$('.preloader-backdrop').fadeOut(200);
				$('body').addClass('has-animation');
			}, 0);
		});
		$(window).on('load resize scroll', function() {
			if ($(this).width() < 992) {
				$('body').addClass('sidebar-mini');
			}
		});
		$(function() {
			try {
				// SIDEBAR ACTIVATE METISMENU
				$('.metismenu').metisMenu();
			} catch (err) {}

			// Activate Tooltips
			$('[data-toggle="tooltip"]').tooltip();

			// Activate Popovers
			$('[data-toggle="popover"]').popover();

			// Activate slimscroll
			$('.scroller').each(function() {
				$(this).slimScroll({
					height: $(this).attr('data-height'),
					color: $(this).attr('data-color'),
					railOpacity: '0.9'
				});
			});
		});
		// PAGE PRELOADING ANIMATION
		$(window).on('load', function() {
			setTimeout(function() {
				$('.preloader-backdrop').fadeOut(200);
				$('body').addClass('has-animation');
			}, 0);
		});

		$('.js-sidebar-toggler').click(function() {
			$('body').toggleClass('sidebar-mini');
			if ($('body').hasClass('sidebar-mini')) {
				$('.fa-angle-right').addClass('show').removeClass('hide');
				$('.fa-angle-left').addClass('hide').removeClass('show');
				$('#sel1').addClass('hide').removeClass('show');
			} else {
				$('.fa-angle-right').addClass('hide').removeClass('show');
				$('.fa-angle-left').addClass('show').removeClass('hide');
				$('#sel1').addClass('show').removeClass('hide');
			}
		});
		let user = this._auth.getItemFromLocalStorage('CurrentUser') as LoginResult;

		this.currentUser = user;

		this.campaignName = this._auth.getItemFromLocalStorage('campaignName')
			? this._auth.getItemFromLocalStorage('campaignName')
			: this.currentUser.mainCampaignName;

		this.campaignID = this._auth.getItemFromLocalStorage('campaignId')
			? +this._auth.getItemFromLocalStorage('campaignId')
			: this.currentUser.mainCampaignId;

		this._auth.setItemToLocalStorage('campaignName', this.campaignName);
		this._auth.setItemToLocalStorage('campaignId', this.campaignID ? this.campaignID.toString() : '');

		if (user) {
			this.campaignList = user.campaigns;

			if (this._auth.getItemFromLocalStorage('currentCampaign')) {
				this.currentCampaign = this._auth.getItemFromLocalStorage('currentCampaign');
			} else {
				this.currentCampaign =
					this.campaignList.filter((x) => (x['id'] == this.campaignID ? x : '')).length > 0
						? this.campaignList.filter((x) => (x['id'] == this.campaignID ? x : ''))[0]
						: '';
				this._auth.setItemToLocalStorage('currentCampaign', JSON.stringify(this.currentCampaign));
			}

			let petitionSheetLineCount = this._auth.getItemFromLocalStorage('petitionSheetLineCount')
				? this._auth.getItemFromLocalStorage('petitionSheetLineCount')
				: 0;

			let currentCampaign = this.campaignList.find((x) => x.id == this.campaignID);
			if (currentCampaign) {
				petitionSheetLineCount = currentCampaign.petitionSheetLineCount;
			}
			this._auth.setItemToLocalStorage('petitionSheetLineCount', petitionSheetLineCount);
		} else this.logout();
	}

	getCampaignList() {
		let user = this._auth.getItemFromLocalStorage('CurrentUser') as LoginResult;
		this.currentUser = user;
		if (user) {
			this.campaignList = user.campaigns;
		}
	}

	setCampaignValue(event) {
		this.campaignID = +event.target.value;
		// window.localStorage.setItem("campaignId", event.target.value);
		this._auth.setItemToLocalStorage('campaignId', event.target.value);

		let campaign = this.campaignList.filter((x) => (x['id'] == this.campaignID ? x['name'] : ''));
		let currentCampaign =
			this.campaignList.filter((x) => (x['id'] == this.campaignID ? x : '')).length > 0
				? this.campaignList.filter((x) => (x['id'] == this.campaignID ? x : ''))[0]
				: '';
		// window.localStorage.setItem("campaignName", campaign[0]['name']);
		this._auth.setItemToLocalStorage('campaignName', campaign[0]['name']);
		this._auth.setItemToLocalStorage('petitionSheetLineCount', campaign[0]['petitionSheetLineCount']);
		this._auth.setItemToLocalStorage('currentCampaign', JSON.stringify(currentCampaign));

		// this.router.navigateByUrl(`/dashbord/${this.campaignID}`)
		// .then(() => this.router.navigate(['/dashboard/', this.campaignID]));
		this.router.navigate([ `/dashboard/${this.campaignID}` ]);
		//window.location.reload();
	}

	logout() {
		this._auth.removeAllLocalStorage();
		this.router.navigate([ './login' ]);
	}

	setSidebar() {
		setTimeout(() => {
			if (!this._auth.isAuthenticated()) {
				this.router.navigate([ 'login' ]);
			}
		}, 0);

		//console.log('sidebar-mini', $("body").hasClass("sidebar-mini"))
		if ($('body').hasClass('sidebar-mini')) {
			$('.fa-angle-right').addClass('show').removeClass('hide');
			$('.fa-angle-left').addClass('hide').removeClass('show');
			$('#sel1').addClass('hide').removeClass('show');
		} else {
			$('.fa-angle-right').addClass('hide').removeClass('show');
			$('.fa-angle-left').addClass('show').removeClass('hide');
			$('#sel1').addClass('show').removeClass('hide');
		}
		$('.canvasjs-chart-credit').html('');
	}

	onLinkClick(val?) {
		if ($('body').hasClass('sidebar-mini')) {
			$('.fa-angle-right').addClass('show').removeClass('hide');
			$('.fa-angle-left').addClass('hide').removeClass('show');
			$('#sel1').addClass('hide').removeClass('show');
		}
		console.log('path', `/check-sheets/${this.campaignID}`);
		if (val) {
			//this.router.isActive(`/check-sheets/${this.campaignID}`, true);
			//if (window.location.pathname === `/check-sheets/${this.campaignID}`) {
			$('#rla').addClass('isActive');
			this.router.navigate([ `/check-sheets/${this.campaignID}` ], {
				queryParams: {
					sheetnumber: this.checkSheetNumber()
				}
			});
		} else {
			$('#rla').removeClass('isActive');
		}
	}

	checkSheetNumber() {
		let queryParam = window.location.search;
		if (queryParam.includes('?sheet=')) {
			return;
		} else {
			let arr = queryParam.split('=');
			if (arr.length) {
				return arr[1];
			}
		}
	}
}
