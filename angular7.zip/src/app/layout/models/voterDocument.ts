export class VoterDocument {
    public CampaignId: number
    public EncodedCsv: string
}