export class MapWalkSheetSpecifications
{
    public  WestBorder
    public  NorthBorder
    public EastBorder
    public SouthBorder 
    public NorthSouthStreets 
    public EastWestStreets 
}