export class Campaign {
    public name: string    
    public mainCampaignId: number    
    public id: number
}
