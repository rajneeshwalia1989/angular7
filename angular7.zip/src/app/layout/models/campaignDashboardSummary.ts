import { Campaign } from "./campaign";

export class CampaignDashboardSummary {
    public mainCampaignId: number
    public id: number //similar to campaignId
    public campaignId: number
    public mainCampaignName: string    
    public sheetNumber: number
    public campaigns: Campaign[]
    public petitionSheetLineCount: number

    public uploadedSheetCount: number
    public reviewedSheetCount: number
    public reviewedSignatureCount: number
    public validSignatureCount: number
    public approximateTotalSignatureCount: number
    public reviewedSheetPercentage: number
    public unreviewedSheetPercentage: number
    public validSignaturesPercentage: number
    public invalidSignaturesPercentage: number
    public blankSignaturesPercentage: number
    public notFoundSignaturesPercentage: number
    public crossedOffSignaturesPercentage: number
    public nextSheetToReview: number
    public reviewedSheetNumbers: number[]
    public unreviewedSheetIds: number[]
    public hasVoters: boolean
}