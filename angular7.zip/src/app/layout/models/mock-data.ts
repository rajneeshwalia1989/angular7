export let sheetLineMock = [
    {
        id: 1, sheetId: 1, lineNumber: 1, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 2, sheetId: 1, lineNumber: 2, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 3, sheetId: 1, lineNumber: 3, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 4, sheetId: 1, lineNumber: 4, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 5, sheetId: 1, lineNumber: 5, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 6, sheetId: 1, lineNumber: 6, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 7, sheetId: 1, lineNumber: 7, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 8, sheetId: 1, lineNumber: 8, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 9, sheetId: 1, lineNumber: 9, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    },
    {
        id: 10, sheetId: 1, lineNumber: 10, status: 0, voterName: "", voterRegistrationId: "", voterId: 0
    }
]

export let sheetObjectionsMock = [
    { text: 'Date of Notary Missing', value: 0 },
    { text: 'Circulator did not appear before Notary', value: 1 },
    { text: 'Circulators Address is incomplete', value: 2 },
    { text: 'Circulators Aﬃdavit is incomplete', value: 3 },
    { text: 'Notary is incomplete', value: 4 },
    { text: 'Circulator did not Sign Petition', value: 5 },
    { text: 'Circulator does not live at Address Shown', value: 6 },
    { text: 'Circulators Signature is not Geniune', value: 7 },
    { text: 'Circulator is not Qualiﬁed Under the Law', value: 8 },
    { text: 'Circulator Circulated for a Candidate of Another Party', value: 9 },
    { text: 'Damage to Page Prevents Clear Reading', value: 10 },
    { text: 'Other', value: 11 }
]

 export let getCounties = [
      { id: 1, name: 'Cook' },
      { id: 2, name: 'Columbia' },
      { id: 3, name: 'Dade' },
      { id: 4, name: 'Decatur' },
      { id: 5, name: 'Clarke' },
      { id: 6, name: 'Clay' },
      { id: 7, name: 'Clayton' },
      { id: 8, name: 'Cobb' },
      { id: 9, name: 'Coffee' },
    ];
  

    export let getCities= [
      { id: 1, county_id: 1, name: 'Chicago' },
      { id: 2, county_id: 1, name: 'Harvey' },
      { id: 3, county_id: 2, name: 'Clatskanie' },
      { id: 4, county_id: 2, name: 'Columbia City' },
      { id: 5, county_id: 3, name: 'Miami' },
      { id: 6, county_id: 3, name: 'Doral' },
      { id: 7, county_id: 4, name: 'Davis City' },
      { id: 8, county_id: 4, name: 'Garden Grove' },
      { id: 9, county_id: 5, name: 'Jackson' },
      { id: 10, county_id: 5, name: 'Thomasville' },
      { id: 11, county_id: 6, name: 'Green Cove Springs' },
      { id: 12, county_id: 6, name: 'Keystone Heights' },
      { id: 13, county_id: 7, name: 'Lake City' },
      { id: 14, county_id: 7, name: 'Forest Park' },
      { id: 15, county_id: 8, name: 'Fair Oaks' },
      { id: 16, county_id: 8, name: 'Vinings' },
      { id: 17, county_id: 9, name: 'Manchester' },
      { id: 18, county_id: 9, name: 'Tullahoma' },
    ]
  

  export let getWard=[
      { id: 1, city_id: 1, name: 'Ward 1' },
      { id: 2, city_id: 1, name: 'Ward 2' },
      { id: 3, city_id: 1, name: 'Ward 3' },
      { id: 4, city_id: 1, name: 'Ward 4' },
      { id: 5, city_id: 2, name: 'Ward 1' },
      { id: 6, city_id: 2, name: 'Ward 2' },
      { id: 7, city_id: 2, name: 'Ward 3' },
      { id: 8, city_id: 2, name: 'Ward 4' },
      { id: 9, city_id: 3, name: 'Ward 1' },
      { id: 10, city_id: 3, name: 'Ward 2' },
      { id: 11, city_id: 3, name: 'Ward 3' },
      { id: 12, city_id: 4, name: 'Ward 1' },
      { id: 13, city_id: 4, name: 'Ward 2' },
      { id: 14, city_id: 5, name: 'Ward 1' },
      { id: 15, city_id: 5, name: 'Ward 2' },
      { id: 16, city_id: 5, name: 'Ward 3' },
      { id: 17, city_id: 6, name: 'Ward 1' },
      { id: 18, city_id: 6, name: 'Ward 2' },
      { id: 19, city_id: 7, name: 'Ward 1' },
      { id: 20, city_id: 7, name: 'Ward 2' },
      { id: 21, city_id: 8, name: 'Ward 1' },
      { id: 22, city_id: 8, name: 'Ward 2' },
      { id: 23, city_id: 9, name: 'Ward 1' },
      { id: 24, city_id: 9, name: 'Ward 2' },
      { id: 25, city_id: 10, name: 'Ward 1' },
      { id: 26, city_id: 10, name: 'Ward 2' },
      { id: 27, city_id: 11, name: 'Ward 1' },
      { id: 28, city_id: 11, name: 'Ward 2' },
      { id: 29, city_id: 12, name: 'Ward 1' },
      { id: 30, city_id: 12, name: 'Ward 2' },
      { id: 31, city_id: 13, name: 'Ward 1' },
      { id: 32, city_id: 13, name: 'Ward 2' },
      { id: 23, city_id: 14, name: 'Ward 1' },
      { id: 33, city_id: 14, name: 'Ward 2' },
      { id: 34, city_id: 15, name: 'Ward 1' },
      { id: 35, city_id: 15, name: 'Ward 2' },
      { id: 36, city_id: 16, name: 'Ward 1' },
      { id: 37, city_id: 16, name: 'Ward 2' },
      { id: 38, city_id: 17, name: 'Ward 1' },
      { id: 39, city_id: 17, name: 'Ward 2' },
      { id: 40, city_id: 18, name: 'Ward 1' },
      { id: 41, city_id: 18, name: 'Ward 2' }

    ]
  

  export let getPrecinct = [
      { id: 1, ward_id: 1, name: '22' },
      { id: 2, ward_id: 1, name: '23' },
      { id: 3, ward_id: 2, name: '22' },
      { id: 4, ward_id: 2, name: '23' },
      { id: 5, ward_id: 3, name: '22' },
      { id: 6, ward_id: 3, name: '23' },
      { id: 7, ward_id: 4, name: '22' },
      { id: 8, ward_id: 4, name: '23' },
      { id: 9, ward_id: 5, name: '22' },
      { id: 10, ward_id: 5, name: '23' },
      { id: 11, ward_id: 6, name: '22' },
      { id: 12, ward_id: 6, name: '23' },
      { id: 13, ward_id: 7, name: '22' },
      { id: 14, ward_id: 7, name: '23' },
      { id: 15, ward_id: 8, name: '22' },
      { id: 16, ward_id: 8, name: '23' },
      { id: 17, ward_id: 9, name: '22' },
      { id: 18, ward_id: 9, name: '23' },
      { id: 19, ward_id: 10, name: '22' },
      { id: 20, ward_id: 10, name: '23' },
      { id: 21, ward_id: 11, name: '22' },
      { id: 22, ward_id: 11, name: '23' },
      { id: 23, ward_id: 12, name: '22' },
      { id: 24, ward_id: 12, name: '23' },
      { id: 25, ward_id: 13, name: '23' },
      { id: 26, ward_id: 13, name: '23' },
      { id: 27, ward_id: 14, name: '23' },
      { id: 28, ward_id: 14, name: '23' },
      { id: 29, ward_id: 15, name: '23' },
      { id: 30, ward_id: 15, name: '23' },
      { id: 31, ward_id: 16, name: '23' },
      { id: 32, ward_id: 16, name: '23' },
      { id: 33, ward_id: 17, name: '23' },
      { id: 34, ward_id: 17, name: '23' },
      { id: 35, ward_id: 18, name: '23' },
      { id: 36, ward_id: 18, name: '23' },
      { id: 37, ward_id: 19, name: '23' },
      { id: 38, ward_id: 19, name: '23' },
      { id: 39, ward_id: 20, name: '23' },
      { id: 40, ward_id: 20, name: '23' },
      { id: 41, ward_id: 21, name: '23' },
      { id: 42, ward_id: 21, name: '22' },
      { id: 43, ward_id: 22, name: '23' },
      { id: 44, ward_id: 22, name: '22' },
      { id: 45, ward_id: 23, name: '23' },
      { id: 46, ward_id: 23, name: '22' },
      { id: 47, ward_id: 23, name: '23' },
      { id: 48, ward_id: 24, name: '22' },
      { id: 49, ward_id: 24, name: '23' },
      { id: 50, ward_id: 25, name: '22' },
      { id: 51, ward_id: 25, name: '23' },
      { id: 52, ward_id: 26, name: '22' },
      { id: 53, ward_id: 26, name: '23' },
      { id: 54, ward_id: 27, name: '22' },
      { id: 55, ward_id: 27, name: '23' },
      { id: 56, ward_id: 28, name: '22' },
      { id: 57, ward_id: 28, name: '23' },
      { id: 58, ward_id: 29, name: '22' },
      { id: 59, ward_id: 29, name: '23' },
      { id: 60, ward_id: 30, name: '22' },
      { id: 61, ward_id: 30, name: '23' },
      { id: 62, ward_id: 31, name: '22' },
      { id: 63, ward_id: 31, name: '23' },
      { id: 64, ward_id: 32, name: '22' },
      { id: 65, ward_id: 32, name: '23' },
      { id: 66, ward_id: 33, name: '22' },
      { id: 67, ward_id: 33, name: '23' },
      { id: 68, ward_id: 34, name: '22' },
      { id: 69, ward_id: 34, name: '23' },
      { id: 70, ward_id: 35, name: '22' },
      { id: 71, ward_id: 35, name: '23' },
      { id: 72, ward_id: 36, name: '22' },
      { id: 73, ward_id: 36, name: '23' },
      { id: 74, ward_id: 37, name: '22' },
      { id: 75, ward_id: 37, name: '23' },
      { id: 76, ward_id: 38, name: '22' },
      { id: 77, ward_id: 38, name: '23' },
      { id: 78, ward_id: 39, name: '22' },
      { id: 79, ward_id: 39, name: '23' },
      { id: 80, ward_id: 40, name: '22' },
      { id: 81, ward_id: 40, name: '23' },
      { id: 82, ward_id: 41, name: '22' },
      { id: 83, ward_id: 41, name: '23' }


    ]
  
