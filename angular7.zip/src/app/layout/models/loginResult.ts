export class LoginResult {
    public id: number
    public username: string
    public isAdmin: boolean
    public mainCampaignId: number
    public mainCampaignName: string
    public campaigns: any
    public walkSheetOptions: any
}