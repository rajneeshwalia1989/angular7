export enum STATUS {
    Empty = 'Empty',
    ConfirmedVoter = 'Confirmed Voter',
    VoterNotFound = 'Voter Not Found',
    LineCrossedOff = 'Line Crossed Off',
    LineBlank = 'Line Blank',
    LineInvalid = 'Line Invalid',
   
}

export enum STATUS_CODE {
    Empty = 0,
    ConfirmedVoter = 1,
    VoterNotFound = 2,
    LineCrossedOff = 3,
    LineBlank = 4,
    LineInvalid = 5,
}


export enum OBJECTIONS {
    None = 'None',
    NotaryDateMissing = 'Date of Notary Missing',
    CirculatorNoNotaryAppearance = 'Circulator did not appear before Notary',
    CirculatorAddressIncomplete = 'Circulators Address is incomplete',
    CirculatorAffidavitIncomplete = 'Circulators Aﬃdavit is incomplete',
    NotaryIncomplete = 'Notary is incomplete',
    CirculatorSignatureMissing = 'Circulator did not Sign Petition',
    CirculatorAddressIncorrect = 'Circulator does not live at Address Shown',
    CirculatorSignatureIncorrect = 'Circulators Signature is not Geniune',
    CirculatorNotLegallyQualified = 'Circulator is not Qualiﬁed Under the Law',
    CirculatorAnotherParty = 'Circulator Circulated for a Candidate of Another Party',
    DamagePreventsReading = 'Damage to Page Prevents Clear Reading',
    Other = 'Other',
    
}

export enum OBJECTIONS_STATUS {
    NotaryDateMissing = 0,
    CirculatorNoNotaryAppearance = 1,
    CirculatorAddressIncomplete = 2,
    CirculatorAffidavitIncomplete = 3,
    NotaryIncomplete = 4,
    CirculatorSignatureMissing = 5,
    CirculatorAddressIncorrect = 6,
    CirculatorSignatureIncorrect = 7,
    CirculatorNotLegallyQualified = 8,
    CirculatorAnotherParty = 9,
    DamagePreventsReading = 10,
    Other = 11

}

export enum LineStatus {
    Unreviewed,
    ConfirmedVoter,
    VoterNotFound,
    LineCrossedOff,
    LineBlank,
    LineInvalid
}

export enum PetitionObjection {
    NotaryDateMissing,
    CirculatorNoNotaryAppearance,
    CirculatorAddressIncomplete,
    CirculatorAffidavitIncomplete,
    NotaryIncomplete,
    CirculatorSignatureMissing,
    CirculatorAddressIncorrect,
    CirculatorSignatureIncorrect,
    CirculatorNotLegallyQualified,
    CirculatorAnotherParty,
    DamagePreventsReading,
    Other
}

export enum SignatureValidation {
    NotValidated,
    Valid,
    Invalid
}

export enum FileType {
    PDF,
    CSV
}

export enum Ordinal {
    First = "First",
    Owner = "Owner",
    Second = "Second",
    Third = "Third",
    Fourth = "Fourth",
    Fifth = "Fifth",
    Sixth = "Sixth",
    Seventh = "Seventh",
    Eighth = "Eighth",
    Ninth = "Ninth",
    Tenth = "Tenth"
}