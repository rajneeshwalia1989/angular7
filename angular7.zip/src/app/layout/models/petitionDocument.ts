export class PetitionDocument {
    public CampaignId: number
    public EncodedPdf: string
}