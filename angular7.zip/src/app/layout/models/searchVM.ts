export class searchVM {
    public firstName: string;
    public lastName: string;
    public streetNumber: number;
    public streetName: string;
}

export class VoterSearchResult {
    public RegistrationId: string;
    public FullName: string;
    public FullAddress: number;
    public CityStateZip: string;
}