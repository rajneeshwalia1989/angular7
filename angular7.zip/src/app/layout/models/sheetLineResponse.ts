export class SheetLineResponse {
    public Id: number
    public SheetId: number
    public LineNumber: number
    public Status: number
    public EncodedCsv: string
    public SignatureValidation: string
    public VoterRegistrationId: string
    public VoterName: string
    public VoterAddress: string

    public sheetNumber: number
// Only relevant if status indicates confirmed voter
    public voterId: number
    public voterCity: string
    public voterZip: string
    public campaignName: string
    public circulator: string
    public notary: string
    public date: string
}