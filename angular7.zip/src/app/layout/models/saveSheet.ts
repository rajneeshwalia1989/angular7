import { PetitionObjection } from "./enums";

export class saveSheetVM {
    public campaignName: string;
    public fullSheetNotes: string;

    public List: List[];

    public id: number;
    public Objection: string;
    public Objections: PetitionObjection[];
    public encodedImage: any;
    public Circulator: string;
    public Notary: string;
    public Date: string;
    public Notes: string;
    public sheetNumber: number;
    public sheetNumberDB: number;
    public isReviewed: boolean;
}

export class List {
    public status: string;
    public voterName: string;
}
