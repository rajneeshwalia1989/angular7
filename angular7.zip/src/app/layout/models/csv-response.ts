export class CSVData {
    public title: any[]
    public header: any[]
    public cols: any[]
    public fullResponse: any[]    
  }

  export class CSVResponse {
    public _validSignaturesCsv: CSVData
    public _sheetCsv: CSVData
    public _totalValidSignatureCsv: CSVData
    public _duplicateSignaturesCsv: CSVData
    public _objectionsCsv: CSVData    
  }

