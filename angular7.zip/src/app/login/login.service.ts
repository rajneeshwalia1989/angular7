import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, of, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { AppConfig } from '../app.config';
import { Login } from './login-model';

@Injectable({ providedIn: 'root' })
export class LoginService {

  constructor(private http: HttpClient, private router: Router, private _config: AppConfig) { }

  loginUser<T>(user: Login): Observable<T> {

    //let body = { 'Username': user, 'Password': password }  

    return this.http.post<T>(`${this._config.baseURL}/new-session`, user, this.getRequestHeaders())
      .pipe(
        catchError(err => {
          return throwError(err);
        })
      );

    //   if (user == 'admin' && password == '12345') {
    //     return of({
    //       IsAdmin: true,
    //       Username: user,
    //       UserId: 1,
    //       CampaignId: 101,
    //       CampaignName: 'admin campaign',
    //       Token: 'authentication-token'
    //     });
    //   }
    //   else if (user == 'user' && password == '12345') {
    //     return of({
    //       IsAdmin: false,
    //       Username: user,
    //       UserId: 2,
    //       CampaignId: 102,
    //       CampaignName: 'user campaign',
    //       Token: 'authentication-token'
    //     });
    //   }
    //   else {
    //     return of(null);
    //   }
    // }
    // else {
    //   return of(null);

  }

  //SET HEADERS
  protected getRequestHeaders(): Object {
    let headers;
    headers = new HttpHeaders({
      //'Content-Type': 'application/x-www-form-urlencoded',
      //'Content-Type': 'text/plain; charset=utf-8',
      'Content-Type': 'application/json',
       'Access-Control-Allow-Origin': '*',
      // "Access-Control-Allow-Credentials" : "true",
      // 'Access-Control-Allow-Headers': 'Content-Type'

    });
    return { headers: headers, responseType: 'json' };
  }

}
