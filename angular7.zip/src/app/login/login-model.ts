export class Login {
    public username: string
    public password: string
}