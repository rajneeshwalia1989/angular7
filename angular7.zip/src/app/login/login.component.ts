import { Component, OnInit } from '@angular/core';
import { LoginService } from './login.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { LoginResult } from '../layout/models/loginResult';
import { Login } from './login-model';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {
  username: string;
  password: string;
  loading: boolean = false;

  constructor(private router: Router, private service: LoginService, private toastr: ToastrService,
    private authService: AuthService) {
    this.authService.removeAllLocalStorage();
  }

  ngOnInit() {
  }

  login() {
    this.loading = true;
    this.toastr.clear();
    let _user: Login = { username: this.username, password: this.password }
    this.service.loginUser<LoginResult>(_user)
      .subscribe(response => {
        if (response) {
          this.authService.setItemToLocalStorage("CurrentUser", response, true);
          this.toastr.success('', 'Login successful!!');
          this.router.navigate(['dashboard/', response.mainCampaignId]);
          //this.loading = false;
        }
        else {
          this.authService.removeFromLocalStorage("CurrentUser");
          // localStorage.removeItem("CurrentUser")
          this.password = undefined;
          this.toastr.error('Please enter correct username & password.', 'Error!');
          this.loading = false;
        }
      },
        error => {
          this.password = undefined;
          this.toastr.error('Please enter correct username & password.', 'Error!');
          console.log('error##', error)
          this.loading = false;
        });
  }

  contactUs() {
    window.open("http://erehwonatlas.com/contactus.html", "_blank");
  }
}
