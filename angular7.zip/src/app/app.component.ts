import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute, NavigationStart } from '@angular/router';
import { AuthService } from './auth.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'Erewhon';
  showSideBarMenu: boolean = true;
  @ViewChild('footer') element: ElementRef;

  constructor(
    private activatedRoute: ActivatedRoute,
    public _auth: AuthService,
    private router: Router) {
    if (!this._auth.isAuthenticated()) {
      this.router.navigate(['login']);
    }

  }
  // constructor(private router: Router) {
  //   // on route change to '/login', set the variable show to false
  //   router.events.forEach((event) => {
  //     if (event instanceof NavigationStart) {
  //       if (event['url'] == '/login') {
  //         this.showSideBarMenu = false;
  //       } else {
  //         this.showSideBarMenu = true;
  //       }
  //     }
  //   });
  // }

  ngOnInit() {
    const { x, y } = this.element.nativeElement.getBoundingClientRect();
  }


}
