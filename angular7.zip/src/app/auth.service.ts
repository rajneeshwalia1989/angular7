import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private router: Router) { }

  public isAuthenticated(): boolean {
    const _currentUser = this.getItemFromLocalStorage("CurrentUser");
    return _currentUser ? true : false;
  }

  public isAdmin(): boolean {
    if (this.isAuthenticated()) {
      const _currentUser = this.getItemFromLocalStorage("CurrentUser") == null
        ? null : this.getItemFromLocalStorage("CurrentUser");
      return _currentUser ? _currentUser.isAdmin ? true : false : false;
    } else {
      return false;
    }
  }

  setItemToLocalStorage(key, value, hasJson = false) {
    if (hasJson)
      window.localStorage.setItem(key, JSON.stringify(value))
    else
      window.localStorage.setItem(key, value)
  }

  getItemFromLocalStorage(key): any {
    let _result = window.localStorage.getItem(key);
    if (_result) {
      try {
        return JSON.parse(_result);
      } catch (err) {
        return _result;
      }
    }
    return null;
  }

  removeFromLocalStorage(key) {
    window.localStorage.removeItem(key);
  }

  removeAllLocalStorage() {
    // this.removeFromLocalStorage('CurrentUser');
    // this.removeFromLocalStorage('campaignName');
    // this.removeFromLocalStorage('petitionSheetLineCount');
    // this.removeFromLocalStorage('campaignId');
    // this.removeFromLocalStorage('reviewedSheetNumbers');
    localStorage.clear();
  }
}
