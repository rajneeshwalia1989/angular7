import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuardService as AuthGuard  } from './authGuard/auth-guard.service';
import { RoleGuardService as RoleGuard  } from './authGuard/role-guard.service';

const routes: Routes = [
  { path: "", redirectTo: "login", pathMatch: "full" },
  {
    path: "login",
    loadChildren: './login/login.module#LoginModule',
  },
  {
    path: "dashboard/:id",
    loadChildren: './layout/dashboard/dashboard.module#DashboardModule',
    canActivate: [AuthGuard]
  },
  {
    path: "dashbord/:id",
    loadChildren: './layout/dashboard/dashboard.module#DashboardModule',
    canActivate: [AuthGuard]
  },
  {
    path: "account/:id",
    loadChildren: './layout/components/account-management/account-management.module#AccountManagementModule',
    canActivate: [AuthGuard]
  },
  {
    path: "admin-volunteer/:id",
    loadChildren: './layout/components/admin-volunteer/admin-volunteer.module#AdminVolunteerModule',
    canActivate: [AuthGuard]
  },
  {
    path: "campaign/:id",
    loadChildren: './layout/components/campaign/campaign.module#CampaignModule',
    canActivate: [RoleGuard]
  },
  {
    path: "help",
    loadChildren: './layout/components/help/help.module#HelpModule',
    canActivate: [RoleGuard]
  },
  {
    path: "upload/:id",
    loadChildren: './layout/components/upload/upload.module#UploadModule',
    canActivate: [RoleGuard]
  },
  {
    path: "check-sheets/:id",
    loadChildren: './layout/components/check-sheets/check-sheets.module#CheckSheetsModule',
    canActivate: [AuthGuard]
  },
  {
    path: "review-checked-sheets/:id",
    loadChildren: './layout/components/review-checked-sheets/review-checked-sheets.module#ReviewCheckedSheetsModule',
    canActivate: [RoleGuard]
  },
  {
    path: "reports/:id",
    loadChildren: './layout/components/reports/reports.module#ReportsModule',
    canActivate: [RoleGuard]
  },
  {
    path: "verify-valid-signature",
    loadChildren: './layout/components/verify-valid-signature/verify-valid-signature.module#VerifyValidSignatureModule',
    canActivate: [RoleGuard]
  },
  {
    path: "walk-sheets/:id",
    loadChildren: './layout/components/walk-sheets/walk-sheets.module#WalkSheetsModule',
    canActivate: [RoleGuard]
  },
  {
    path: "**",
    loadChildren: './login/login.module#LoginModule',
  }

];

@NgModule({
  imports: [
    RouterModule.forRoot(routes) //preloadingStrategy: PreloadAllModules
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA],
  exports: [RouterModule]
})
export class AppRoutingModule { }
