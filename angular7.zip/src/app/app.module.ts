import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';

import { AppComponent } from './app.component';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { SidebarComponent } from './layout/sidebar/sidebar.component';
import { HeaderComponent } from './layout/header/header.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { AppConfig } from './app.config';
import { SkipSheetModalComponent } from './layout/components/check-sheets/skip-sheet-modal/skip-sheet-modal.component';
import { DeleteSheetModalComponent } from './layout/components/check-sheets/delete-sheet-modal/delete-sheet-modal.component';
import { SignatureModalComponent } from './layout/components/check-sheets/signature-modal/signature-modal.component';
import { AddEditCampaignComponent } from './layout/components/campaign/add-edit-campaign/add-edit-campaign.component';
import { ChangePasswordComponent } from './layout/components/admin-volunteer/change-password/change-password.component';
import { HttpModule } from '@angular/http';
import { AuthGuardService } from './authGuard/auth-guard.service';
import { RoleGuardService } from './authGuard/role-guard.service';
import { CacheInterceptor } from './shared/cache-interceptor.service';


const APP_PROVIDERS = [
  AppConfig
]

@NgModule({
  declarations: [
    AppComponent,
    SidebarComponent,
    HeaderComponent,
    AddEditCampaignComponent,
    ChangePasswordComponent,
    SkipSheetModalComponent,
    DeleteSheetModalComponent,
    SignatureModalComponent
  ],
  imports: [
    HttpModule,
    BrowserModule,
    AppRoutingModule,
    AngularFontAwesomeModule,
    ModalModule.forRoot(),
    ButtonsModule.forRoot(),
    HttpClientModule,
    FormsModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({ timeOut: 500000, positionClass: 'toast-center-center' }),
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CacheInterceptor,
      multi: true
    },
    APP_PROVIDERS,
    AuthGuardService,
    RoleGuardService
  ],
  entryComponents: [
    AddEditCampaignComponent,
    ChangePasswordComponent,
    SkipSheetModalComponent,
    DeleteSheetModalComponent,
    SignatureModalComponent
  ],
  bootstrap: [AppComponent],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class AppModule { }
